package edu.hm.cs.bka.dev2.splitting;


import static org.junit.jupiter.api.Assertions.*;


import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StringHelperTest {

  @Test
  public void shouldSplitString() {
    Pair<String, String> result = StringHelper.split("Abrakadabra", 5);
    assertNotNull(result, "Split gibt kein Ergebnis zurück!");
    assertEquals("Abrak", result.getFirst());
    assertEquals("adabra", result.getSecond());
  }

  @Test
  public void shoudlSplitWithZero() {
    Pair<String, String> result = StringHelper.split("Abrakadabra", 0);
    assertNotNull(result, "Split gibt kein Ergebnis zurück!");
    assertEquals("", result.getFirst());
    assertEquals("Abrakadabra", result.getSecond());
  }

  @Test
  public void shoudlSplitWithLength() {
    Pair<String, String> result = StringHelper.split("Abrakadabra", 11);
    assertNotNull(result, "Split gibt kein Ergebnis zurück!");
    assertEquals("Abrakadabra", result.getFirst());
    assertEquals("", result.getSecond());
  }


  @Test
  public void shoudlThrowWithNegative() {
    assertThrows(IllegalArgumentException.class, () -> StringHelper.split("Abrakadabra", -3));
  }

  @Test
  public void shoudlThrowWithMoreThanLength() {
    assertThrows(IllegalArgumentException.class, () -> StringHelper.split("Abrakadabra", 12));
  }

  @Test
  public void shoudlThrowWithNull() {
    assertThrows(IllegalArgumentException.class, () -> StringHelper.split(null, 0));
  }

}
