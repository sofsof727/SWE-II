package edu.hm.cs.bka.dev2.decision;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DecisionDiceTest {

    @Test
    @Order(1)
    public void testDecisionDiceGeneric() throws NoSuchMethodException, SecurityException {
        Class<?> c = DecisionDice.class;
        TypeVariable<?>[] typeParameters = c.getTypeParameters();
        assertEquals( 1, typeParameters.length, "DecisionDice sollte generisch sein!");

        Method m = c.getDeclaredMethod("pick");
        Type rt = m.getGenericReturnType();
        assertEquals(typeParameters[0], rt, "Methode pick muss generischen Typ zurückgeben");
    }
}
