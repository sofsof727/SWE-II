package edu.hm.cs.bka.dev2.zoo;

import static org.junit.jupiter.api.Assertions.assertEquals;


import edu.hm.cs.bka.dev2.zoo.gehege.*;
import edu.hm.cs.bka.dev2.zoo.tiere.Raubkatze;
import edu.hm.cs.bka.dev2.zoo.tiere.Tier;
import edu.hm.cs.bka.dev2.zoo.tiere.Vogel;
import edu.hm.cs.bka.dev2.zoo.tiere.Wild;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import org.junit.jupiter.api.Test;

public class ZooTest {

  @Test
  public void testGehege() throws NoSuchMethodException, SecurityException {
    Class<?> c = Gehege.class;
    TypeVariable<?>[] typeParameters = c.getTypeParameters();
    assertEquals(1, typeParameters.length, "Gehege sollte generisch sein!");
    assertEquals(Tier.class.getCanonicalName(),
        typeParameters[0].getBounds()[0].getTypeName());

    Method[] methods = c.getDeclaredMethods();
    Method schliesseEin = null;
    Method lasseFrei = null;
    for (Method m : methods) {
      if (m.getName().equals("schliesseEin")) {
        schliesseEin = m;
      } else if (m.getName().equals("lasseFrei")) {
        lasseFrei = m;
      }
    }

    Type rt = schliesseEin.getGenericParameterTypes()[0];
    assertEquals(typeParameters[0], rt, "schliesseEin sollte generischen Typ zurückgeben.");

    rt = lasseFrei.getGenericParameterTypes()[0];
    assertEquals(typeParameters[0], rt, "lasseFrei sollte generischen Typ zurückgeben.");
  }

  @Test
  public void testKaefig() throws NoSuchMethodException, SecurityException {
    Class<?> c = Kaefig.class;
    TypeVariable<?>[] typeParameters = c.getTypeParameters();
    assertEquals(1, typeParameters.length, "Kaefig sollte generisch sein!");
    assertEquals(Tier.class.getCanonicalName(),
        typeParameters[0].getBounds()[0].getTypeName());

    assertEquals(0, c.getDeclaredMethods().length,
        "Gehegearten sollten keine neuen Methoden implementieren oder überschreiben");

  }

  @Test
  public void testVoliere() throws NoSuchMethodException, SecurityException {
    Class<?> c = Voliere.class;
    TypeVariable<?>[] typeParameters = c.getTypeParameters();
    assertEquals(1, typeParameters.length, "Voliere sollte generisch sein!");
    assertEquals(Vogel.class.getCanonicalName(), typeParameters[0].getBounds()[0].getTypeName());

    assertEquals(0, c.getDeclaredMethods().length,
        "Gehegearten sollten keine neuen Methoden implementieren oder überschreiben");

  }

  @Test
  public void testRaubkatzenKaefig() throws NoSuchMethodException, SecurityException {
    Class<?> c = RaubkatzenKaefig.class;
    TypeVariable<?>[] typeParameters = c.getTypeParameters();
    assertEquals(1, typeParameters.length, "RaubkatzenKaefig sollte generisch sein!");
    assertEquals(Raubkatze.class.getCanonicalName(),
        typeParameters[0].getBounds()[0].getTypeName());

    assertEquals(0, c.getDeclaredMethods().length,
        "Gehegearten sollten keine neuen Methoden implementieren oder überschreiben");

  }

  @Test
  public void testWildgehege() throws NoSuchMethodException, SecurityException {
    Class<?> c = Wildgehege.class;
    TypeVariable<?>[] typeParameters = c.getTypeParameters();
    assertEquals(1, typeParameters.length, "Wildgehege sollte generisch sein!");
    assertEquals(Wild.class.getCanonicalName(),
        typeParameters[0].getBounds()[0].getTypeName());

    assertEquals(0, c.getDeclaredMethods().length,
        "Gehegearten sollten keine neuen Methoden implementieren oder überschreiben");

  }
}
