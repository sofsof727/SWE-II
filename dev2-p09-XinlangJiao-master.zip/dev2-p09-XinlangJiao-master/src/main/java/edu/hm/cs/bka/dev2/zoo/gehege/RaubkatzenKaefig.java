package edu.hm.cs.bka.dev2.zoo.gehege;

import edu.hm.cs.bka.dev2.zoo.tiere.Tier;

/**
 * Klasse für Raubkatzenkäfige.
 */
public class RaubkatzenKaefig extends Kaefig {

  /**
   * Konstruktor.
   *
   * @param tiere einzusperrende Tiere, darf null enthalten für freie Plätze
   */
  public RaubkatzenKaefig(Tier[] tiere) {
    super(tiere);
  }
}
