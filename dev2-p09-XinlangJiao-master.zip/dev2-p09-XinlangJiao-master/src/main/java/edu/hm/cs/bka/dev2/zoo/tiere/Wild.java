package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Abstrakte Klasse für Wild.
 */
public abstract class Wild extends Tier {

  public Wild(String name) {
    super(name);
  }

}
