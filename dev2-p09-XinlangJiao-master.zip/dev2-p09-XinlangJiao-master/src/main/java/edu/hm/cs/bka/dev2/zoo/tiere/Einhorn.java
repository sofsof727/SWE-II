package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Einhörner.
 */
public final class Einhorn extends Wild {

  public Einhorn(String name) {
    super(name);
  }

}
