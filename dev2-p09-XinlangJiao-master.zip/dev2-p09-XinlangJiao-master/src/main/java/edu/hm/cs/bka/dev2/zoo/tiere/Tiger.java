package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Tiger.
 */
public final class Tiger extends Raubkatze {

  public Tiger(String name) {
    super(name);
  }

}
