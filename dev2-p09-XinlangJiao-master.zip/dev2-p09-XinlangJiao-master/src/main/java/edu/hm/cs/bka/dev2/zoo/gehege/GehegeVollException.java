package edu.hm.cs.bka.dev2.zoo.gehege;

/**
 * Exception, die ein volles Gehege signalisiert.
 */
public class GehegeVollException extends Exception {

  public GehegeVollException(String msg) {
    super(msg);
  }

}
