package edu.hm.cs.bka.dev2.decision;

/**
 * Beispielcode für Generics-Warm-Up.
 */
public class Demo {

  /**
   * Beispielprogramm zur Nutzung der Klasse DecisionDice.
   *
   * @param args nicht genutzt
   */
  public static void main(String[] args) {

    // Die auskommentierten Zeilen sollen so, wie sie dastehen
    // funktionieren, wenn Sie die Klasse DecisionDice korrigiert haben!

    System.out.print("Sollte ich mehr üben?  -- ");
    String[] antworten = {"Ja", "Nein", "Vielleicht", "Weiß nicht",
        "Was würde Herr Katz tun?"};
    // DecisionDice<String> advice = new DecisionDice<String>(antworten);
    // String myAdvice = advice.pick(); // Sollte ohne Typumwandlung gehen!
    // System.out.println(myAdvice); // Zufällige Wahl

    System.out.print("Was bekomme ich in SWE2?  -- ");
    Double[] noten = {1.0, 1.3, 1.7, 2.0, 2.3, 2.7, 3.0, 3.3, 3.7, 4.0, 5.0};
    // DecisionDice<Double> oracle = new DecisionDice<Double>(noten);
    // Double forecast = oracle.pick(); // Sollte ohne Typumwandlung gehen!
    // System.out.println(forecast); // Zufällige Wahl

    /* Optionaler Teil */

    String[] tatorte = {"Küche", "Musikzimmer", "Bibliothek", "Salon"};
    String[] tatwaffen = {"Kerzenleuchter", "Dolch", "Rohrzange"};
    // DoubleDecisionDice<String, String> dice = new DoubleDecisionDice<String, String>(tatorte,
    //         tatwaffen);
    // Pair<String, String> ergebnis = dice.pick();
    // System.out.println(ergebnis);

  }
}
