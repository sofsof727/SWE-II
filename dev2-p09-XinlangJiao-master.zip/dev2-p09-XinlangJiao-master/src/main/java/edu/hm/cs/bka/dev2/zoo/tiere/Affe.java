package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Affen.
 */
public final class Affe extends Tier {

  public Affe(String name) {
    super(name);
  }

}
