package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Löwen.
 */
public final class Loewe extends Raubkatze {

  public Loewe(String name) {
    super(name);
  }

}
