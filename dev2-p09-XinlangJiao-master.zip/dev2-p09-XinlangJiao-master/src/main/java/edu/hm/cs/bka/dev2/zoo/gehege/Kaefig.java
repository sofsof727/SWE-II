package edu.hm.cs.bka.dev2.zoo.gehege;


import edu.hm.cs.bka.dev2.zoo.tiere.Tier;

/**
 * Klasse für Käfige.
 */
public class Kaefig extends Gehege {

  /**
   * Konstruktor.
   *
   * @param tiere einzusperrende Tiere, darf null enthalten für freie Plätze
   */
  public Kaefig(Tier[] tiere) {
    super(tiere);
  }
}
