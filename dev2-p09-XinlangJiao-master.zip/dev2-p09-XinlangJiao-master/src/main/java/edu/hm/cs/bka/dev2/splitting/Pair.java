package edu.hm.cs.bka.dev2.splitting;

/**
 * Klasse zur Rückgabe von zwei Werten.
 *
 * @param <L> Typ des ersten Elements
 * @param <R> Typ des zweiten Elements
 */
public class Pair<L, R> {
  private final L first;
  private final R second;

  /**
   * Konstruktor.
   *
   * @param first  erster Wert
   * @param second zweiter Wert
   */
  public Pair(L first, R second) {
    this.first = first;
    this.second = second;
  }

  /**
   * Liefert den ersten Teil des Paares zurück.
   *
   * @return erster Teil
   */
  public L getFirst() {
    return first;
  }

  /**
   * Liefert den zweiten Teil des Paares zurück.
   *
   * @return zweiter Teil
   */
  public R getSecond() {
    return second;
  }

  @Override
  public String toString() {
    return "[" + first + "/" + second + "]";
  }
}
