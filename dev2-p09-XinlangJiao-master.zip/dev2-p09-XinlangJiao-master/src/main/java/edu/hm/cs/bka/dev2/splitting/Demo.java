package edu.hm.cs.bka.dev2.splitting;

/**
 * Beispielcode für String-Splitting.
 */
public class Demo {

  /**
   * Beispielprogramm zur Nutzung der String-Split-Funktion.
   *
   * @param args ungenutzt
   */
  public static void main(String[] args) {

    // Sollte so funktionieren!
    Pair<String, String> result = StringHelper.split("Abrakadabra", 5);
    System.out.println(result.getFirst()); // Abrak
    System.out.println(result.getSecond()); // adabra

  }
}
