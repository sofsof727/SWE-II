package edu.hm.cs.bka.dev2.zoo;

import edu.hm.cs.bka.dev2.zoo.gehege.GehegeVollException;
import edu.hm.cs.bka.dev2.zoo.gehege.RaubkatzenKaefig;
import edu.hm.cs.bka.dev2.zoo.gehege.Voliere;
import edu.hm.cs.bka.dev2.zoo.gehege.Wildgehege;
import edu.hm.cs.bka.dev2.zoo.tiere.*;

/**
 * Beispielcode für Aufgabe 25.
 */
public class ZooDemo {

  /**
   * Beispielcode.
   *
   * @param args nicht verwendet
   */
  @SuppressWarnings("unused")
  public static void main(String[] args) throws GehegeVollException {

    // Den folgenden Beispielcode müssen Sie auch anpassen!

    /* Beispiel 1: Sperre Papageien ein und lasse sie frei */
    Papagei[] papageien = {new Papagei("Lora"), new Papagei("Rory")};
    Voliere papageienVoliere = new Voliere(papageien);
    papageienVoliere.lasseFrei(papageien[0]);
    papageienVoliere.schliesseEin(new Papagei("Rio"));
    System.out.println(papageienVoliere); // Belegung: Rio Rory

    /* Beispiel 2: Erstelle Wildgehege mit fünf Plätzen und zwei Hirschen, Bambi und Feline */
    Hirsch[] hirsche = {new Hirsch("Bambi"), new Hirsch("Feline"), null, null, null, null};
    Wildgehege hirschGehege = new Wildgehege(hirsche);
    System.out.println(hirschGehege);

    /* Beispiel 3: Erstelle einen RaubkatzenKaefig für drei Tiger und einen für drei Loewen */
    Tiger[] tiger = {new Tiger("Shir Khan"), null, null};
    Loewe[] loewe = {new Loewe("Simba"), null, null};
    RaubkatzenKaefig tigerKaefig = new RaubkatzenKaefig(tiger);
    RaubkatzenKaefig loewenKaefig = new RaubkatzenKaefig(loewe);
    System.out.println(tigerKaefig);
    System.out.println(loewenKaefig);

    // Das hier sollte nicht gehen, geht aber (noch). Bitte später löschen
    Tier[] tiere = {new Einhorn("Pinky Pie"), new Loewe("Simba"), new Affe("Louis")};
    Wildgehege gehege = new Wildgehege(tiere);
  }
}
