package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Hirsche.
 */
public final class Hirsch extends Wild {

  public Hirsch(String name) {
    super(name);
  }
}
