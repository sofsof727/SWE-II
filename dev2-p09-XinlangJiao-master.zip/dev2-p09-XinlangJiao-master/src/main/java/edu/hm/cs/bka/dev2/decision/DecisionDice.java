package edu.hm.cs.bka.dev2.decision;

import java.util.Random;

/**
 * Hilfsklasse mit statischen Methoden zur zufälligen Auswahl aus einem Array mit Optionen.
 */
public final class DecisionDice {

  // Zufallszahlengenerator
  private static final Random RANDOM = new Random();

  private final Object[] options;

  /**
   * Konstruktor.
   *
   * @param options Auswahlmöglichkeiten
   */
  public DecisionDice(Object[] options) {
    this.options = options.clone();
  }

  /**
   * Liefert eine zufällige Option.
   *
   * @return zufällige Auswahl aus den Optionen
   */
  public Object pick() {
    return options[RANDOM.nextInt(options.length)];
  }

}
