package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Abstrakte Oberklasse für Vögel.
 */
public abstract class Vogel extends Tier {

  public Vogel(String name) {
    super(name);
  }

}
