package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Abstrakte Oberklasse für alle Tiere.
 */
public abstract class Tier {
  private final String name;

  public Tier(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  @Override
  public String toString() {
    return name;
  }
}
