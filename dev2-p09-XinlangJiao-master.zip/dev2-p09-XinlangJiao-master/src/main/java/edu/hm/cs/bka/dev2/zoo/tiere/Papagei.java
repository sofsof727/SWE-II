package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Klasse für Papageien.
 */
public final class Papagei extends Vogel {

  public Papagei(String name) {
    super(name);
  }

}
