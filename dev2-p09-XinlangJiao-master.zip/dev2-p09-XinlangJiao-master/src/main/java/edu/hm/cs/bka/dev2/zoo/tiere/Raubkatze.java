package edu.hm.cs.bka.dev2.zoo.tiere;

/**
 * Abstrakte Oberklasse für Raubkatzen.
 */
public abstract class Raubkatze extends Tier {

  public Raubkatze(String name) {
    super(name);
  }

}
