package edu.hm.cs.bka.dev2.liedgut;

/**
 * Sperling.
 */
public final class Sperling extends Vogel {
  @Override
  protected String liefereBezeichnung() {
    return "der Sperling";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der bringt der Braut den Trauring";
  }
}
