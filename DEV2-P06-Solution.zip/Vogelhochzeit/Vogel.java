package edu.hm.cs.bka.dev2.liedgut;

/**
 * Basisklasse für alle Vögel.
 */
public abstract class Vogel {

  /**
   * Gibt die zwei Anfangsstrophen der Vogelhochzeit aus.
   */
  public final void singeAnfang() {
    System.out.println("Ein Vogel wollte Hochzeit machen in dem grünen Walde.");
    singeRefrain();
    System.out.println("Die Drossel war der Bräutigam, die Amsel war die Braute.");
    singeRefrain();
  }

  /**
   * Gibt die zum Vogel passende Strophe aus.
   */
  public void singeStrophe() {
    String bez = liefereBezeichnung();
    System.out.println(bez.substring(0, 1).toUpperCase() + bez.substring(1) + ", " + bez + ", "
        + liefereBeschreibung() + ".");
    singeRefrain();
  }

  /**
   * Bezeichnung des Vogels.
   *
   * @return Bezeichung des Vogels, z.B. "der Hahn"
   */
  protected abstract String liefereBezeichnung();

  /**
   * Beschreibender Halbsatz.
   *
   * @return liefere Bschreibung, z.B. "die bracht die Braut zur Kerche"
   */
  protected abstract String liefereBeschreibung();

  /**
   * Gibt die Endstrophe der Vogelhochzeit aus.
   */
  public final void singeEnde() {
    System.out.println("Die Vogelhochzeit ist nun aus, die Vögel fliegen all nach Haus.");
    singeRefrain();
  }

  /**
   * Gibt de Refrain aus.
   */
  protected final void singeRefrain() {
    System.out.println("Fiderallala, Fiderallala, Fiderallalalala.");
  }

}
