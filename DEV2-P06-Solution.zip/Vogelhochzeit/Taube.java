package edu.hm.cs.bka.dev2.liedgut;

/**
 * Taube.
 */
public final class Taube extends Vogel {
  @Override
  protected String liefereBezeichnung() {
    return "die Taube";
  }

  @Override
  protected String liefereBeschreibung() {
    return "die bringt der Braut die Haube";
  }
}
