package edu.hm.cs.bka.dev2.liedgut;

/**
 * Beispielanwendung zur Ausgabe der Vogelhochzeit mit abstrakten Methode.
 *
 * @author katz.bastian
 */
public class Vogelhochzeit {

  /**
   * Main-Methode. Gibt das Lied <i>Die Vogelhochzeit</i> aus.
   *
   * @param args Kommandozeilen-Parameter
   */
  public static void main(String[] args) {

    // Erweitern/Umsortieren dieses Arrays fuehrt zu Variationen
    Vogel[] voegel = {new Sperber(), new Star(), new Lerche(), new Auerhahn(),
        new Seidenschwanz(), new Sperling(),
        new Uhu("der bringt der Braut die Hochzeitsschuh"), new Taube(), new Wiedehopf(),
        new Pfau(), new Hahn(), new Kuckuck(), new Eule()};

    // Der erste Vogel singt den Anfang
    voegel[0].singeAnfang();

    // Jeder Vogel singt "seine" Strophe
    for (int i = 0; i < voegel.length; i++) {
      Vogel vogel = voegel[i];
      // Ein Hahn ? Tausche mit dem letzten Vogel !
      // Bedingung muss ergaenzt werden !
      if (voegel[i] instanceof Hahn) {
        voegel[i] = voegel[voegel.length - 1];
        voegel[voegel.length - 1] = vogel;
        vogel = voegel[i];
      }
      vogel.singeStrophe();
    }

    // Der letzte Vogel singt das Ende
    voegel[voegel.length - 1].singeEnde();
  }

}
