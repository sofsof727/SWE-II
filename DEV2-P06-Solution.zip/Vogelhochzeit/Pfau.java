package edu.hm.cs.bka.dev2.liedgut;

/**
 * Pfau.
 */
public final class Pfau extends Vogel {
  @Override
  public void singeStrophe() {
    String bez = liefereBezeichnung();
    System.out.println(bez.substring(0, 1).toUpperCase() + bez.substring(1)
        + " mit seinem bunten Schwanz " + liefereBeschreibung() + ".");
    singeRefrain();
  }

  @Override
  protected String liefereBezeichnung() {
    return "der Pfau";
  }

  @Override
  protected String liefereBeschreibung() {
    return "macht mit der Braut den ersten Tanz";
  }
}
