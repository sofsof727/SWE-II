package edu.hm.cs.bka.dev2.liedgut;

/**
 * Hahn.
 */
public final class Hahn extends Vogel {

  @Override
  public void singeStrophe() {
    String bez = liefereBezeichnung();
    System.out.println(bez.substring(0, 1).toUpperCase() + bez.substring(1) + ", "
        + liefereBeschreibung() + ".");
    singeRefrain();
  }

  @Override
  protected String liefereBezeichnung() {
    return "der Hahn";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der krähet: Gute Nacht, nun wird die Kammer zugemacht";
  }
}
