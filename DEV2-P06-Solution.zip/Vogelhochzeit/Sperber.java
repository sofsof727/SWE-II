package edu.hm.cs.bka.dev2.liedgut;

/**
 * Sperber.
 */
public final class Sperber extends Vogel {

  @Override
  protected String liefereBezeichnung() {
    return "der Sperber";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der war der Hochzeitswerber";
  }
}
