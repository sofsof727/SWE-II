package edu.hm.cs.bka.dev2.liedgut;

/**
 * Star.
 */
public final class Star extends Vogel {
  @Override
  protected String liefereBezeichnung() {
    return "der Stare";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der flocht der Braut die Haare";
  }
}
