package edu.hm.cs.bka.dev2.liedgut;

/**
 * Seidenschwanz.
 */
public final class Seidenschwanz extends Vogel {
  @Override
  protected String liefereBezeichnung() {
    return "der Seidenschwanz";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der bracht der Braut den Hochzeitskranz";
  }
}
