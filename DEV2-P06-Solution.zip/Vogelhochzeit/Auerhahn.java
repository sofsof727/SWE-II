package edu.hm.cs.bka.dev2.liedgut;

/**
 * Auerhahn.
 */
public final class Auerhahn extends Vogel {

  @Override
  public String liefereBezeichnung() {
    return "der Auerhahn";
  }

  @Override
  public String liefereBeschreibung() {
    return "der ist der würdge Herr Kaplan";
  }

}
