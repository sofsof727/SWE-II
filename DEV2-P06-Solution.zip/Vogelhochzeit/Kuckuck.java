package edu.hm.cs.bka.dev2.liedgut;

/**
 * Kuckuck.
 */
public final class Kuckuck extends Vogel {

  @Override
  public void singeStrophe() {
    String bez = liefereBezeichnung();
    System.out.println(bez.substring(0, 1).toUpperCase() + bez.substring(1) + " schreit, " + bez
        + " schreit, " + liefereBeschreibung() + ".");
    singeRefrain();
  }

  @Override
  protected String liefereBezeichnung() {
    return "der Kuckuck";
  }

  @Override
  protected String liefereBeschreibung() {
    return "er bringt der Braut das Hochzeitskleid";
  }

}
