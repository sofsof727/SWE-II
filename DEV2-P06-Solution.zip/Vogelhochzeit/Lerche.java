package edu.hm.cs.bka.dev2.liedgut;

/**
 * Lerche.
 */
public final class Lerche extends Vogel {

  @Override
  protected String liefereBezeichnung() {
    return "die Lerche";
  }

  @Override
  protected String liefereBeschreibung() {
    return "die führt die Braut zur Kerche";
  }
}
