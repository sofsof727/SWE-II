package edu.hm.cs.bka.dev2.liedgut;

/**
 * Wiedehopf.
 */
public final class Wiedehopf extends Vogel {
  @Override
  protected String liefereBezeichnung() {
    return "der Wiedehopf";
  }

  @Override
  protected String liefereBeschreibung() {
    return "der bringt der Braut nen Blumentopf";
  }
}
