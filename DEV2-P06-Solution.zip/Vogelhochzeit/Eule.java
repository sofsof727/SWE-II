package edu.hm.cs.bka.dev2.liedgut;

/**
 * Eule.
 */
public final class Eule extends Vogel {
  @Override
  public void singeStrophe() {
    System.out.println(
        "Brautmutter war " + liefereBezeichnung() + ", " + liefereBeschreibung() + ".");
    singeRefrain();
  }

  @Override
  protected String liefereBezeichnung() {
    return "die Eule";
  }

  @Override
  protected String liefereBeschreibung() {
    return "nahm Abschied mit Geheule";
  }

}
