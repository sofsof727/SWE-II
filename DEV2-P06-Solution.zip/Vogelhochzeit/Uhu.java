package edu.hm.cs.bka.dev2.liedgut;

/**
 * Uhu.
 */
public final class Uhu extends Vogel {
  private final String beschreibung;

  public Uhu(String beschreibung) {
    this.beschreibung = beschreibung;
  }

  @Override
  protected String liefereBezeichnung() {
    return "der Uhu";
  }

  @Override
  protected String liefereBeschreibung() {
    return beschreibung;
  }
}
