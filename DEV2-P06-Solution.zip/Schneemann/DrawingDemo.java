package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

/**
 * Klasse mit Beispielverwendung von Geometrischen Objekten.
 */
public class DrawingDemo {

  /**
   * Demo zur Ausrichtung von Objekten.
   *
   * @param args nicht verwendet
   */
  public static void main(String[] args) {

    // Array mit den Objekten, die wir zeichnen wollen!
    GeometricObject[] d = new GeometricObject[] {
        new Circle(Color.BLACK, new Point(100, 600), 60),
        new Circle(Color.WHITE, new Point(100, 75), 80),
        new Circle(Color.RED, new Point(100, 20), 10),
        new edu.hm.cs.bka.dev2.snowman.Rectangle(Color.BLUE, new Point(90, 120),
            new Point(110, 140)),
        new edu.hm.cs.bka.dev2.snowman.Rectangle(Color.BLUE, new Point(150, 80),
            new Point(170, 100)),
        new edu.hm.cs.bka.dev2.snowman.Rectangle(Color.GRAY, new Point(40, 50), new Point(160, 60)),
        new Rectangle(Color.GRAY, new Point(60, 110), new Point(140, 150))
    };

    // Einkommentieren, wenn die Methoden existieren & implementiert sind!
    d[2].alignTop(d[6]);
    d[6].alignBottom(d[5]);
    d[4].alignLeft(d[6]);
    d[3].alignTop(d[4]);
    d[3].alignRight(d[6]);
    d[0].alignTop(d[5]);

    BufferedImage image = createImage();

    for (Drawable dd : d) {
      dd.draw(image.createGraphics());
    }

    createFrame(image);

  }

  /* In diesem Teil müssen Sie nichts ändern! */

  /**
   * Zeichnet das Fenster mit dem Bild.
   *
   * @param image Bild
   */
  private static void createFrame(Image image) {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.setTitle("Schneemann");
    frame.setLocation(500, 300);
    JPanel imagePanel = new JPanel() {
      public void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, 200, 200, 0, 0, 200, 200, null);
      }
    };
    frame.add(imagePanel);
    imagePanel.setPreferredSize(new Dimension(200, 200));
    frame.pack();
    frame.setVisible(true);

  }

  /**
   * Erstellt ein Bild zum Zeichnen.
   *
   * @return Bild
   */
  private static BufferedImage createImage() {
    BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_ARGB);

    Graphics2D g2 = image.createGraphics();
    g2.setBackground(Color.WHITE);
    g2.clearRect(0, 0, 200, 200);
    return image;
  }
}
