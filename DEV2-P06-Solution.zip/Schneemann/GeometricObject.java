package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;

/**
 * Klasse fuer geometrische Objekte.
 */
public abstract class GeometricObject implements Drawable {

  private final Color color;

  public GeometricObject(Color color) {
    this.color = color;
  }

  public Color getColor() {
    return color;
  }

  /**
   * Verschiebt das Objekt.
   *
   * @param byX Verschiebung in X-Richtung
   * @param byY Verschiebung in Y-Richtung
   */
  public abstract void move(double byX, double byY);

  /**
   * Linke Grenze.
   *
   * @return minimale X-Koordinate (links)
   */
  public abstract double getMinX();

  /**
   * Obere Grenze.
   *
   * @return minimale Y-Koordinate (oben)
   */
  public abstract double getMinY();

  /**
   * Rechte Grenze.
   *
   * @return maximale X-Koordinate (rechts)
   */
  public abstract double getMaxX();

  /**
   * Untere Grenze.
   *
   * @return maximale Y-Koordinate (unten)
   */
  public abstract double getMaxY();

  public void alignLeft(GeometricObject object) {
    move(object.getMinX() - getMinX(), 0);
  }

  public void alignRight(GeometricObject object) {
    move(object.getMaxX() - getMaxX(), 0);
  }

  public void alignBottom(GeometricObject object) {
    move(0, object.getMaxY() - getMaxY());
  }

  public void alignTop(GeometricObject object) {
    move(0, object.getMinY() - getMinY());
  }

}


