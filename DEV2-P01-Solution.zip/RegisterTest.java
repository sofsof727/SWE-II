package edu.hm.cs.bka.dev2.kasse;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link Register}.
 */
public class RegisterTest {

  @Test
  public void shouldHaveSumZeroAfterInitialization() {
    // Given
    Register register = new Register();

    // When
    int actual = register.getSum();

    // Then
    assertEquals(0, actual);
  }

  @Test
  public void shouldHaveAddedValueAfterSingleAddition() {
    // Given
    Register register = new Register();

    // When
    register.add(17);

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  public void shouldHaveCorrectSumAfterMultipleAdditions() {
    // Given
    Register register = new Register();

    // When
    register.add(17);
    register.add(12);

    // Then
    int actual = register.getSum();
    assertEquals(29, actual);
  }

  @Test
  public void shouldResetCorrectly() {
    // Given
    Register register = new Register();
    register.add(17);

    // When
    register.reset();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  public void shouldNotRepeatAfterStorno() {
    // Given
    Register register = new Register();
    register.add(17);

    // When
    register.storno();
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }


  @Test
  public void shouldNotStornoAfterStorno() {
    // Given
    Register register = new Register();
    register.add(17);
    register.add(12);

    // When
    register.storno();
    register.storno();

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  public void shouldNotStornoAfterReset() {
    // Given
    Register register = new Register();
    register.add(17);
    register.add(12);

    // When
    register.reset();
    register.storno();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  public void shouldNotRepeatAfterReset() {
    // Given
    Register register = new Register();
    register.add(17);
    register.add(12);

    // When
    register.reset();
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  public void shouldNotAddNegativeValue() {
    // Given
    Register register = new Register();


    // When
    register.add(-17);

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  public void shouldNotRepeatNegativeValue() {
    // Given
    Register register = new Register();
    register.add(20);
    // When
    register.add(-3);
    register.repeat();

    // Then
    int actual = register.getSum();

    assertEquals(20, actual);
  }

  @Test
  public void shouldNotStornoNegativeValue() {
    // Given
    Register register = new Register();
    register.add(20);

    // When
    register.add(-3);
    register.storno();

    // Then
    int actual = register.getSum();
    assertEquals(20, actual);
  }

  @Test
  public void shouldNotRepeatAfterInitialization() {
    // Given
    Register register = new Register();

    // When
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }
}
