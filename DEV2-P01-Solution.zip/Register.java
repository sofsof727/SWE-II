package edu.hm.cs.bka.dev2.kasse;

/**
 * Implementierung einer kleinen Kasse.
 */
public class Register {
  // aktuelle Summe
  int sum;

  // letzte Erhoehung (fuer repeat oder storno).
  int last;

  /**
   * Liefert den Wert der Kasse.
   *
   * @return Aktueller Wert der Kasse
   */
  public int getSum() {
    return sum;
  }

  /**
   * Fügt einen Wert hinzu.
   *
   * @param value Erhopehung. Negative Werte werden wie Null behandelt.
   */
  public void add(final int value) {
    if (value > 0) {
      sum += value;
      last = value;
    } else {
      last = 0;
    }
  }

  /**
   * Wiederholt die letzte Erhoehung.
   */
  public void repeat() {
    sum += last;
  }

  /**
   * Macht eine direkt vorangegangene Erhoehung rueckgaengig. Danach sind weitere Repeat- oder
   * Storno-Operationen bis zur naechsten Erhoehung wirkungslos.
   */
  public void storno() {
    sum -= last;
    last = 0;
  }

  /**
   * Setzt das Objekt wieder in den Ausgangszustand zurueck.
   */
  public void reset() {
    sum = 0;
    last = 0;
  }
}
