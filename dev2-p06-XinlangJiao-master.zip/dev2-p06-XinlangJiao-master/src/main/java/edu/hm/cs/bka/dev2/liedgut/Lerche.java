package edu.hm.cs.bka.dev2.liedgut;

/**
 * Lerche.
 */
public class Lerche extends Vogel {

}
