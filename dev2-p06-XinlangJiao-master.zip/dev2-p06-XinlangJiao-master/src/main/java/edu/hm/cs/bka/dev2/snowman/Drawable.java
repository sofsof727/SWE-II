package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;

/**
 * Schnittstelle fuer Objekte, die sich selbst zeichnen koennen.
 */
public interface Drawable {

  void draw(Graphics2D graphics);

}
