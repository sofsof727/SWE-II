package edu.hm.cs.bka.dev2.liedgut;

/**
 * Taube.
 */
public class Taube extends Vogel {

}
