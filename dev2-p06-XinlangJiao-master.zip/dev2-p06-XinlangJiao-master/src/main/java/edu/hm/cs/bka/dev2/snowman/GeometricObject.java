package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;

/**
 * Klasse fuer geometrische Objekte.
 */
public abstract class GeometricObject implements Drawable {

  private final Color color;

  public GeometricObject(Color color) {
    this.color = color;
  }

  public Color getColor() {
    return color;
  }
}


