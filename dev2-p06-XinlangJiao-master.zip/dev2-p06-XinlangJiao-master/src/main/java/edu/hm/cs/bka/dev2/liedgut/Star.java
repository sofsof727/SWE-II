package edu.hm.cs.bka.dev2.liedgut;

/**
 * Star.
 */
public class Star extends Vogel {

}
