package edu.hm.cs.bka.dev2.liedgut;

/**
 * Sperling.
 */
public class Sperling extends Vogel {

}
