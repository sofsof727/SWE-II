package edu.hm.cs.bka.dev2.liedgut;

/**
 * Basisklasse für alle Vögel.
 */
public abstract class Vogel {

  /**
   * Gibt die zwei Anfangsstrophen der Vogelhochzeit aus.
   */
  public void singeAnfang() {
    System.out.println("[Anfang]");
  }

  /**
   * Gibt die zum Vogel passende Strophe aus.
   */
  public void singeStrophe() {
    System.out.println("[Strophe]");
  }

  /**
   * Gibt die Endstrophe der Vogelhochzeit aus.
   */
  public void singeEnde() {
    System.out.println("[Ende]");
  }

  public void singeRefrain() {
    // TODO: benötigt für Refrain
  }
}
