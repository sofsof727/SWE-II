package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;

/**
 * Klasse für Kreise.
 */
public class Circle extends GeometricObject {

  private final Point center;
  private final double radius;

  /**
   * Konstruktor.
   *
   * @param color  Farbe
   * @param center Mittelpunkt
   * @param radius Radius
   */
  public Circle(Color color, Point center, double radius) {
    super(color);
    this.center = center;
    this.radius = radius;
  }

  public Point getCenter() {
    return center;
  }

  @Override
  public void draw(Graphics2D graphics) {
    graphics.setColor(getColor());
    graphics
        .fillArc((int) (center.getX() - radius), (int) (center.getY() - radius), (int) radius * 2,
            (int) radius * 2, 0, 360);
  }

}
