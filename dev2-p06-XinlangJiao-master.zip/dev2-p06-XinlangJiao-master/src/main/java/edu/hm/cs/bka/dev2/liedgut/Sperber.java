package edu.hm.cs.bka.dev2.liedgut;

/**
 * Sperber.
 */
public class Sperber extends Vogel {

}
