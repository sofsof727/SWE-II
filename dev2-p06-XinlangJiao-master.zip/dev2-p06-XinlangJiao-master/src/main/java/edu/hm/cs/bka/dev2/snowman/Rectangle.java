package edu.hm.cs.bka.dev2.snowman;

import java.awt.*;

/**
 * Klasse für Dreiecke.
 */
public class Rectangle extends GeometricObject {

  private final Point upperLeft;
  private final Point lowerRight;

  /**
   * Konstruktor.
   *
   * @param color      Farbe
   * @param upperLeft  obere, linke Ecke (kleinste Werte für x und y)
   * @param lowerRight untere, rechte Ecke (große Werte für x und y)
   */
  public Rectangle(Color color, Point upperLeft, Point lowerRight) {
    super(color);
    // Besser wäre hier eine Überprüfung der relativen Positionen!
    this.upperLeft = upperLeft;
    this.lowerRight = lowerRight;
  }

  public Point getUpperLeft() {
    return upperLeft;
  }

  public Point getLowerRight() {
    return lowerRight;
  }

  @Override
  public void draw(Graphics2D graphics) {
    graphics.setColor(getColor());
    int x = (int) Math.min(upperLeft.getX(), lowerRight.getX());
    int width = (int) Math.abs(upperLeft.getX() - lowerRight.getX());
    int y = (int) Math.min(upperLeft.getY(), lowerRight.getY());
    int height = (int) Math.abs(upperLeft.getY() - lowerRight.getY());
    graphics.fillRect(x, y, width, height);
  }
}
