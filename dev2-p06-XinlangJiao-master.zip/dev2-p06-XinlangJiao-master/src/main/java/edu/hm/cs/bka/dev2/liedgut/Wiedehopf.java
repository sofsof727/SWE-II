package edu.hm.cs.bka.dev2.liedgut;

/**
 * Wiedehopf.
 */
public class Wiedehopf extends Vogel {

}
