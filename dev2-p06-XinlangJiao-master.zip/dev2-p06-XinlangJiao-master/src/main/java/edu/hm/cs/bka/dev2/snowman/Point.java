package edu.hm.cs.bka.dev2.snowman;

/**
 * Sehr einfache Klasse für Punkte in 2D.
 */
public class Point {

  private double xvalue;
  private double yvalue;

  public Point(double x, double y) {
    this.xvalue = x;
    this.yvalue = y;
  }

  public double getX() {
    return xvalue;
  }

  public double getY() {
    return yvalue;
  }

  public void setX(final double x) {
    this.xvalue = x;
  }

  public void setY(final double y) {
    this.yvalue = y;
  }
}
