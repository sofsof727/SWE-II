package edu.hm.cs.bka.dev2.liedgut;

/**
 * Seidenschwanz.
 */
public class Seidenschwanz extends Vogel {

}
