package edu.hm.cs.bka.dev2.liedgut;

/**
 * Beispielanwendung zur Ausgabe der Vogelhochzeit mit abstrakten Methode.
 *
 * @author katz.bastian
 */
public class Vogelhochzeit {

  /**
   * Main-Methode. Gibt das Lied <i>Die Vogelhochzeit</i> aus.
   *
   * @param args Kommandozeilen-Parameter
   */
  public static void main(String[] args) {

    // Erweitern/Umsortieren dieses Arrays fuehrt zu Variationen
    Vogel[] voegel = {new Sperber(), new Star(), new Lerche()};

    // Der erste Vogel singt den Anfang
    voegel[0].singeAnfang();

    // Jeder Vogel singt "seine" Strophe
    for (Vogel vogel : voegel) {
      vogel.singeStrophe();
    }

    // Der letzte Vogel singt das Ende
    voegel[voegel.length - 1].singeEnde();
  }

}
