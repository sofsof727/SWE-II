package edu.hm.cs.bka.dev2.liedgut;

/**
 * Auerhahn.
 */
public class Auerhahn extends Vogel {

}
