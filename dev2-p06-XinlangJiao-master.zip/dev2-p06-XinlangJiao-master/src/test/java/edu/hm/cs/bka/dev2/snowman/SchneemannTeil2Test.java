package edu.hm.cs.bka.dev2.snowman;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchneemannTeil2Test {

  private static final Duration TIMEOUT = Duration.ofSeconds(10);

  @Test
  @Order(1)
  public void GoHasAbstractMinXMethod() {
    Method m = assertPublicMethod(GeometricObject.class, "getMinX",
        double.class);
    if (!Modifier.isAbstract(m.getModifiers())) {
      failf("Methode getMinX in Klasse GeometricObject muss abstrakt sein!");
    }

  }

  @Test
  @Order(2)
  public void GoHasAbstractMinYMethod() {
    Method m = assertPublicMethod(GeometricObject.class, "getMinY",
        double.class);
    if (!Modifier.isAbstract(m.getModifiers())) {
      failf("Methode getMinY in Klasse GeometricObject muss abstrakt sein!");
    }
  }

  @Test
  @Order(3)
  public void GoHasAbstractMaxXMethod() {
    Method m = assertPublicMethod(GeometricObject.class, "getMaxX",
        double.class);
    if (!Modifier.isAbstract(m.getModifiers())) {
      failf("Methode getMaxX in Klasse GeometricObject muss abstrakt sein!");
    }
  }

  @Test
  @Order(4)
  public void GoHasAbstractMaxYMethod() {
    Method m = assertPublicMethod(GeometricObject.class, "getMaxY",
        double.class);
    if (!Modifier.isAbstract(m.getModifiers())) {
      failf("Methode getMaxY in Klasse GeometricObject muss abstrakt sein!");
    }
  }

  @Test
  public void shoudlCalcCorrectBorderForCircle()
      throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    Circle c = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(1.0, 4.0), 7.0);
    Method getMinX = assertPublicMethod(GeometricObject.class, "getMinX", double.class);
    Method getMinY = assertPublicMethod(GeometricObject.class, "getMinY", double.class);
    Method getMaxX = assertPublicMethod(GeometricObject.class, "getMaxX", double.class);
    Method getMaxY = assertPublicMethod(GeometricObject.class, "getMaxY", double.class);

    assertEquals(-6.0, (Double) getMinX.invoke(c), 0.1, "Berechnung von MinX bei Kreis falsch!");
    assertEquals(-3.0, (Double) getMinY.invoke(c), 0.1, "Berechnung von MinY bei Kreis falsch!");
    assertEquals(8.0, (Double) getMaxX.invoke(c), 0.1, "Berechnung von MaxX bei Kreis falsch!");
    assertEquals(11.0, (Double) getMaxY.invoke(c), 0.1, "Berechnung von MaxY bei Kreis falsch!");
  }

  @Test
  public void shoudlCalcCorrectBorderForRectangle()
      throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    edu.hm.cs.bka.dev2.snowman.Rectangle
        r = new Rectangle(Color.RED, new edu.hm.cs.bka.dev2.snowman.Point(1.0, 2.0), new Point(3.0, 4.0));
    Method getMinX = assertPublicMethod(GeometricObject.class, "getMinX", double.class);
    Method getMinY = assertPublicMethod(GeometricObject.class, "getMinY", double.class);
    Method getMaxX = assertPublicMethod(GeometricObject.class, "getMaxX", double.class);
    Method getMaxY = assertPublicMethod(GeometricObject.class, "getMaxY", double.class);

    assertEquals(1.0, (Double) getMinX.invoke(r), 0.1, "Berechnung von MinX bei Rechteck falsch!");
    assertEquals(2.0, (Double) getMinY.invoke(r), 0.1, "Berechnung von MinY bei Rechteck falsch!");
    assertEquals(3.0, (Double) getMaxX.invoke(r), 0.1, "Berechnung von MaxX bei Rechteck falsch!");
    assertEquals(4.0, (Double) getMaxY.invoke(r), 0.1, "Berechnung von MaxY bei Rechteck falsch!");
  }

}
