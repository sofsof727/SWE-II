package edu.hm.cs.bka.dev2.liedgut;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.*;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.Duration;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VogelhochzeitTeil2Test {

  private static final Duration TIMEOUT = Duration.ofSeconds(5);

  @Test
  @Order(1)
  public void test01UnterklassenSindFinal() {
    if (!Modifier.isFinal(Auerhahn.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Lerche.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Seidenschwanz.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Sperber.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Sperling.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Star.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Taube.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
    if (!Modifier.isFinal(Wiedehopf.class.getModifiers())) {
      failf("Unterklassen von Vogel dürfen keine weitere Vererbung zulassen!");
    }
  }

  @Test
  @Order(2)
  public void test02AbstractMethodLiefereBezeichnungExists() {
    Method m = null;
    try {
      m = Vogel.class.getDeclaredMethod("liefereBezeichnung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBezeichnung fehlt in Klasse Vogel.");
    }
    assertEquals(String.class,
        m.getReturnType(), "liefereBezeichnung muss String zurückliefern!");

    assertTrue(Modifier.isAbstract(m.getModifiers()),
        "liefereBezeichnung in Vogel ist nicht abstrakt!");

    assertTrue(Modifier.isProtected(m.getModifiers()),
        "liefereBezeichnung in Vogel ist nicht protected!");
  }

  @Test
  @Order(3)
  public void test03AbstractMethodLiefereBeschreibungExists() {
    Method m = null;
    try {
      m = Vogel.class.getDeclaredMethod("liefereBeschreibung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBechreibung fehlt in Klasse Vogel.");
    }
    assertEquals(String.class,
        m.getReturnType(), "liefereBeschreibung muss String zurückliefern!");

    assertTrue(Modifier.isAbstract(m.getModifiers()),
        "liefereBeschreibung in Vogel ist nicht abstrakt!");
    assertTrue(Modifier.isProtected(m.getModifiers()),
        "liefereBeschreibung in Vogel ist nicht protected!");
  }

  public static void testImplementation(Vogel v, String rhyme)
      throws Exception {
    Method beschreibung = null;
    try {
      beschreibung = Vogel.class.getDeclaredMethod("liefereBeschreibung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBechreibung() fehlt in Klasse Vogel.");
    }

    Method bezeichnung = null;
    try {
      bezeichnung = Vogel.class.getDeclaredMethod("liefereBezeichnung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBezeichnung() fehlt in Klasse Vogel.");
    }

    String n = v.getClass().getSimpleName();
    try {
      v.getClass().getDeclaredMethod("singeStrophe");
      fail("Klasse " + n + " darf singeStrophe nicht implementieren!");
    } catch (Exception e) {
      // intentionally left blank
    }

    assertTrue(bezeichnung.invoke(v).toString().contains(n),
        "Klasse " + n + " muss Bezeichnung zurückliefern.");

    assertTrue(beschreibung.invoke(v).toString().toLowerCase().contains(rhyme),
        "Klasse " + n + " muss Beschreibung zurückliefern.");

    String refrain = SystemLambda.tapSystemOutNormalized(v::singeRefrain);
    String strophe = SystemLambda.tapSystemOutNormalized(v::singeStrophe);

    assertEquals(1, StringUtils.countMatches(strophe, refrain),
        "Strophe muss Refrain einmal enthalten!");
    assertEquals(2, StringUtils.countMatches(
        strophe.toLowerCase(), bezeichnung.invoke(v).toString().toLowerCase()),
        "Strophe muss Bezeichnung zweimal enthalten!");

    assertEquals(1, StringUtils.countMatches(
        strophe.toLowerCase(), beschreibung.invoke(v).toString().toLowerCase()),
        "Strophe muss Beschreibung enthalten!");

  }

  @Test
  @Order(4)
  public void test04AuerhahnIsImplemented() throws Exception {
    testImplementation(new Auerhahn(), "herr kaplan");
  }

  @Test
  @Order(5)
  public void test05LercheIsImplemented() throws Exception {
    testImplementation(new Lerche(), "kerche");
  }

  @Test
  @Order(6)
  public void test06SeidenschwanzzIsImplemented() throws Exception {
    testImplementation(new Seidenschwanz(), "hochzeitskranz");
  }

  @Test
  @Order(7)
  public void test07SperberIsImplemented() throws Exception {
    testImplementation(new Sperber(), "werber");
  }

  @Test
  @Order(8)
  public void test08SperlingIsImplemented() throws Exception {
    testImplementation(new Sperling(), "trauring");
  }

  @Test
  @Order(9)
  public void test09StarIsImplemented() throws Exception {
    testImplementation(new Star(), "haare");
  }

  @Test
  @Order(10)
  public void test10TaubeIsImplemented() throws Exception {
    testImplementation(new Taube(), "haube");
  }

  @Test
  @Order(11)
  public void test11WiedehopfIsImplemented() throws Exception {
    testImplementation(new Wiedehopf(), "blumentopf");
  }
}
