package edu.hm.cs.bka.dev2.snowman;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchneemannTeil1Test {

  private static final Duration TIMEOUT = Duration.ofSeconds(10);

  @Test
  @Order(1)
  public void GoHasAbstractMoveMethod() {
    Method m = assertPublicMethod(GeometricObject.class, "move",
        void.class, double.class, double.class);
    if (!Modifier.isAbstract(m.getModifiers())) {
      failf("Methode move in Klasse GeometricObject muss abstrakt sein!");
    }
  }

  @Test
  @Order(2)
  public void shouldMoveCircle()
      throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    Circle c = new Circle(Color.BLACK, new Point(1.0, 4.0), 7.0);
    Method m = assertPublicMethod(GeometricObject.class, "move",
        void.class, double.class, double.class);
    m.invoke(c, 4.0, -3.0);
    assertEquals(5.0, c.getCenter().getX(), 0.1,
        "Verschiebung eines Kreises funktioniert nicht (X-Richtung)");
    assertEquals(1.0, c.getCenter().getY(), 0.1,
        "Verschiebung eines Kreises funktioniert nicht (Y-Richtung)");
  }

  @Test
  @Order(3)
  public void shouldMoveRectangle()
      throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    Rectangle r = new Rectangle(Color.RED, new Point(0.0, 0.0), new Point(2.0, 3.0));
    Method m = assertPublicMethod(GeometricObject.class, "move",
        void.class, double.class, double.class);
    m.invoke(r, 7.0, 5.0);

    assertEquals(7.0, r.getUpperLeft().getX(), 0.1,
        "Verschiebung eines Rechtecks funktioniert nicht (X-Richtung)");
    assertEquals(5.0, r.getUpperLeft().getY(), 0.1,
        "Verschiebung eines Rechtecks funktioniert nicht (Y-Richtung)");
    assertEquals(9.0, r.getLowerRight().getX(), 0.1,
        "Verschiebung eines Rechtecks funktioniert nicht (X-Richtung)");
    assertEquals(8.0, r.getLowerRight().getY(), 0.1,
        "Verschiebung eines Rechtecks funktioniert nicht (Y-Richtung)");
  }

}
