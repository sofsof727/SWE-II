package edu.hm.cs.bka.dev2.liedgut;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.*;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Method;
import java.time.Duration;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VogelhochzeitTeil4Test {


  private static final Duration TIMEOUT = Duration.ofSeconds(8);

  public static String testImplementation(Vogel v, String rhyme)
      throws Exception {
    Method beschreibung = null;
    try {
      beschreibung = Vogel.class.getDeclaredMethod("liefereBeschreibung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBechreibung() fehlt in Klasse Vogel.");
    }

    Method bezeichnung = null;
    try {
      bezeichnung = Vogel.class.getDeclaredMethod("liefereBezeichnung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBezeichnung() fehlt in Klasse Vogel.");
    }

    String n = v.getClass().getSimpleName();

    assertTrue(bezeichnung.invoke(v).toString().contains(n),
        "Klasse " + n + " muss Bezeichnung zurückliefern.");

    assertTrue(beschreibung.invoke(v).toString().toLowerCase().contains(rhyme),
        "Klasse " + n + " muss Beschreibung zurückliefern.");

    String refrain = SystemLambda.tapSystemOutNormalized(v::singeRefrain);
    String strophe = SystemLambda.tapSystemOutNormalized(v::singeStrophe);

    assertEquals(1, StringUtils.countMatches(strophe, refrain),
        "Strophe muss Refrain einmal enthalten!");
    assertEquals(1, StringUtils.countMatches(
        strophe.toLowerCase(), beschreibung.invoke(v).toString().toLowerCase()),
        "Strophe muss Beschreibung enthalten!");

    return strophe;

  }

  @Test
  public void testEuleIsImplemented() throws Exception {

    Class<?> c = assertClass("edu.hm.cs.bka.dev2.liedgut", "Eule");
    String strophe = testImplementation((Vogel) c.newInstance(), "geheule");

    assertTrue(1<=StringUtils.countMatches(
        strophe.toLowerCase(), "eule"), "Strophe muss Bezeichnung enthalten!");

    assertTrue(strophe.toLowerCase().startsWith("brautmutter"),
        "Strophe muss mit Brautmutter anfangen");
  }

  @Test
  public void testKuckuckIsImplemented() throws Exception {

    Class<?> c = assertClass("edu.hm.cs.bka.dev2.liedgut", "Kuckuck");
    String strophe = testImplementation((Vogel) c.newInstance(), "hochzeitskleid");

    assertEquals(2, StringUtils.countMatches(
        strophe.toLowerCase(), "kuckuck"), "Strophe muss Bezeichnung zweimal enthalten!");

    assertTrue(
        StringUtils.countMatches(strophe.toLowerCase(), "schreit") == 2,
        "Strophe muss zweimal 'schreit' enthalten");
  }

  @Test
  public void testPfauIsImplemented() throws Exception {

    Class<?> c = assertClass("edu.hm.cs.bka.dev2.liedgut", "Pfau");
    var v = (Vogel) c.newInstance();
    String strophe = testImplementation(v, "den ersten tanz");
    Method beschreibung = null;
    try {
      beschreibung = Vogel.class.getDeclaredMethod("liefereBeschreibung");
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Methode liefereBeschreibung() fehlt in Klasse Vogel.");
    }

    assertFalse(beschreibung.invoke(v).toString().toLowerCase().contains("schwanz"),
        "Klasse " + v.getClass().getSimpleName() +
            " muss Beschreibung ohne 'Schwanz' zurückliefern.");

    assertEquals(1, StringUtils.countMatches(
        strophe.toLowerCase(), "pfau"), "Strophe muss Bezeichnung enthalten!");

    assertTrue(
        StringUtils.countMatches(strophe.toLowerCase(), "schwanz") == 1,
        "Strophe muss 'Schwanz' enthalten");
  }

  @Test
  public void testHahnIsImplemented() throws Exception {

    Class<?> c = assertClass("edu.hm.cs.bka.dev2.liedgut", "Hahn");
    var v = (Vogel) c.newInstance();
    String strophe = testImplementation(v, "gute nacht");

    assertEquals(1, StringUtils.countMatches(
        strophe.toLowerCase(), "hahn"), "Strophe muss Bezeichnung enthalten!");

  }

}
