package edu.hm.cs.bka.dev2.liedgut;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.Duration;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VogelhochzeitTeil1Test {


  private static final Duration TIMEOUT = Duration.ofSeconds(5);

  @Test
  @Order(1)
  public void test01MethodRefrainExists() {

    Method m = null;
    try {
      m = Vogel.class.getDeclaredMethod("singeRefrain");
    } catch (NoSuchMethodException | SecurityException e) {
      failf("Methode singeRefrain fehlt in Klasse Vogel.");
    }
    if (!Modifier.isProtected(m.getModifiers())) {
      failf("Sichtbarkeit von singeRefrain() entspricht nicht der Aufgabenstellung!");
    }
    if (!Modifier.isFinal(m.getModifiers())) {
      failf("singeRefrain() soll unveränderlich sein!");
    }
  }

  @Test
  @Order(2)
  public void test01MethodRefrainSingsRefrain()
      throws Exception {

    String sysout = SystemLambda.tapSystemOutNormalized(new Star()::singeRefrain);

    // ACHTUNG: Normalized ändert Zeilenumbrüche von LineSep auf "\n"
    assertEquals(1, StringUtils.countMatches(sysout, "\n"),
        "singeRefrain sollte eine Zeile (mit Umbruch) ausgeben!");
    assertTrue(sysout.toLowerCase().contains("fiderallalalala"),
        "singeRefrain sollte den Refrain ausgeben");
    assertEquals(3, StringUtils.countMatches(sysout.toLowerCase(), "fiderallala"),
        "singeRefrain sollte den Refrain ausgeben");
  }

  @Test
  @Order(3)
  public void test03MethodAnfangPrintsAnfang() throws Exception {
    String refrain = SystemLambda.tapSystemOutNormalized(new Star()::singeRefrain);
    String anfang = SystemLambda.tapSystemOutNormalized(new Star()::singeAnfang);

    assertTrue(StringUtils.countMatches(anfang, refrain) == 2,
        "singeAnfang sollte Refrain zweimal enthalten");
    // ACHTUNG: Normalized ändert Zeilenumbrüche von LineSep auf "\n"
    assertEquals(4, StringUtils.countMatches(anfang, "\n"),
        "singeAnfang sollte vier Zeilen (mit Umbruch) ausgeben!");
    assertTrue(anfang.toLowerCase().contains("hochzeit"), "singeAnfang sollte Anfang enthalten!");
    assertTrue(anfang.toLowerCase().contains("walde"), "singeAnfang sollte Anfang enthalten!");
    assertTrue(anfang.toLowerCase().contains("drossel"), "singeAnfang sollte Anfang enthalten!");
  }

  @Test
  @Order(4)
  public void test04MethodAnfangIsFinal() {
    Method m = assertPublicMethod(Vogel.class, "singeAnfang", void.class);
    if (!Modifier.isFinal(m.getModifiers())) {
      failf("SingeAnfang sollte final sein!");
    }
  }

  @Test
  @Order(5)
  public void test05MethodEndePrintsEnde() throws Exception {
    String refrain = SystemLambda.tapSystemOutNormalized(new Star()::singeRefrain);
    String ende = SystemLambda.tapSystemOutNormalized(new Star()::singeEnde);

    assertTrue(ende.contains(refrain), "singeEnde sollte Refrain enthalten");

    // ACHTUNG: Normalized ändert Zeilenumbrüche von LineSep auf "\n"
    assertEquals(2, StringUtils.countMatches(ende, "\n"),
        "singeEnde sollte zwei Zeilen (mit Umbruch) ausgeben!");

    assertTrue(ende.toLowerCase().contains("ist nun aus"), "singeEnde sollte Ende enthalten!");
    assertTrue(ende.toLowerCase().contains("fliegen all nach"), "singeEnde sollte Ende enthalten!");
  }

  @Test
  public void test06MethodEndeIsFinal() {
    Method m = assertPublicMethod(Vogel.class, "singeEnde", void.class);
    if (!Modifier.isFinal(m.getModifiers())) {
      failf("singeEnde() sollte final sein!");
    }
  }


}
