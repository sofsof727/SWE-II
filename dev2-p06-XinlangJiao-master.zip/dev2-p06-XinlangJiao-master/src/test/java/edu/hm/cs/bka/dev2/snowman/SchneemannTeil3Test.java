package edu.hm.cs.bka.dev2.snowman;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchneemannTeil3Test {

    private static final Duration TIMEOUT = Duration.ofSeconds(10);

    @Test
    @Order(1)
    public void goHasAlignLeftMethod() {
        Method m = assertPublicMethod(GeometricObject.class, "alignLeft",
                void.class, GeometricObject.class);
    }

    @Test
    @Order(2)
    public void goHasAlignRightMethod() {
        Method m = assertPublicMethod(GeometricObject.class, "alignRight",
                void.class, GeometricObject.class);
    }

    @Test
    @Order(3)
    public void goHasAlignTopMethod() {
        Method m = assertPublicMethod(GeometricObject.class, "alignTop",
                void.class, GeometricObject.class);
    }

    @Test
    @Order(4)
    public void goHasAlignBottomMethod() {
        Method m = assertPublicMethod(GeometricObject.class, "alignBottom",
                void.class, GeometricObject.class);
    }

    @Test
    @Order(5)
    public void alignLeftIsInheritedInCircle() {
        try {
            Method m = Circle.class.getDeclaredMethod("alignLeft", GeometricObject.class);
            fail("align-Methoden müssen unverändert geerbt werden!");
        } catch (Exception e) {
            // Nothing to do here.
        }
    }

    @Test
    @Order(6)
    public void alignRightIsInheritedInCircle() {
        try {
            Method m = Circle.class.getDeclaredMethod("alignRight", GeometricObject.class);
            fail("align-Methoden müssen unverändert geerbt werden!");
        } catch (Exception e) {
            // Nothing to do here.
        }
    }

    @Test
    @Order(7)
    public void alignTopIsInheritedInCircle() {
        try {
            Method m = Circle.class.getDeclaredMethod("alignTop", GeometricObject.class);
            fail("align-Methoden müssen unverändert geerbt werden!");
        } catch (Exception e) {
            // Nothing to do here.
        }
    }

    @Test
    @Order(8)
    public void alignBottomIsInheritedInCircle() {
        try {
            Method m = Circle.class.getDeclaredMethod("alignBottom", GeometricObject.class);
            fail("align-Methoden müssen unverändert geerbt werden!");
        } catch (Exception e) {
            // Nothing to do here.
        }
    }

    @Test
    @Order(9)
    public void testAlignLeft()
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Method m = assertPublicMethod(GeometricObject.class, "alignLeft",
                void.class, GeometricObject.class);
        Circle c1 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(4.0, 5.0), 2.0);
        Circle c2 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(1.0, 1.0), 3.0);
        m.invoke(c2, c1);
        assertEquals(5.0, c2.getCenter().getX(), 0.01, "alignLeft funktioniert nicht für Kreis!");
        assertEquals(1.0, c2.getCenter().getY(), 0.01, "alignLeft funktioniert nicht für Kreis!");
    }

    @Test
    @Order(10)
    public void testAlignRight()
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Method m = assertPublicMethod(GeometricObject.class, "alignRight",
                void.class, GeometricObject.class);
        Circle c1 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(4.0, 5.0), 2.0);
        Circle c2 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(1.0, 1.0), 3.0);
        m.invoke(c2, c1);
        assertEquals(3.0, c2.getCenter().getX(), 0.01, "alignRight funktioniert nicht für Kreis!");
        assertEquals(1.0, c2.getCenter().getY(), 0.01, "alignRight funktioniert nicht für Kreis!");
    }

    @Test
    @Order(11)
    public void testAlignTop()
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Method m = assertPublicMethod(GeometricObject.class, "alignTop",
                void.class, GeometricObject.class);
        Circle c1 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(4.0, 5.0), 2.0);
        Circle c2 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(1.0, 1.0), 3.0);
        m.invoke(c2, c1);
        assertEquals(1.0, c2.getCenter().getX(), 0.01, "alignTop funktioniert nicht für Kreis!");
        assertEquals(6.0, c2.getCenter().getY(), 0.01, "alignTop funktioniert nicht für Kreis!");
    }

    @Test
    @Order(12)
    public void testAlignBottom()
            throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Method m = assertPublicMethod(GeometricObject.class, "alignBottom",
                void.class, GeometricObject.class);
        Circle c1 = new Circle(Color.BLACK, new edu.hm.cs.bka.dev2.snowman.Point(4.0, 5.0), 2.0);
        Circle c2 = new Circle(Color.BLACK, new Point(1.0, 1.0), 3.0);
        m.invoke(c2, c1);
        assertEquals(1.0, c2.getCenter().getX(), 0.01, "alignBottom funktioniert nicht für Kreis!");
        assertEquals(4.0, c2.getCenter().getY(), 0.01, "alignBottom funktioniert nicht für Kreis!");
    }
}
