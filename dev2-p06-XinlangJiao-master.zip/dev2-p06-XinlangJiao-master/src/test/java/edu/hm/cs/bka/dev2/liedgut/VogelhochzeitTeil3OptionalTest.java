package edu.hm.cs.bka.dev2.liedgut;

import static de.i8k.java.testing.ReflectiveAssertions.*;
import static org.junit.jupiter.api.Assertions.fail;

import java.lang.reflect.Constructor;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VogelhochzeitTeil3OptionalTest {

  private static final Duration TIMEOUT = Duration.ofSeconds(8);

  @Test
  public void testUhuIsImplemented() throws Exception {
    Class<?> c = assertClass("edu.hm.cs.bka.dev2.liedgut", "Uhu");
    Constructor<?> con = null;
    try {
      con = c.getConstructor(String.class);
    } catch (NoSuchMethodException | SecurityException e) {
      fail("Konstruktor mit String-Parameter fehlt in Klasse Uhu.");
    }
    VogelhochzeitTeil2Test
        .testImplementation((Vogel) con.newInstance("der lalala huhu"), "der lalala huhu");
  }

}
