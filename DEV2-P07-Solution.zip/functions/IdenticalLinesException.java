package edu.hm.cs.bka.dev2.functions;

/**
 * Exception für Anzeige von unendlich vielen Schnitten bei gleichen Geraden.
 */
public class IdenticalLinesException extends Exception {

  /**
   * Konstruktor.
   *
   * @param message Meldung
   */
  public IdenticalLinesException(String message) {
    super(message);
  }
}
