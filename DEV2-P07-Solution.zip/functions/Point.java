package edu.hm.cs.bka.dev2.functions;

import java.util.Objects;

/**
 * Repräsentation eines Punktes.
 */
public class Point {
  private final double xvalue;
  private final double yvalue;

  public Point(double xvalue, double yvalue) {
    this.xvalue = xvalue;
    this.yvalue = yvalue;
  }

  public double getX() {
    return xvalue;
  }

  public double getY() {
    return yvalue;
  }

  @Override
  public String toString() {
    return "(" + xvalue + "/" + yvalue + ")";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Point point = (Point) o;
    return Double.compare(point.xvalue, xvalue) == 0 &&
        Double.compare(point.yvalue, yvalue) == 0;
  }

  @Override
  public int hashCode() {
    return Objects.hash(xvalue, yvalue);
  }
}
