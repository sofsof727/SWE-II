package edu.hm.cs.bka.dev2.functions;

/**
 * Exception zur Anzeige fehlender Schnitte bei parallelen Geraden.
 */
public class NoIntersectionException extends Exception {

  /**
   * Konstruktor.
   *
   * @param message Meldung
   */
  public NoIntersectionException(String message) {
    super(message);
  }
}
