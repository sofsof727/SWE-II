package edu.hm.cs.bka.dev2.functions;

/**
 * Klasse für Funktionen der Form f(x) = mx + n.
 *
 * @author katz.bastian
 */
public class LinearFunction {

  private final double ordinatenSchnitt; // n
  private final double steigung; // m

  /**
   * Konstruktor.
   *
   * @param steigung         Steigungsfaktor (m)
   * @param ordinatenSchnitt Konstante, damit auch y-Achsenschnitt (a=f(0))
   */
  public LinearFunction(double steigung, double ordinatenSchnitt) {
    this.ordinatenSchnitt = ordinatenSchnitt;
    this.steigung = steigung;
  }

  /**
   * Liefert den Wert der Funktion an einer Stelle x.
   *
   * @param x Stelle zur Auswertung
   * @return f(x), d.h. mx+n
   */
  public double valueAt(double x) {
    return ordinatenSchnitt + steigung * x;
  }

  /**
   * Berechnet den Schnittpunkt mit einer anderen linearen Funktion.
   *
   * @param g andere lineare Funktion.
   * @return Schnittpunkt
   */
  public Point intersection(LinearFunction g)
      throws IdenticalLinesException, NoIntersectionException {
    if (g == null) {
      throw new IllegalArgumentException("Argument darf nicht null sein!");
    }
    // Steigungsdifferenz der beiden Funktionen.
    double deltaSteigung = steigung - g.steigung;

    // Unterschied im y-Achsenabschnitt
    double deltaAbschnitt = g.ordinatenSchnitt - ordinatenSchnitt;
    if (deltaSteigung == 0.0) {
      if (deltaAbschnitt == 0.0) {
        throw new IdenticalLinesException("Geraden sind identisch!");
      } else {
        throw new NoIntersectionException("Geraden schneiden sich nicht.");
      }
    }

    double xcoordinate = deltaAbschnitt / deltaSteigung;
    return new Point(xcoordinate, valueAt(xcoordinate));
  }

  @Override
  public String toString() {
    String result = steigung + "x";
    if (ordinatenSchnitt >= 0.0) {
      result += "+";
    }
    result += ordinatenSchnitt;
    return result;
  }
}
