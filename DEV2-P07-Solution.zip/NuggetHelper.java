package edu.hm.cs.bka.dev2.nuggets;

/**
 * Hilfsklasse für die Berechnung von Nugget-Bestellungen.
 */
public class NuggetHelper {

  /**
   * Berechnet eine Aufteilung einer Zahl in Vielfache von 6, 9 und 20 (Chicken-McNugget-Problem).
   *
   * @param nuggets positive Anzahl der bestellten Nuggets
   * @return Array mit den Anzahlen an 20ern, 9ern und 6ern
   * @throws ImpossibleOrderException wenn es keine bestellbare Kombination gibt
   */
  public static int[] teileAufPackungen(final int nuggets) throws ImpossibleOrderException {
    if (nuggets < 0) {
      throw new IllegalArgumentException("Negative Zahl Nuggets unzulässig!");
    }

    // berechne eine Lösung
    int zwanziger = 0;
    int neuner = 0;
    int rest = nuggets;

    while (rest % 3 != 0 || rest > 63) {
      zwanziger++;
      rest -= 20;
    }

    while (rest > 12 || rest == 9) {
      neuner++;
      rest -= 9;
    }

    if (rest >= 0 && rest % 6 == 0) {
      return new int[] { zwanziger, neuner, rest / 6 };
    }


    // Das passiert, wenn nix gefunden wird:
    throw new ImpossibleOrderException(nuggets);
  }


}