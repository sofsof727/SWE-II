package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Widerstand.
 */
public class Widerstand extends Komponente {

  private final double widerstand;

  /**
   * Konstruktor.
   *
   * @param widerstand Widerstandswert, muss positiv sein.
   */
  public Widerstand(String bezeichner, double widerstand) {
    super(bezeichner);
    if (widerstand <= 0.0) {
      throw new IllegalArgumentException("Widerstand negativ!");
    }
    this.widerstand = widerstand;
  }

  @Override
  public double berechneWiderstand() {
    return widerstand;
  }

}
