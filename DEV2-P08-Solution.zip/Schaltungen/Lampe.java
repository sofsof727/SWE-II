package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Lampe. Widerstand wird berechnet aus Nominalspannung und Leistung.
 */
public class Lampe extends Komponente {

  private final double sollSpannung;
  private final double leistung;

  /**
   * Konstruktor.
   *
   * @param bezeichner Bezeichner
   * @param sollSpannung Sollspannung
   * @param leistung Leistungsaufnahme
   */
  public Lampe(String bezeichner, double sollSpannung, double leistung) {
    super(bezeichner);
    this.sollSpannung = sollSpannung;
    this.leistung = leistung;
  }

  @Override
  public double berechneWiderstand() {
    return sollSpannung * sollSpannung / leistung;
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    if (spannung > sollSpannung) {
      throw new UeberspannungsException("Lampe kaputt.");
    }
    if (spannung >= 0.5 * sollSpannung) {
      System.out.println("BLINK!");
    }
    return super.legeSpannungAn(spannung);
  }

}
