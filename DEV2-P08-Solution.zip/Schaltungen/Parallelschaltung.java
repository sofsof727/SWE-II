package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Parallelschaltung zweier Schaltungen.
 */
public class Parallelschaltung extends Kombinationsschaltung {


  public Parallelschaltung(Schaltung a, Schaltung b) {
    super(a, b);
  }

  @Override
  public double berechneWiderstand() {
    return 1 / (1 / getErstes().berechneWiderstand() + 1 / getZweites().berechneWiderstand());
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    getErstes().legeSpannungAn(spannung);
    getZweites().legeSpannungAn(spannung);
    return super.legeSpannungAn(spannung);
  }
}

