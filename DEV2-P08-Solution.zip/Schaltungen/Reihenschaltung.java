package edu.hm.cs.bka.dev2.schaltungen;

/** Reihenschaltung zweier Schaltungen. Widerstände addieren sich. */
public class Reihenschaltung extends Kombinationsschaltung {

  public Reihenschaltung(Schaltung a, Schaltung b) {
    super(a, b);
  }

  @Override
  public double berechneWiderstand() {
    return getErstes().berechneWiderstand() + getZweites().berechneWiderstand();
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    getErstes().legeSpannungAn(spannung * getErstes().berechneWiderstand() / berechneWiderstand());
    getZweites()
        .legeSpannungAn(spannung * getZweites().berechneWiderstand() / berechneWiderstand());
    return super.legeSpannungAn(spannung);
  }
}
