package edu.hm.cs.bka.dev2.schaltungen;

public abstract class Kombinationsschaltung extends Schaltung {

  private final Schaltung[] teile;

  protected Kombinationsschaltung(Schaltung erste, Schaltung zweite) {
    teile = new Schaltung[] {erste, zweite};
  }

  protected Schaltung getErstes() {
    return teile[0];
  }

  protected Schaltung getZweites() {
    return teile[1];
  }

}
