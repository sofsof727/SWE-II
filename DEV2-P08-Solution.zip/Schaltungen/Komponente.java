package edu.hm.cs.bka.dev2.schaltungen;

public abstract class Komponente extends Schaltung {

  private final String bezeichner;

  protected Komponente(String bezeichner) {
    this.bezeichner = bezeichner;
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    double strom = super.legeSpannungAn(spannung);
    System.out
        .printf("Bauteil %s, Widerstand %.02fΩ angelegte Spannung %.02fV, Stromfluss %.02fA%n",
            bezeichner, berechneWiderstand(), spannung, strom); // unicode: Ohm
    return strom;
  }
}
