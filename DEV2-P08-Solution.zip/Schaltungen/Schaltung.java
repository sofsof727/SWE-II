package edu.hm.cs.bka.dev2.schaltungen;

public abstract class Schaltung {

  /**
   * Berechnet den inneren Widerstand.
   *
   * @return Widerstand in Ohm.
   */
  public abstract double berechneWiderstand();

  /**
   * Löst Verhalten eines Bauteils aus und berechnet den Stromfluss.
   *
   * @param spannung angelegte Spannung in Volt
   * @return Stromfluss in Ampere
   * @throws UeberspannungsException wenn Spannung zu hoch ist
   */
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    return spannung / berechneWiderstand();
  }
}
