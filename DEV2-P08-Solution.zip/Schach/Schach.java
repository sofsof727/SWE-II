package edu.hm.cs.bka.dev2.schach;

public class Schach extends Schachspiel {

  public static void main(String[] args) {
    Schachspiel schachspiel = new Schach();
    schachspiel.spiele();
  }

  /**
   * Konstruktor.
   */
  public Schach() {
    set(0, 0, new Turm(Farbe.WEISS));
    set(0, 1, new Springer(Farbe.WEISS));
    set(0, 2, new Laeufer(Farbe.WEISS));
    set(0, 3, new Dame(Farbe.WEISS));
    set(0, 4, new Koenig(Farbe.WEISS));
    set(0, 5, new Laeufer(Farbe.WEISS));
    set(0, 6, new Springer(Farbe.WEISS));
    set(0, 7, new Turm(Farbe.WEISS));
    set(7, 0, new Turm(Farbe.SCHWARZ));
    set(7, 1, new Springer(Farbe.SCHWARZ));
    set(7, 2, new Laeufer(Farbe.SCHWARZ));
    set(7, 3, new Dame(Farbe.SCHWARZ));
    set(7, 4, new Koenig(Farbe.SCHWARZ));
    set(7, 5, new Laeufer(Farbe.SCHWARZ));
    set(7, 6, new Springer(Farbe.SCHWARZ));
    set(7, 7, new Turm(Farbe.SCHWARZ));
    for (int col = 0; col < 8; col++) {
      set(6, col, new Bauer(Farbe.SCHWARZ));
      set(1, col, new Bauer(Farbe.WEISS));
    }
  }

  @Override
  protected boolean beendet() {
    int count = 0;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (get(r, c) != null && get(r, c) instanceof Koenig) {
          count++;
        }
      }
    }
    return (count < 2);
  }


}
