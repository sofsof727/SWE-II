package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Läufer.
 */
public class Laeufer extends GeradeZiehendeFigur {

  public Laeufer(Farbe color) {
    super(color);
  }

  public String toString() {
    return "\u265d"; // Läufer
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                            int nachReihe, int nachSpalte) {

    // Wenn Zug nicht geradlinig ist, ist der Zug nicht zulässig.
    if (!super.kannZiehen(schachbrett, vonReihe, vonSpalte, nachReihe, nachSpalte)) {
      return false;
    }
    // Es muss in beiden Dimensionen Änderung geben!
    return vonReihe != nachReihe && vonSpalte != nachSpalte;
  }
}

