package edu.hm.cs.bka.dev2.schach;

/**
 * Abstrakte Oberklasse für alle Figuren, die beim Ziehen überprüfen müssen, dass das Zielfeld leer
 * ist oder eine gegnerische Figur enthalten (d.h. keine eigene Figur enthalten).
 */
public abstract class NormalSchlagendeFigur extends Figur {

  public NormalSchlagendeFigur(Farbe color) {
    super(color);
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                            int nachReihe, int nachSpalte) {
    Figur ziel = schachbrett.get(nachReihe, nachSpalte);
    return (ziel == null || ziel.getFarbe() != getFarbe());
  }
}
