package edu.hm.cs.bka.dev2.editor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * Einfachste JavaFX-Anwendung.
 */
public class TinyEdit extends Application {

  /**
   * Erzeugt erste/einzige Scene und ordnet sie dem Fenster zu.
   *
   * @param stage Fenster
   */
  public void start(Stage stage) {
    // Definition der TextArea
    TextArea area = new TextArea();
    area.setWrapText(true);
    area.setFont(Font.font("Arial", 20));
    area.setPrefHeight(2000);

    // Menüstruktur
    MenuBar bar = new MenuBar();
    Menu menu = new Menu("Menü");
    bar.getMenus().add(menu);
    MenuItem open = new MenuItem("Öffnen");
    MenuItem save = new MenuItem("Speichern");
    menu.getItems().add(open);
    menu.getItems().add(save);

    // Aktion für Menüeintrag "Öffnen"
    open.setOnAction(value -> {
      area.setText(readFile(stage));
    });

    // Aktion für Menüeintrag "Speichern"
    save.setOnAction(value -> {
      writeFile(stage, area.getText());
    });

    // Checkbox
    CheckBox check = new CheckBox("Text umbrechen");
    check.setSelected(true);

    // Aktion für Checkbox
    check.setOnAction(value -> {
      area.setWrapText(check.isSelected());
    });

    // Slider
    Slider slider = new Slider(10, 50, 20);

    // Aktion für Slider
    slider.setOnMouseDragged(value -> {
      area.setFont(Font.font("Arial", slider.getValue()));
    });

    // Layout
    HBox hbox = new HBox(check, slider);
    VBox vbox = new VBox(bar, area, hbox);
    Scene scene = new Scene(vbox, 600, 450);
    stage.setScene(scene);

    // Benennt das fertige Fenster und macht es sichtbar.
    stage.setTitle("tinyEdit");
    stage.show();
  }

  /**
   * Start der Anwendung, main-Methode muss in anderer Klasse liegen.
   */
  static void startApp() {
    launch();
  }



  /* Hilfsmethoden, hier müssen Sie nichts ändern! */

  /**
   * Öffnet einen Dateiauswahldialog und liest die gesamte Datei als Textdatei in einen String.
   *
   * @param stage dem Dialog übergeordnetes Fenster
   * @return Inhalt der Datei als String, leerer String bei Abbruch.
   */
  private static String readFile(Stage stage) {
    String result = "";
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Datei öffnen");
    File file = fileChooser.showOpenDialog(stage);
    if (file != null) {
      Path path = file.toPath();
      // Das Einlesen geht noch etwas eleganter, aber nicht mit bekannten Mitteln.
      // Der Einsatz von try und catch ist nicht zu vermeiden.
      try {
        for (String line : Files.readAllLines(path)) {
          result += line + System.lineSeparator();
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return result;
  }

  /**
   * Öffnet einen Dateiauswahldialog und schreibt einen gegebenen Text in die gewählte (auch neue)
   * Datei.
   *
   * @param stage dem Dialog übergeordnetes Fenster
   * @param text zu schreibender Text
   */
  private static void writeFile(Stage stage, String text) {
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Datei speichern");
    File file = fileChooser.showSaveDialog(stage);
    if (file != null) {
      Path path = file.toPath();
      try {
        Files.writeString(path, text);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
