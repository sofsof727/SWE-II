package edu.hm.cs.bka.dev2.survey;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Einfachste JavaFX-Anwendung.
 */
public class Survey extends Application {

  boolean initial = true;

  /**
   * Erzeugt erste/einzige Scene und ordnet sie dem Fenster zu.
   *
   * @param stage Fenster
   */
  public void start(Stage stage) {

    // Chart
    PieChart pieChart = new PieChart();
    PieChart.Data data1 = new PieChart.Data("Cola (0)", 1);
    PieChart.Data data2 = new PieChart.Data("Fanta (0)", 1);
    PieChart.Data data3 = new PieChart.Data("Sprite (0)", 1);
    pieChart.getData().add(data1);
    pieChart.getData().add(data2);
    pieChart.getData().add(data3);

    // Buttons
    Button buttonA = new Button("Cola");
    buttonA.setPrefSize(150, 150);

    // Das hier ließe sich noch rausziehen, aber so ist es
    // am verständlichsten!
    buttonA.setOnAction(value -> {
      if (initial) {
        data1.setPieValue(0);
        data2.setPieValue(0);
        data3.setPieValue(0);
        initial = false;
      }
      data1.setPieValue(data1.getPieValue() + 1);
      data1.setName("Cola (" + (int) data1.getPieValue() + ")");
    });

    Button buttonB = new Button("Fanta");
    buttonB.setPrefSize(150, 150);

    // Das hier ließe sich noch rausziehen, aber so ist es
    // am verständlichsten!
    buttonB.setOnAction(value -> {
      if (initial) {
        data1.setPieValue(0);
        data2.setPieValue(0);
        data3.setPieValue(0);
        initial = false;
      }
      data2.setPieValue(data2.getPieValue() + 1);
      data2.setName("Fanta (" + (int) data2.getPieValue() + ")");
    });

    Button buttonC = new Button("Sprite");
    buttonC.setPrefSize(150, 150);

    // Das hier ließe sich noch rausziehen, aber so ist es
    // am verständlichsten!
    buttonC.setOnAction(value -> {
      if (initial) {
        data1.setPieValue(0);
        data2.setPieValue(0);
        data3.setPieValue(0);
        initial = false;
      }
      data3.setPieValue(data3.getPieValue() + 1);
      data3.setName("Sprite (" + (int) data3.getPieValue() + ")");
    });


    // Layout (unfertig)
    GridPane pane = new GridPane();
    pane.add(pieChart, 0, 0, 1, 3);
    pane.add(buttonA, 1, 0, 1, 1);
    pane.add(buttonB, 1, 1, 1, 1);
    pane.add(buttonC, 1, 2, 1, 1);
    Scene scene = new Scene(pane, 600, 400);
    stage.setScene(scene);

    // Benennt das fertige Fenster und macht es sichtbar.
    stage.setTitle("miniSurvey");
    stage.show();
  }

  /**
   * Start der Anwendung, main-Methode muss in anderer Klasse liegen.
   */
  static void startApp() {
    launch();
  }

  /* Hilfsmethoden */


}
