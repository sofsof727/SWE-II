package edu.hm.cs.bka.dev2.kasse;

import static java.lang.System.exit;

/**
 * Implementierung einer kleinen Kasse.
 */
public class Register {
    // TODO: Implementieren Sie hier die Klasse wie in der Aufgabe beschrieben

    private int sum=0;
    static int zahl=0;
    static int count=0;//static variable

    public void add(final int value){
        sum +=value;

        if (value<0){
            sum = zahl;
        }
        zahl=value;
        //methodezaehler
        count++;

    }

    public int getSum(){
        return sum;
    }

    public void repeat(){
        if(count==0)
            sum=sum;
        sum+=zahl;
    }

    //Vor dem ersten Aufruf von add und nach einem Aufruf von storno sind Aufrufe von storno wirkungslos
    public void storno(){
        if (count==0)
            sum=sum;
        sum-=zahl;
    }

    public void reset(){
        sum=0;
    }

}