package edu.hm.cs.bka.dev2.kasse;

import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link Register}.
 */



class RegisterTest {
    // TODO: Ergänzen Sie hier ausreichend Tests (mindestens 8)

    @Test
    public void testAdd1() {
        //arrange
        Register reg = new Register();

        //act
        reg.add(5);

        //assertion
        assertEquals(5, reg.getSum(), "add 5, sum ergibt sich aus 5");
    }

    @Test
    public void testAdd2() {
        //arrange
        Register reg = new Register();

        //act
        reg.add(5);
        reg.add(-5);

        //assertion
        assertEquals(5, reg.getSum(), "add 5, add -5, sum ergibt sich aus 5");
    }


    @Test
    public void testStorno(){
        //arrange
        Register reg = new Register();

        //act
        reg.add(5);
        reg.add(15);
        reg.storno();
        //assertation
        assertEquals(5, reg.getSum(), "add 5, add 15, sum ergibt sich aus 5");
    }

    @Test
    public void testRepeat(){
        //arrange
        Register reg = new Register();

        //act
        reg.add(5);
        reg.add(10);
        reg.repeat();

        //assertation
        assertEquals(25, reg.getSum(), "add 5, add 10, repeat, sum ergibt sich aus 25");
    }

    @Test
    public void testReset(){
        //arrange
        Register reg = new Register();

        //act
        reg.add(5);
        reg.add(6);
        reg.reset();

        //assertation
        assertEquals(0, reg.getSum(), "add 5, add 6, reset, sum ergibt sich aus 0");
    }

    @Test
    public void testVorAddStorno(){
        //arrange
        Register reg = new Register();

        //act
        reg.storno();
        reg.storno();

        //assertation
        assertEquals(0, reg.getSum(), "ohne add erst zuruecksetzen, sum ergibt sich aus 0");
    }

    @Test
    public void testVorAddRepeat(){
        //arrange
        Register reg = new Register();

        //act
        reg.reset();
        reg.repeat();

        //assertation
        assertEquals(0, reg.getSum(), "ohne add erst in den Ursprungszustand setzt, sum ergibt sich aus 0");
    }

    @Test
    public void testRepeatbeliebigmals(){
        //arrange
        Register reg = new Register();

        //act
        reg.add(1);
        reg.add(2);
        reg.repeat();
        reg.repeat();

        reg.add(3);
        reg.repeat();
        reg.repeat();

        //assertation
        assertEquals(16, reg.getSum(), "add 1, add 2, repeat zweimal, add 3, repeat zweimal sum ergibt sich aus 16");
    }

}

