package edu.hm.cs.bka.dev2.kasse;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;


import edu.hm.cs.bka.dev2.kasse.impls.*;
import java.io.IOException;
import java.io.InputStream;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.UnmodifiableClassException;
import java.lang.reflect.Field;
import java.net.URL;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.agent.ByteBuddyAgent;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;

import static org.junit.jupiter.api.Assertions.fail;

public class MetaTest {

  @Test
  public void test01()
      throws ClassNotFoundException {
    String hint =
        "Eine Implementierung ohne implementierte Methoden und falschen Initialwert wird nicht erkannt.";
    run(new WrongInitialValueNoImplementedOperationsRegister(), hint);
  }

  @Test
  public void test02()
      throws ClassNotFoundException {
    String hint = "Eine Implementierung mit fehlenden Methoden passiert Ihre Tests.";
    run(new NotImplementedOperationsRegister(), hint);
  }

  @Test
  public void test03()
      throws ClassNotFoundException {
    String hint =
        "Eine Implementierung, bei der nach Storno noch wiederholt/storniert werden kann, wird nicht erkannt.";
    run(new StornoNotPreventingRepeatRegister(), hint);
  }

  @Test
  public void test04()
      throws ClassNotFoundException {
    String hint =
        "Eine Implementierung, bei der nach Reset noch wiederholt/storniert werden kann, wird nicht erkannt.";
    run(new ResetNotPreventingRepeatOrStornoRegister(), hint);
  }

  @Test
  public void test05()
      throws ClassNotFoundException {
    String hint =
        "Implementierung, bei der negative Werte storniert werden koennen, wird nicht erkannt.";
    run(new RepeatOfNegativeValuePossibleRegister(), hint);
  }

  @Test
  public void test06()
      throws ClassNotFoundException {
    String hint = "Eine Implementierung, die negative Werte akzeptiert, wird nicht erkannt.";
    run(new AcceptingNegativeAdditionsRegister(), hint);
  }

  @Test
  public void test07() throws ClassNotFoundException {
    String hint = "Eine Implementierung, die bei Storno auf 0 setzt, wird nicht erkannt.";
    run(new StornoToZeroRegister(), hint);
  }

  @Test
  public void test08()
      throws ClassNotFoundException {
    String hint =
        "Eine Implementierung, die bei Erstellung wiederholbaren Wert enthaelt, wird nicht erkannt..";
    run(new StartsWithRepeatableMemoryRegister(), hint);
  }

  @Test
  public void test09() throws ClassNotFoundException {
    String hint = "Eine Implementierung, die statt reset nur storniert, wird nicht erkannt.";
    run(new ResetEqualsStornoRegister(), hint);
  }

  @Test
  public void test10()
      throws ClassNotFoundException {
    String hint =
        "Eine Implementierung, die negative Summen verhindert, aber keine negativen Additionen, wird nicht erkannt.";
    run(new PreventsNegativeSumButNotNegativeAdditionRegister(), hint);
  }

  private void run(Object o, String hint) throws ClassNotFoundException {
    SummaryGeneratingListener listener = new SummaryGeneratingListener();
    System.out.println("Running "+o.getClass());


    try {
      Field f = Register.class.getDeclaredField("delegateClass");
      f.set(null, o.getClass());
    } catch (Exception e) {
      fail("Konnte Meta-Tests nicht ausführen!"+e);
    }

    LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder.request()
        .selectors(selectClass(Class.forName("edu.hm.cs.bka.dev2.kasse.RegisterTest")))
        .build();
    Launcher launcher = LauncherFactory.create();
    TestPlan testPlan = launcher.discover(request);
    launcher.registerTestExecutionListeners(listener);

    launcher.execute(request);
    if (listener.getSummary().getTestsFoundCount() < 8) {
      fail("RegisterTest muss mindestens 8 Testfaelle enthalten!");
    }
    if (listener.getSummary().getFailures().size() == 0) {
      fail("Sie testen noch nicht genug: " + hint);
    } else {
      System.out.println("Fail: "+ listener.getSummary().getFailures().get(0).getTestIdentifier());
    }
  }

}
