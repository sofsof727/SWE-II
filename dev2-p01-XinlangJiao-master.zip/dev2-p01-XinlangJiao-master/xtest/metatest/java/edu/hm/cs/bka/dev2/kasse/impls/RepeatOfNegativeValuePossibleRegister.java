package edu.hm.cs.bka.dev2.kasse.impls;


public class RepeatOfNegativeValuePossibleRegister {

  int sum;

  int last;

  public int getSum() {
    return sum;
  }

  public void add(final int value) {
    if (value > 0) {
      sum += value;
    }
    last = value;
  }

  public void repeat() {
    sum += last;
  }

  public void storno() {
    sum -= last;
    last = 0;
  }

  public void reset() {
    sum = 0;
    last = 0;
  }

}
