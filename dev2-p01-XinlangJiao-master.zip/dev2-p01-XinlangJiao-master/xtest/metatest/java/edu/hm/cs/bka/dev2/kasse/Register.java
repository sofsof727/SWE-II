package edu.hm.cs.bka.dev2.kasse;

import de.i8k.java.testing.ReflectiveAssertions;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Delegating Test-Proxy!
 */
public class Register {

  public static Class<?> delegateClass = null;

  private Object delegate = null;
  public Register() {
    try {
      delegate = delegateClass.newInstance();
    } catch (InstantiationException|IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  public void reset() {
    Method reset = ReflectiveAssertions.assertMethod(delegate.getClass(), "reset", void.class);
    try {
      reset.invoke(delegate);
    } catch (IllegalAccessException| InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }

  public void add(int value) {
    Method add = ReflectiveAssertions.assertMethod(delegate.getClass(), "add", void.class, int.class);
    try {
      add.invoke(delegate, value);
    } catch (IllegalAccessException| InvocationTargetException e) {
      throw new RuntimeException(e);
    }

  }

  public void repeat() {
    Method repeat = ReflectiveAssertions.assertMethod(delegate.getClass(), "repeat", void.class);
    try {
      repeat.invoke(delegate);
    } catch (IllegalAccessException| InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }

  public void storno() {
    Method storno = ReflectiveAssertions.assertMethod(delegate.getClass(), "storno", void.class);
    try {
      storno.invoke(delegate);
    } catch (IllegalAccessException| InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }

  public int getSum() {

    Method getSum = ReflectiveAssertions.assertMethod(delegate.getClass(), "getSum", int.class);
    try {
      return (int) getSum.invoke(delegate);
    } catch (IllegalAccessException| InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }
}
