package edu.hm.cs.bka.dev2.kasse.impls;

public class PreventsNegativeSumButNotNegativeAdditionRegister {

  int sum;

  int last;

  public int getSum() {
    return sum;
  }

  public void add(final int value) {
    sum += value;
    last = value;
    if (sum < 0) {
      sum = 0;
      last = 0;
    }
  }

  public void repeat() {
    sum += last;
  }

  public void storno() {
    sum -= last;
    // last = 0;
  }

  public void reset() {
    sum = 0;
    last = 0;
  }

}
