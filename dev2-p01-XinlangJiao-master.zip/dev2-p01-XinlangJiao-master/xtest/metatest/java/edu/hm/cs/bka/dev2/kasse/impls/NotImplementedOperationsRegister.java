package edu.hm.cs.bka.dev2.kasse.impls;

public class NotImplementedOperationsRegister {

  public void reset() {
    // not doing anything
  }

  public void add(int value) {
    // not doing anything

  }

  public void repeat() {
    // not doing anything

  }

  public void storno() {
    // not doing anything
  }

  public int getSum() {
    return 0;
  }
}
