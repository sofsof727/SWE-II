package edu.hm.cs.bka.dev2.kasse;

import static org.junit.jupiter.api.Assertions.assertEquals;

import de.i8k.java.testing.ReflectiveAssertions;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class ReferenzTest {

  private void assertAllMethods() {
    try {
      Register.class.getConstructor();
      Register.class.getMethod("getSum");
      Register.class.getMethod("storno");
      Register.class.getMethod("repeat");
      Register.class.getMethod("reset");
      Register.class.getMethod("add", int.class);
    } catch (NoSuchMethodException e) {
      Assertions.fail("Klasse Register enthält nicht alle benötigten Methoden!");
    }
  }

  @Test
  public void test01() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);

    // When
    int actual = (int) getSum.invoke(register);

    // Then
    assertEquals(0, actual, "Summe ist zu Beginn nicht 0!");
  }

  @Test
  public void test02() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    // When
    add.invoke(register, 17);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(17, actual, "Summe ist nach Addition von 17 nicht 17.");
  }

  @Test
  public void test03() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);


    // When
    add.invoke(register, 17);
    add.invoke(register, 12);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(29, actual, "Summe ist nach Addition von 17 und 12 nicht 29!");
  }

  @Test
  public void test04() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method reset = ReflectiveAssertions.assertMethod(Register.class, "reset", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);
    add.invoke(register, 17);

    // When
    reset.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe ist nach Reset nicht 0!");
  }

  @Test
  public void test05() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method storno = ReflectiveAssertions.assertMethod(Register.class, "storno", void.class);
    Method repeat = ReflectiveAssertions.assertMethod(Register.class, "repeat", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    add.invoke(register, 17);

    // When
    storno.invoke(register);
    repeat.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe ist nach Addition, Storno und Repeat nicht 0.");
  }


  @Test
  public void test06() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method storno = ReflectiveAssertions.assertMethod(Register.class, "storno", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    add.invoke(register, 17);
    add.invoke(register, 12);

    // When
    storno.invoke(register);
    storno.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(17, actual,
        "Summe entspricht nach zweifacher Addition und doppeltem Storno nicht dem ersten Wert");
  }

  @Test
  public void test07() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method storno = ReflectiveAssertions.assertMethod(Register.class, "storno", void.class);
    Method reset = ReflectiveAssertions.assertMethod(Register.class, "reset", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    add.invoke(register, 17);
    add.invoke(register, 12);

    // When
    reset.invoke(register);
    storno.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe ist nach Reset und Storno nicht 0");
  }

  @Test
  public void test08() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method repeat = ReflectiveAssertions.assertMethod(Register.class, "repeat", void.class);
    Method reset = ReflectiveAssertions.assertMethod(Register.class, "reset", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    add.invoke(register, 17);
    add.invoke(register, 12);

    // When
    reset.invoke(register);
    repeat.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe ist nach Reset und Repeat nicht 0.");
  }

  @Test
  public void test09() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    // When
    add.invoke(register, -17);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe ist nach negativer Addition nicht 0");
  }

  @Test
  public void test10() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method repeat = ReflectiveAssertions.assertMethod(Register.class, "repeat", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    add.invoke(register, 20);

    // When
    add.invoke(register, -3);
    repeat.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(20, actual, "Summe wird durch negative Addition und Repeat verändert!");
  }

  @Test
  public void test11() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method storno = ReflectiveAssertions.assertMethod(Register.class, "storno", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);
    add.invoke(register, 20);

    // When
    add.invoke(register, -3);
    storno.invoke(register);

    // Then
    int actual = (int) getSum.invoke(register);
    assertEquals(20, actual, "Summe wird durch negative Addition und Storno verändert!");
  }

  @Test
  public void test12() throws InvocationTargetException, IllegalAccessException {
    assertAllMethods();
    // Given
    Register register = new Register();
    Method getSum = ReflectiveAssertions.assertMethod(Register.class, "getSum", int.class);
    Method repeat = ReflectiveAssertions.assertMethod(Register.class, "repeat", void.class);
    Method add = ReflectiveAssertions.assertMethod(Register.class, "add", void.class, int.class);

    // When
    repeat.invoke(register);

    // Then

    int actual = (int) getSum.invoke(register);
    assertEquals(0, actual, "Summe nach sofortigem Repeat nicht 0");
  }
}
