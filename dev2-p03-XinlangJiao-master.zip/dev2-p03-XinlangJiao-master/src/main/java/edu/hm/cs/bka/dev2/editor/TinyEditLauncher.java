package edu.hm.cs.bka.dev2.editor;

/**
 * Launcher-Klasse für den Mini-Editor. Aus <i>sehr</i> technischen Gründen darf
 * die <code>main</code>-Methode nicht in der Anwendungsklasse selbst liegen.
 */
public class TinyEditLauncher {

  /**
   * Startet die Anwendung.
   *
   * @param args nicht verwendet
   */
  public static void main(String[] args) {
    TinyEdit.startApp();
  }
}
