package edu.hm.cs.bka.dev2.survey;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Einfachste JavaFX-Anwendung.
 */
public class Survey extends Application {

  /**
   * Erzeugt erste/einzige Scene und ordnet sie dem Fenster zu.
   *
   * @param stage Fenster
   */
  public void start(Stage stage) {

    // Chart
    PieChart pieChart = new PieChart();
    PieChart.Data data1 = new PieChart.Data("Cola (0)", 1);
    PieChart.Data data2 = new PieChart.Data("Fanta (0)", 1);
    PieChart.Data data3 = new PieChart.Data("Sprite (0)", 1);
    pieChart.getData().add(data1);
    pieChart.getData().add(data2);
    pieChart.getData().add(data3);

    // Buttons
    Button buttonA = new Button("Cola");
    buttonA.setPrefSize(150, 150);
    Button buttonB = new Button("Fanta");
    buttonB.setPrefSize(150, 150);
    Button buttonC = new Button("Sprite");
    buttonC.setPrefSize(150, 150);

    // Layout (unfertig)
    Scene scene = new Scene(pieChart, 600, 400);
    stage.setScene(scene);

    // Benennt das fertige Fenster und macht es sichtbar.
    stage.setTitle("miniSurvey");
    stage.show();
  }

  /**
   * Start der Anwendung, main-Methode muss in anderer Klasse liegen.
   */
  static void startApp() {
    launch();
  }

  /* Hilfsmethoden */


}
