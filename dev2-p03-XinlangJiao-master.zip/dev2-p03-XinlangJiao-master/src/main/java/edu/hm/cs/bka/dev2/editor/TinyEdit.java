package edu.hm.cs.bka.dev2.editor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * Einfachste JavaFX-Anwendung.
 */
public class TinyEdit extends Application {

  /**
   * Erzeugt erste/einzige Scene und ordnet sie dem Fenster zu.
   *
   * @param stage Fenster
   */
  public void start(Stage stage) {

    // Benennt das fertige Fenster und macht es sichtbar.
    stage.setTitle("tinyEdit");
    stage.show();
  }

  /**
   * Start der Anwendung, main-Methode muss in anderer Klasse liegen.
   */
  static void startApp() {
    launch();
  }



  /* Hilfsmethoden, hier müssen Sie nichts ändern! */

  /**
   * Öffnet einen Dateiauswahldialog und liest die gesamte Datei als Textdatei in einen String.
   *
   * @param stage dem Dialog übergeordnetes Fenster
   * @return Inhalt der Datei als String, leerer String bei Abbruch.
   */
  private static String readFile(Stage stage) {
    String result = "";
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Datei öffnen");
    File file = fileChooser.showOpenDialog(stage);
    if (file != null) {
      Path path = file.toPath();
      // Das Einlesen geht noch etwas eleganter, aber nicht mit bekannten Mitteln.
      // Der Einsatz von try und catch ist nicht zu vermeiden.
      try {
        for (String line : Files.readAllLines(path)) {
          result += line + System.lineSeparator();
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return result;
  }

  /**
   * Öffnet einen Dateiauswahldialog und schreibt einen gegebenen Text in die gewählte (auch neue)
   * Datei.
   *
   * @param stage dem Dialog übergeordnetes Fenster
   * @param text zu schreibender Text
   */
  private static void writeFile(Stage stage, String text) {
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Datei speichern");
    File file = fileChooser.showSaveDialog(stage);
    if (file != null) {
      Path path = file.toPath();
      try {
        Files.writeString(path, text);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
