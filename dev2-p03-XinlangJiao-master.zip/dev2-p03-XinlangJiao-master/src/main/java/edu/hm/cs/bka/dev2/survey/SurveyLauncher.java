package edu.hm.cs.bka.dev2.survey;

/**
 * Launcher-Klasse für die Survey-Anwendung. Aus <i>sehr</i> technischen Gründen darf
 * die <code>main</code>-Methode nicht in der Anwendungklasse selbst liegen.
 */
public class SurveyLauncher {

  /**
   * Startet die Anwendung.
   *
   * @param args wird nicht verwendet
   */
  public static void main(String[] args) {
    Survey.startApp();
  }
}
