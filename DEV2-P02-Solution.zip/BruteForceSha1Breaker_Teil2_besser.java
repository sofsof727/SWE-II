package edu.hm.cs.bka.dev2.breaker;

import org.apache.commons.codec.digest.DigestUtils;

public class BruteForceSha1Breaker {

  /**
   * Ermittelt Passwörter zu gegebenem Hash.
   *
   * @param sha1Hash Hash.
   * @return Passwort oder null, wenn kein passendes Passwort gefunden wurde.
   */
  public String findPassword(String sha1Hash) {
    // Diese Lösung folgt dem Vorgehen eines Zählers; in jedem Schritt wird die niedrigste
    // Stelle um ein Zeichen erhöht. Ist das höchste Zeichen erreicht, fängt es an dieser
    // Stelle wieder beim ersten Zeichen an, dafür gibt es einen Übertrag auf die nächste Stelle

    // Hinweis: Das lässt sich einfacher und schneller mit einem StringBuffer lösen,
    // über den haben wir aber in der Vorlesung nicht gesprochen.

    final int PWD_LENGTH = 5; // Maximale Passwort-Läng

    // Array mit zulässigen Zeichen (entsprechend ASCII-Reihenfolge)
    char[] valid = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();

    // Hier speichern wir ab, welches Zeichen an welcher Stelle gerade gewählt ist.
    // (Nur relevant für schon genutzte Stellen)
    int[] indizes = new int[PWD_LENGTH+1];

    // Aktuelles Passwort (getestet wird erst nach Erhöhung)
    String pwd = "";

    // "Erhöhe" Passwort, bis "ZZZZZ"
    while (pwd.length() <= PWD_LENGTH) {
      // Beginne mit einem "Übertrag" auf Index 0
      int index = 0;
      boolean carry = true;

      // erhöhe Stellen, bis kein Übertrag mehr vorliegt
      while (carry) {
        carry = false;
        // Wenn Übertrag an einer leeren Position ist, wird erstes Zeichen angehängt
        if (pwd.length() <= index) {
          pwd += valid[0];
        } else { // sonst wird Zeichen erhöht
          // Index des neuen Zeichens ermitteln
          indizes[index] = (indizes[index] + 1) % valid.length;

          // Zeichen ersetzen (hier wäre StringBuffer besser
          pwd = pwd.substring(0, index) + valid[indizes[index]] + pwd.substring(index + 1);
          // Wenn wir auf erstes Zeichen zurücksetzen, gibt es wieder Übertrag
          if (indizes[index] == 0) {
            carry = true;
            index++;
          }
        }
      }

      // Teste aktuelles Passwort
      String hash = DigestUtils.sha1Hex(pwd);
      if (hash.equals(sha1Hash)) {
        return pwd;
      }
    }

    // Wurde kein passendes Passwort gefunden, gib null zurueck.
    return null;
  }

}

