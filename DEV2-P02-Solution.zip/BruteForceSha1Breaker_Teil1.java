package edu.hm.cs.bka.dev2.breaker;

import org.apache.commons.codec.digest.DigestUtils;

public class BruteForceSha1Breaker {

  /**
   * Ermittelt Passwörter zu gegebenem Hash.
   *
   * @param sha1Hash Hash.
   *
   * @return Passwort oder null, wenn kein passendes Passwort gefunden wurde.
   */
  public String findPassword(String sha1Hash) {

    for (char letter1 = 'a'; letter1 <= 'z'; letter1++) {
      for (char letter2 = 'a'; letter2 <= 'z'; letter2++) {
        for (char letter3 = 'a'; letter3 <= 'z'; letter3++) {
          for (char letter4 = 'a'; letter4 <= 'z'; letter4++) {

            String password = "" + letter1 + letter2 + letter3 + letter4;
            String hash = DigestUtils.sha1Hex(password);

            if (hash.equals(sha1Hash)) {
              return password;
            }
          }
        }
      }
    }

    // Wurde kein passendes Passwort gefunden, gib null zurueck.
    return null;
  }

}