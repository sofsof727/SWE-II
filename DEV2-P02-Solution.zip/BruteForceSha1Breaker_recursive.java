package edu.hm.cs.bka.dev2.breaker;

import org.apache.commons.codec.digest.DigestUtils;

public class BruteForceSha1Breaker {

  private static final char[] VALID =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();

  /**
   * Ermittelt Passwörter zu gegebenem Hash.
   *
   * @param sha1Hash Hash.
   * @return Passwort oder null, wenn kein passendes Passwort gefunden wurde.
   */
  public String findPassword(String sha1Hash) {
    return findPassword("", 4, sha1Hash);
  }

  public String findPassword(String prefix, int maxLength, String hash) {

    if (DigestUtils.sha1Hex(prefix).equals(hash)) {
      return prefix;
    }
    if (prefix.length() == maxLength) {
      return null;
    }
    for (char c : VALID) {
      String pwd = findPassword(prefix + c, maxLength, hash);
      if (pwd != null) {
        return pwd;
      }
    }
    return null;
  }
}
