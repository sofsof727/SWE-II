package edu.hm.cs.bka.dev2.boxing;


import java.lang.reflect.Array;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static de.i8k.java.testing.ReflectiveAssertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BoxableTest {

    final static String PACKAGE = BoxableTest.class.getPackageName();

    @Test
    @Order(1)
    public void interfaceBoxableShouldExist() {
        assertInterface(PACKAGE, "Boxable");
    }

    @Test
    @Order(2)
    public void interfaceBoxableshouldHaveWeigthMethod() {
        Class<?> i = assertInterface(PACKAGE, "Boxable");
        assertPublicMethod(i, "getWeight", double.class);
    }
    
    @Test
    @Order(3)
    public void bookShouldImplementInterface() {
        Class<?> i = assertInterface(PACKAGE, "Boxable");
        if (!i.isAssignableFrom(Book.class)) {
            failf("Book muss Interface Boxable implementieren!");
        }
    }

    @Test
    @Order(4)
    public void crystalBallShouldImplementInterface() {
        Class<?> i = assertInterface(PACKAGE, "Boxable");
        if (!i.isAssignableFrom(CrystalBall.class)) {
            failf("Book muss Interface Boxable implementieren!");
        }
    }

    @Test
    @Order(5)
    public void constructorShouldAcceptInterface() {
        Class<?> i = assertInterface(PACKAGE, "Boxable");
        assertPublicConstructor(Box.class, String.class, Array.newInstance(i, 0).getClass());
    }

}
