package edu.hm.cs.bka.dev2.switchables;


import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.time.Duration;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Test fuer Mixer-Klasse.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MixerTest {

  final static Duration TIMEOUT = Duration.ofSeconds(5);
  final static String PACKAGE = MixerTest.class.getPackageName();


  @Test
  @Order(1)
  public void classShouldExistAndHaveMethod() {
    Class<?> c = assertClass(PACKAGE, "Mixer");
    assertPublicMethod(c, "toggle", void.class);
  }

  @Test
  @Order(2)
  public void interfaceShouldExistAndHaveMethod() {
    Class<?> i = assertInterface(PACKAGE, "Switchable");
    assertPublicMethod(i, "toggle", void.class);
  }

  @Test
  @Order(3)
  public void shouldImplementInterface() {
    Class<?> c = assertClass(PACKAGE, "Mixer");
    Class<?> i = assertInterface(PACKAGE, "Switchable");
    if (!i.isAssignableFrom(c)) {
      failf("%s muss Interface %s implementieren!", c.getSimpleName(), i.getSimpleName());
    }
  }

  @Test
  public void classShouldHaveDefaultConstructor() {
    Class<?> c = assertClass(PACKAGE, "Mixer");
    Constructor<?> con = assertPublicConstructor(c);
  }

  @Test
  public void shouldSwitchCorrectly() throws Exception {
    Class<?> c = assertClass(PACKAGE, "Mixer");
    Constructor<?> con = assertPublicConstructor(c);
    Method m = assertPublicMethod(c, "toggle", void.class);
    Object o = con.newInstance();

    String out = SystemLambda.tapSystemOutNormalized(() -> m.invoke(o));
    assertTrue(out.trim().contains("brm"), "Ausgabe sollte \"brmmmm\" sein!");

    out = SystemLambda.tapSystemOutNormalized(() -> m.invoke(o));
    assertTrue(out.trim().contains("BRM"), "Ausgabe sollte \"BRMMM\" sein!");

    out = SystemLambda.tapSystemOutNormalized(() -> m.invoke(o));
    assertTrue(out.trim().contains("click"), "Ausgabe sollte \"click\" sein!");

    out = SystemLambda.tapSystemOutNormalized(() -> m.invoke(o));
    assertTrue(out.trim().contains("brm"), "Ausgabe sollte \"brmmmm\" sein!");

    out = SystemLambda.tapSystemOutNormalized(() -> m.invoke(o));
    assertTrue(out.trim().contains("BRM"), "Ausgabe sollte \"BRMMM\" sein!");
  }

}
