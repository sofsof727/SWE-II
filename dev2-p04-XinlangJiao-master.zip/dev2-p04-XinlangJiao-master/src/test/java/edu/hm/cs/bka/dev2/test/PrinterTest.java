package edu.hm.cs.bka.dev2.test;

import edu.hm.cs.bka.dev2.text.TextReader;
import edu.hm.cs.bka.dev2.text.abbreviate.Abbreviator;
import edu.hm.cs.bka.dev2.text.printer.SimpleConsolePrinter;
import edu.hm.cs.bka.dev2.text.printer.WrappingConsolePrinter;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static de.i8k.java.testing.ReflectiveAssertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PrinterTest {

  private static final String PACKAGE = "edu.hm.cs.bka.dev2.text.printer";

  @Test
  @Order(1)
  public void interfaceWriterShouldExist() {
    Class<?> i = assertInterface(PACKAGE, "Printer");
  }

  @Test
  @Order(2)
  public void simpleConsolePrinterShouldImplementInterface() {
    Class<?> i = assertInterface(PACKAGE, "Printer");
    if (!i.isAssignableFrom(SimpleConsolePrinter.class)) {
      failf("SimpleConsolePrinter sollte Printer-Interface implementieren!");
    }
  }

  @Test
  @Order(3)
  public void wrappingPrinterShouldImplementInterface() {
    Class<?> i = assertInterface(PACKAGE, "Printer");
    if (!i.isAssignableFrom(WrappingConsolePrinter.class)) {
      failf("WrappingConsolePrinter sollte Printer-Interface implementieren!");
    }
  }

  @Test
  @Order(4)
  public void constructorShouldAcceptInterface() {
    Class<?> i = assertInterface(PACKAGE, "Printer");
    assertPublicConstructor(TextReader.class, i, Abbreviator.class);
  }

}
