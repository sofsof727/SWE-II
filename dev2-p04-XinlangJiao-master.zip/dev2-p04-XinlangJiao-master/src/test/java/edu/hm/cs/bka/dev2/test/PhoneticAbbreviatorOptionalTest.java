package edu.hm.cs.bka.dev2.test;


import edu.hm.cs.bka.dev2.text.abbreviate.Abbreviator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PhoneticAbbreviatorOptionalTest {

    private final static String PACKAGE = "edu.hm.cs.bka.dev2.text.abbreviate";

    @Test
    @Order(1)
    public void shouldExistAndImplementInterface() {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        if (!Abbreviator.class.isAssignableFrom(c)) {
            failf("PhoneticAbbreviator sollte Abbreviator-Interface implementieren!");
        }
    }

    @Test
    @Order(2)
    public void shouldHaveIntConstrucor() {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        assertPublicConstructor(c, int.class);
    }

    @Test
    @Order(3)
    public void shouldLeaveShortWords() throws InstantiationException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        Constructor<?> con = assertPublicConstructor(c, int.class);
        Method m = assertPublicMethod(c, "abbreviate", String.class, String.class);
        Object o = con.newInstance(10);
        assertEquals("Larifari", m.invoke(o, "Larifari"));
    }

    @Test
    public void shouldLeaveExactWordLength() throws InstantiationException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        Constructor<?> con = assertPublicConstructor(c, int.class);
        Method m = assertPublicMethod(c, "abbreviate", String.class, String.class);
        Object o = con.newInstance(8);
        assertEquals("Larifari", m.invoke(o, "Larifari"));
    }

    @Test
    public void shouldShortenAtSecondVowel() throws InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        Constructor<?> con = assertPublicConstructor(c, int.class);
        Method m = assertPublicMethod(c, "abbreviate", String.class, String.class);
        Object o = con.newInstance(6);
        assertEquals("Larif.", m.invoke(o, "Larifari"));
    }

    @Test
    public void shouldNotShortenWordsWithTwoVowels() throws InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Class<?> c = assertClass(PACKAGE, "PhoneticAbbreviator");
        Constructor<?> con = assertPublicConstructor(c, int.class);
        Method m = assertPublicMethod(c, "abbreviate", String.class, String.class);
        Object o = con.newInstance(5);
        assertEquals("Knuspern", m.invoke(o, "Knuspern"));
    }
}
