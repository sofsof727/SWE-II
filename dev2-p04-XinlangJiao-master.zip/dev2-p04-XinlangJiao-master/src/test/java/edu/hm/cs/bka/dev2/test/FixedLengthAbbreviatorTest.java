package edu.hm.cs.bka.dev2.test;


import edu.hm.cs.bka.dev2.text.abbreviate.Abbreviator;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FixedLengthAbbreviatorTest {

  private static final String PACKAGE = "edu.hm.cs.bka.dev2.text.abbreviate";

  @Test
  public void shouldExistAndImplementInterface() {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    if (!Abbreviator.class.isAssignableFrom(c)) {
      failf("FixedLengthAbbreviator sollte Abbreviator-Interface implementieren!");
    }
  }

  @Test
  public void shouldHaveIntConstrucor() {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    assertPublicConstructor(c, int.class);
  }

  @Test
  public void shouldLeaveShortWords()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    Constructor<?> con = assertPublicConstructor(c, int.class);
    Method m = assertPublicMethod(c, "abbreviate", String.class,
        String.class);
    Object o = con.newInstance(16);
    assertEquals("Digitalisierung", m.invoke(o, "Digitalisierung"),
        "Wörter unter der Mindestlänge sollen unverändert bleiben!");
  }

  @Test
  public void shouldLeaveExactWordLength()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    Constructor<?> con = assertPublicConstructor(c, int.class);
    Method m = assertPublicMethod(c, "abbreviate", String.class,
        String.class);
    Object o = con.newInstance(15);
    assertEquals("Digitalisierung", m.invoke(o, "Digitalisierung"),
        "Wörter mit exakt der Mindestlänge sollen unverändert bleiben!");
  }

  @Test
  public void shouldShortenLongWordEqualCase()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    Constructor<?> con = assertPublicConstructor(c, int.class);
    Method m = assertPublicMethod(c, "abbreviate", String.class,
        String.class);
    Object o = con.newInstance(6);
    assertEquals("Rh..er", m.invoke(o, "Rhabarber"));
  }

  @Test
  public void shouldShortenLongWordOddCase()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    Constructor<?> con = assertPublicConstructor(c, int.class);
    Method m = assertPublicMethod(c, "abbreviate", String.class,
        String.class);
    Object o = con.newInstance(7);
    assertEquals("Rha..er", m.invoke(o, "Rhabarber"));
  }

  @Test
  public void shouldTreatValuesBelow4As4() throws InstantiationException,
      IllegalAccessException, IllegalArgumentException, InvocationTargetException {
    Class<?> c = assertClass(PACKAGE, "FixedLengthAbbreviator");
    Constructor<?> con = assertPublicConstructor(c, int.class);
    Method m = assertPublicMethod(c, "abbreviate", String.class,
        String.class);
    Object o = con.newInstance(1);
    assertEquals("R..r", m.invoke(o, "Rhabarber"));
  }

}
