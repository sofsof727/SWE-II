package edu.hm.cs.bka.dev2.boxing;

/**
 * Klasse für Bücher.
 */
public class Book {

  /**
   * Titel des Buchs.
   */
  private final String title;

  /**
   * Gwicht des Buchs.
   */
  private final double weight;

  /**
   * Konstruktor zum Erzeugen eines Buchs.
   *
   * @param title  Titel
   * @param weight Gewicht in kg.
   */
  public Book(String title, double weight) {
    this.title = title;
    this.weight = weight;
  }

  /**
   * Liefert das Gewicht eines Buches.
   *
   * @return Gewicht des Buchs in kg.
   */
  public double getWeight() {
    return weight;
  }

  @Override
  public String toString() {
    return "Buch \"" + title + "\"";
  }
}
