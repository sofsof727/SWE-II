package edu.hm.cs.bka.dev2.text.abbreviate;

/**
 * Interface für das Abkuerzen von Worten.
 */
public interface Abbreviator {

  /**
   * Liefert Abkürzung für lange Wörter.
   *
   * @param word zu kürzendes Wort
   * @return das uebergebene Wort oder eine Abkürzung.
   */
  String abbreviate(final String word);
}
