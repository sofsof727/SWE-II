package edu.hm.cs.bka.dev2.text;

import edu.hm.cs.bka.dev2.text.abbreviate.Abbreviator;
import edu.hm.cs.bka.dev2.text.printer.SimpleConsolePrinter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.commons.lang3.StringUtils;

/**
 * Klasse zum Einlesen und Ausgeben einer Textdatei mit der Option, lange Wörter abzukürzen.
 */
public class TextReader {

  /**
   * Ausgabeklasse, kümmert sich um die Formatierung der Ausgabe.
   */
  private final SimpleConsolePrinter printer;

  /**
   * Verfahren zum Abkürzen langer Wörter.
   */
  private final Abbreviator abbreviator;

  /**
   * Erstellt einen neuen Reader mit vorgegebenem Ausgabeformat und (optional) Abkürzungsverfahren.
   *
   * @param writer      Ausgabeformatierer
   * @param abbreviator Abkuerzer, darf null sein.
   */
  public TextReader(final SimpleConsolePrinter writer, final Abbreviator abbreviator) {
    this.abbreviator = abbreviator;
    this.printer = writer;
  }

  /* Ab hier muessen Sie nichts aendern! */

  /**
   * Liest die Datei ein, kürzt lange Wörter, wenn ein {@link Abbreviator} uebergeben wurde und
   * nutzt den übergebenen Printer zur Ausgabe.
   *
   * @param filename Dateiname
   */
  public void read(final String filename) {
    Path path = Paths.get(filename);
    String inhalt = "";
    try {
      inhalt = Files.readString(path);
    } catch (IOException e) {
      System.out.println("Fehler beim Einlesen der Datei!");
    }

    // Suche nach langen Wörtern und kürze sie ab!
    if (abbreviator != null) {
      String[] words = StringUtils.split(inhalt, " \t\n\r,.;-!?\"'");
      for (String word : words) {
        inhalt = StringUtils.replace(inhalt, word, abbreviator.abbreviate(word));
      }
    }

    // Gib Text aus!
    System.out.println("Inhalt von " + filename.toUpperCase());
    System.out.println("=====================");
    printer.print(inhalt);
    System.out.println();
  }
}
