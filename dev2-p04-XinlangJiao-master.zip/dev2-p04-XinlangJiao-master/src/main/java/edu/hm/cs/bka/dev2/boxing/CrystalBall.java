package edu.hm.cs.bka.dev2.boxing;

/**
 * Klasse für Kristallkugeln.
 */
public class CrystalBall {

  /**
   * Beschreibung.
   */
  private final String description;

  /**
   * Radius.
   */
  private final double radius;

  /**
   * Konstruktor für eine neue Kristallkugel.
   *
   * @param description Beschreibung
   * @param radius      Radius in cm
   */
  public CrystalBall(String description, double radius) {
    this.radius = radius;
    this.description = description;
  }

  /**
   * Liefert das Gewicht einer Kugel.
   *
   * @return Gewicht der Kugel in kg.
   */
  public double getWeight() {
    return 1.33 * 2.4 * Math.PI * Math.pow(radius, 3);
  }

  @Override
  public String toString() {
    return "Kristallkugel '" + description + "' mit Radius " + radius + "cm";
  }

}
