package edu.hm.cs.bka.dev2.text.printer;

/**
 * Sehr einfache Lösung zur Ausgabe eines String.
 */
public class SimpleConsolePrinter {

  public void print(String s) {
    System.out.println(s);
  }
}
