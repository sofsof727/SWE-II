package edu.hm.cs.bka.dev2.text;

import edu.hm.cs.bka.dev2.text.printer.SimpleConsolePrinter;

/**
 * Demonstration der Klasse TextReader.
 */
public class TextReaderDemo {

  /**
   * Demo-Methode.
   *
   * @param args nicht verwendet
   */
  public static void main(String[] args) {

    SimpleConsolePrinter printer = new SimpleConsolePrinter();
    TextReader reader = new TextReader(printer, null);
    reader.read("phobie.txt");

    // Mit der Einfuerung des Interfaces Printer sollte auch
    // folgender Ablauf moeglich sein (Imports ergaenzen!)
    // Printer printer2 = new WrappingConsolePrinter(50);
    // TextReader reader2 = new TextReader(printer2, null);
    // reader2.read("phobie.txt");

    // Mit der Implementierung von von FixedLengthAbbreaviator
    // sollte auch folgender Aufruf moeglich sein (Imports ergaenzen!)
    // Abbreviator fla = new FixedLengthAbbreviator(10);
    // TextReader reader3 = new TextReader(printer2, fla);
    // reader3.read("phobie.txt");

    // Mit der optionalen Implementierung von von PhoneticAbbreviator
    // sollte auch folgender Aufruf moeglich sein (Imports ergaenzen!)
    // Abbreviator pa = new PhoneticAbbreviator(8);
    // TextReader reader4 = new TextReader(printer2, pa);
    // reader4.read("phobie.txt");

  }

}
