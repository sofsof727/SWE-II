package edu.hm.cs.bka.dev2.boxing;

/**
 * Klasse zur Repräsentation von Kartons, die mit Büchern gefüllt sind.
 */
public class Box {

  /**
   * Beschriftung.
   */
  private final String label;

  /**
   * Im Karton enthaltene Bücher.
   */
  private final Book[] content;

  /**
   * Konstruktor zur Erzeugung eines neuen Kartons.
   *
   * @param content enthaltene Bücher.
   * @param label   Beschriftung.
   */
  public Box(String label, Book... content) {
    this.content = content;
    this.label = label;
  }

  @Override
  public String toString() {
    String result =
        String.format("Box %s, Gewicht %.2fkg mit ", label, getTotalWeight());
    for (Book book : content) {
      result += "\n\t" + String.format("%s (%.2fkg)", book, book.getWeight());
    }
    return result;
  }

  /**
   * Berechnet das Gesamtgewicht.
   *
   * @return Gesamtgewicht der Box.
   */
  public double getTotalWeight() {
    double weight = 0.0;
    for (Book book : content) {
      weight += book.getWeight();
    }
    return weight;
  }
}
