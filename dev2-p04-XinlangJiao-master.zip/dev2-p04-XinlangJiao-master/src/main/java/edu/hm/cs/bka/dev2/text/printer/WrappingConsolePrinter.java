package edu.hm.cs.bka.dev2.text.printer;

import org.apache.commons.lang3.StringUtils;

/**
 * Ausgabe eines Strings auf der Kommandozeile. Dabei wird eine maximale Zeilenlänge berücksichtigt
 * und nach Möglichkeit Umbrüche ergänzt.
 */
public class WrappingConsolePrinter {

  // maximale Zeilenlänge
  private final int lineLength;

  /**
   * Konstruktor.
   *
   * @param lineLength maximale Zeilenlänge
   */
  public WrappingConsolePrinter(final int lineLength) {
    this.lineLength = lineLength;
  }

  /**
   * Gibt den Text auf der Konsole aus.
   *
   * @param text Text.
   */
  public void print(String text) {
    // Gib Zeile für Zeile aus
    for (String line : StringUtils.split(text, "\n")) {
      String rest = line.strip();
      // Gib Zeilen Stückweise aus, bis zum letzten sinnvollen Umbruch
      while (rest.length() > 0) {
        String nextPart = rest.substring(0, Math.min(rest.length(), lineLength));
        int splitAt = Math.max(nextPart.lastIndexOf(" "), nextPart.lastIndexOf("-") + 1);
        if (rest.length() > lineLength && splitAt > 0) {
          nextPart = rest.substring(0, splitAt).strip();
        }
        System.out.println(nextPart);
        rest = rest.substring(nextPart.length()).strip();
      }
    }
  }
}