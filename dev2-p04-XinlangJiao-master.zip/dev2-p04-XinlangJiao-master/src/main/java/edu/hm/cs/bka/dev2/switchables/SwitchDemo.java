package edu.hm.cs.bka.dev2.switchables;

/**
 * Beispielcode fuer Aufgabe 10.
 */
public class SwitchDemo {

  /**
   * Instantiiert Objekte der zu implementierenden Klassen und ruft die Methoden auf.
   *
   * @param args nicht verwendet.
   */
  public static void main(String... args) {
    // Switchable[] switchables = { new Lightbulb(), new Mixer() };
    // switchables[0].toggle(); // ->HELL
    // switchables[0].toggle(); // ->DUNKEL
    // switchables[0].toggle(); // ->HELL
    // switchables[1].toggle(); // ->brmmmm
    // switchables[1].toggle(); // ->BRMMM
    // switchables[1].toggle(); // ->AUS
    // switchables[1].toggle(); // ->brmmmm
  }

}
