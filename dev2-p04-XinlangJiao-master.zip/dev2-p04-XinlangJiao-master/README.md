# Softwareentwicklung II (W) - Projekt zu Aufgabenblatt 4

## Einsicht des Qualitätsreports

Sie können den Qualitäts-Report leider nur indirekt zugreifen. Gehen Sie dazu auf die Übersicht
der [Pipelines](../../pipelines/) und laden Sie den Report herunter (rechts/siehe Bild):

![Download Report](https://syncandshare.lrz.de/dl/fiDLdTE8XJ6awh9gW5tCqg/DEV2/DEV2-Grading.png)


