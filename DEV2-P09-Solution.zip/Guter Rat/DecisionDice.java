package edu.hm.cs.bka.dev2.decision;

import java.util.Random;

/**
 * Hilfsklasse mit statischen Methoden zur zufälligen Auswahl aus einem Array mit Optionen.
 */
public final class DecisionDice<T> {

  // Zufallszahlengenerator
  private static final Random RANDOM = new Random();

  private final T[] options;

  /**
   * Konstruktor.
   *
   * @param options Auswahlmöglichkeiten
   */
  public DecisionDice(T[] options) {
    this.options = options.clone();
  }

  /**
   * Liefert eine zufällige Option.
   *
   * @return zufällige Auswahl aus den Optionen
   */
  public T pick() {
    return options[RANDOM.nextInt(options.length)];
  }

}
