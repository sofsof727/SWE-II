package edu.hm.cs.bka.dev2.decision;

import edu.hm.cs.bka.dev2.splitting.Pair;
import java.util.Random;

/**
 * Hilfsklasse mit statischen Methoden zur zufälligen Auswahl aus einem Array mit Optionen.
 */
public final class DoubleDecisionDice<T, U> {

  // Zufallszahlengenerator
  private static final Random RANDOM = new Random();

  private final T[] optionsFirst;
  private final U[] optionsSecond;

  /**
   * Konstruktor.
   *
   * @param optionsFirst  Auswahlmöglichkeiten erste Option
   * @param optionsSecond Auswahlmöglichkeiten zweite Option
   */
  public DoubleDecisionDice(T[] optionsFirst, U[] optionsSecond) {
    this.optionsFirst = optionsFirst.clone();
    this.optionsSecond = optionsSecond.clone();
  }

  /**
   * Liefert eine zufällige Option.
   *
   * @return zufällige Auswahl aus den Optionen
   */
  public Pair<T, U> pick() {
    return new Pair<T, U>(optionsFirst[RANDOM.nextInt(optionsFirst.length)],
        optionsSecond[RANDOM.nextInt(optionsSecond.length)]);
  }

}
