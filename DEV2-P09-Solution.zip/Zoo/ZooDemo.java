package edu.hm.cs.bka.dev2.zoo;

import edu.hm.cs.bka.dev2.zoo.gehege.GehegeVollException;
import edu.hm.cs.bka.dev2.zoo.gehege.RaubkatzenKaefig;
import edu.hm.cs.bka.dev2.zoo.gehege.Voliere;
import edu.hm.cs.bka.dev2.zoo.gehege.Wildgehege;
import edu.hm.cs.bka.dev2.zoo.tiere.*;

/**
 * Beispielcode für Aufgabe 25.
 */
public class ZooDemo {

  /**
   * Beispielcode.
   *
   * @param args nicht verwendet
   */
  @SuppressWarnings("unused")
  public static void main(String[] args) throws GehegeVollException {

    // Den folgenden Beispielcode müssen Sie auch anpassen!

    /* Beispiel 1: Sperre Papageien ein und lasse sie frei */
    Papagei[] papageien = {new Papagei("Lora"), new Papagei("Rory")};
    Voliere<Papagei> papageienVoliere = new Voliere<Papagei>(papageien);
    papageienVoliere.lasseFrei(papageien[0]);
    papageienVoliere.schliesseEin(new Papagei("Rio"));
    System.out.println(papageienVoliere); // Belegung: Rio Rory

    /* Beispiel 2: Erstelle Wildgehege mit fünf Plätzen und zwei Hirschen, Bambi und Feline */
    Hirsch[] hirsche = {new Hirsch("Bambi"), new Hirsch("Feline"), null, null, null, null};
    Wildgehege<Hirsch> hirschGehege = new Wildgehege<Hirsch>(hirsche);
    System.out.println(hirschGehege);

    /* Beispiel 3: Erstelle einen RaubkatzenKaefig für drei Tiger und einen für drei Loewen */
    Tiger[] tiger = {new Tiger("Shir Khan"), null, null};
    Loewe[] loewe = {new Loewe("Simba"), null, null};
    RaubkatzenKaefig<Tiger> tigerKaefig = new RaubkatzenKaefig<Tiger>(tiger);
    RaubkatzenKaefig<Loewe> loewenKaefig = new RaubkatzenKaefig<Loewe>(loewe);
    System.out.println(tigerKaefig);
    System.out.println(loewenKaefig);

    // Das hier geht nicht mehr! Wildgehege müssen einer Tierart gehören, die von Wild erbt!
    // Tier[] tiere = {new Einhorn("Pinky Pie"), new Loewe("Simba"), new Affe("Louis")};
    // Wildgehege gehege = new Wildgehege(tiere);
  }
}
