package edu.hm.cs.bka.dev2.zoo.gehege;

import edu.hm.cs.bka.dev2.zoo.tiere.Vogel;

/**
 * Klasse für Volieren.
 */
public class Voliere<T extends Vogel> extends Gehege<T> {

  /**
   * Konstruktor.
   *
   * @param tiere einzusperrende Tiere, darf null enthalten für freie Plätze
   */

  public Voliere(T[] tiere) {
    super(tiere);
  }
}
