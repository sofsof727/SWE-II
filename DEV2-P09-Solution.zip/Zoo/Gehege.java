package edu.hm.cs.bka.dev2.zoo.gehege;

import edu.hm.cs.bka.dev2.zoo.tiere.Tier;

/**
 * Allgemeine Klasse für Gehege.
 */
public abstract class Gehege<T extends Tier> {

  /**
   * Array mit enthaltenen Tieren, <code>null</code> für einen freien Platz.
   */
  private final T[] tiere;

  /**
   * Konstruktor.
   *
   * @param tiere Array mit Tieren, darf null enthalten für freie Plätze.
   */
  public Gehege(T[] tiere) {
    this.tiere = tiere.clone();
  }

  /**
   * Fügt dem Gehege ein Tier hinzu.
   *
   * @param tier neues Tier.
   * @throws GehegeVollException wenn alle Plätze belegt sind.
   */
  public void schliesseEin(T tier) throws GehegeVollException {
    for (int i = 0; i < tiere.length; i++) {
      if (tiere[i] == null) {
        tiere[i] = tier;
        return;
      }
    }
    throw new GehegeVollException("Gehege voll!");
  }

  /**
   * Entfernt ein Tier aus dem Gehege (wenn es denn drin ist).
   *
   * @param tier zu entfernendes Tier
   */
  public void lasseFrei(T tier) {
    for (int i = 0; i < tiere.length; i++) {
      if (tiere[i] == tier) {
        tiere[i] = null;
        return;
      }
    }
  }

  @Override
  public String toString() {
    String result = "Belegung:";
    for (Tier tier : tiere) {
      if (tier != null) {
        result += " " + tier;
      } else {
        result += " (frei)";
      }
    }
    return result;
  }
}
