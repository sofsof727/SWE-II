package edu.hm.cs.bka.dev2.zoo.gehege;

import edu.hm.cs.bka.dev2.zoo.tiere.Wild;

/**
 * Klasse für Wildgehege.
 */
public class Wildgehege<T extends Wild> extends Gehege<T> {

  /**
   * Konstruktor.
   *
   * @param tiere einzusperrende Tiere, darf null enthalten für freie Plätze
   */
  public Wildgehege(T[] tiere) {
    super(tiere);
  }

}
