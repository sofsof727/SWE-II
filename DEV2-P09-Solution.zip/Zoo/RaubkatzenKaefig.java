package edu.hm.cs.bka.dev2.zoo.gehege;

import edu.hm.cs.bka.dev2.zoo.tiere.Raubkatze;

/**
 * Klasse für Raubkatzenkäfige.
 */
public class RaubkatzenKaefig<T extends Raubkatze> extends Kaefig<T> {

  /**
   * Konstruktor.
   *
   * @param tiere einzusperrende Tiere, darf null enthalten für freie Plätze
   */
  public RaubkatzenKaefig(T[] tiere) {
    super(tiere);
  }
}
