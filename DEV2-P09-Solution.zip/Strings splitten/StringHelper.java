package edu.hm.cs.bka.dev2.splitting;

/**
 * Klasse mit Hilfsfunktionenen für Strings.
 */
public class StringHelper {

  /**
   * Teilt einen String an einer vorgegebenen Stelle in zwei Teilstrings.
   *
   * @param string   beliebiger String, nicht null
   * @param position Länge des ersten Teilstrings (Wert zwischen 0 und <code>string.length</code>
   * @return Teilstrings als {@link Pair}.
   */
  public static Pair<String, String> split(String string, int position) {
    if (string == null) {
      throw new IllegalArgumentException("String darf nicht null sein!");
    }
    if (string.length() < position || position < 0) {
      throw new IllegalArgumentException("Split-Position liegt außerhalb des Strings!");
    }

    return new Pair<String, String>(string.substring(0, position), string.substring(position));
  }
}
