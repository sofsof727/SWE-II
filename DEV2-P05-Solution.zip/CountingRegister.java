package edu.hm.cs.bka.dev2.register;

/**
 * Kasse, die die alle Additionen mitzählt.
 *
 * @author katz.bastian
 */
public class CountingRegister extends ProRegister {

  /**
   * Anzahl der Additionen.
   */
  protected int count = 0;

  @Override
  public void add(int value) {
    super.add(value);
    count++;
  }
}
