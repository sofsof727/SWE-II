package edu.hm.cs.bka.dev2.peng;

/**
 * Implementierung eines Revolvers.
 */
public class Revolver extends Schusswaffe {

  private final boolean[] ladungInTrommeln;
  private int index = 0;

  /**
   * Konstruktor.
   *
   * @param geraeusch        Geräusch beim Schießen
   * @param ladungInTrommeln Trommeln mit Ladezustand (true: Patrone in Trommel)
   */
  public Revolver(String geraeusch, boolean[] ladungInTrommeln) {
    super(geraeusch);
    this.ladungInTrommeln = ladungInTrommeln;
  }

  @Override
  public void schiessen() {
    // schiessen, wenn an der aktuellen Position in der Trommel eine Patrone ist.
    if (ladungInTrommeln[index]) {
      super.schiessen();
      // danach ist keine Patrone mehr an der Stelle
      ladungInTrommeln[index] = false;
    } else {
      System.out.println("klick");
    }
    // Trommel dreht sich, aktuelle Stelle in der Trommel hochzaehlen
    index = (index + 1) % ladungInTrommeln.length;
  }
}
