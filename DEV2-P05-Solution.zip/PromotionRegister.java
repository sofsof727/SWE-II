package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die statt jedes 13. Wertes eine 0 erfasst..
 */
public class PromotionRegister extends CountingRegister {

  @Override
  public void add(int value) {
    if (count != 12) {
      super.add(value);
    } else {
      // Zähler zurücksetzen, damit wieder von vorne gezählt wird
      count = 0;
    }
  }
}

