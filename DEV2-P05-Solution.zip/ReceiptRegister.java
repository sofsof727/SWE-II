package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die eine Funktion zu Quittungsdruck beherrscht.
 */
public class ReceiptRegister extends ProRegister {

  // Pro-Tipp: Besser geht es mit einem StringBuffer!
  String receipt = "";

  @Override
  public void add(final int value) {
    super.add(value);
    if (value > 0) {
      receipt += String.format("%6d\n", value);
    }
  }

  public void printReceipt() {
    System.out.println(receipt + "------\n" + String.format("%6d\n", getSum()));
  }
}