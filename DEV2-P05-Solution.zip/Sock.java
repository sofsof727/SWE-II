package edu.hm.cs.bka.dev2.socks;

import java.awt.Color;
import java.util.Objects;

/**
 * Klasse für Socken.
 */
public class Sock {
  private final Color color;
  private final int size;

  /**
   * Konstruktor.
   *
   * @param color Farbe
   * @param size Größe
   */
  public Sock(Color color, int size) {
    this.color = color;
    this.size = size;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    Sock sock = (Sock) o;

    if (size != sock.size) {
      return false;
    }
    return Objects.equals(color, sock.color);
  }

  @Override
  public int hashCode() {
    int result = color != null ? color.hashCode() : 0;
    result = 31 * result + size;
    return result;
  }
}
