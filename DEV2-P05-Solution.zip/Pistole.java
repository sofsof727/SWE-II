package edu.hm.cs.bka.dev2.peng;

/**
 * Eine Pistole hat eine begrenzte Zahl von Schüssen in einem Magazin.
 */
public class Pistole extends Schusswaffe {

  private int patronen;
  private final int magazinGroesse;

  /**
   * Konstruktor.
   *
   * @param geraeusch      Geräusch beim Schießen
   * @param magazinGroesse Größe des Magazins
   * @param patronen       Anzahl der Patronen im Magazin
   */
  public Pistole(String geraeusch, int magazinGroesse, int patronen) {
    super(geraeusch);
    this.magazinGroesse = magazinGroesse;
    this.patronen = patronen;
  }

  @Override
  public void schiessen() {
    // nur (mit Gerausch) schiessen, wenn noch Patrone im Revolver
    if (patronen > 0) {
      super.schiessen();
      patronen--;
    } else {
      System.out.println("klick");
    }
  }

  /**
   * Gibt mehrere Schüsse ab.
   *
   * @param anzahl Anzahl der Schüsse
   */
  public void schiessen(int anzahl) {
    for (int i = 0; i < anzahl; i++) {
      schiessen();
    }
  }

  /**
   * Füllt das Magazin auf (ganz).
   */
  public void nachladen() {
    this.patronen = magazinGroesse;
  }

}
