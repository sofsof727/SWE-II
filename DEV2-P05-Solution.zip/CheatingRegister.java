package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die bei jeder vierten Eingabe einen Wert von 2 addiert.
 */
public class CheatingRegister extends CountingRegister {
  
  @Override
  public void add(int value) {
    // Nächste Operation durch 4 teilbare Nummer?
    if (count % 4 == 3) {
      super.add(2);
      // Zähler korrigieren.
      count--;
    }
    super.add(value);
  }

  @Override
  public void reset() {
    super.reset();
    count = 0;
  }
}
