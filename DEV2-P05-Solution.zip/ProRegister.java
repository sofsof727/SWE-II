package edu.hm.cs.bka.dev2.register;

/**
 * Implementierung einer Kasse mit Storno- und Wiederholfunktion.
 */
public class ProRegister extends Register {

  // letzte Erhoehung (fuer repeat oder storno).
  private int lastAddition;

  /**
   * Eingabe einer Summe.
   *
   * @param value Erhoehung. Negative Werte werden wie Null behandelt.
   */
  public void add(final int value) {
    super.add(value);
    if (value > 0) {
      lastAddition = value;
    } else {
      lastAddition = 0;
    }
  }

  /**
   * Wiederholt die letzte Erhoehung.
   */
  public void repeat() {
    add(lastAddition);
  }

  /**
   * Setzt das Objekt wieder in den Ausgangszustand zurueck.
   */
  public void reset() {
    super.reset();
    lastAddition = 0;
  }

}