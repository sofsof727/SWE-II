package edu.hm.cs.bka.dev2.jeans;

import java.util.*;

/**
 * Vergleichsklasse.
 */
public class SizeComparator {
  // TODO: Implementieren!
}
