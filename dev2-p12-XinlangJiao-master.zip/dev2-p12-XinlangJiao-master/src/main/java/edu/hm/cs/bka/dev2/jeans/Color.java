package edu.hm.cs.bka.dev2.jeans;

/**
 * Farben von Jeans.
 */

public enum Color {

  /**
   * Farben.
   */
  DARK_STONEWASH, NAVARRO_DARK_WASH, KANSAS_GREY, LIGHT_WASH
}
