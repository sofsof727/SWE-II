package edu.hm.cs.bka.dev2.jeans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ComparableTest {

  @Test
  @Order(1)
  public void compareToSollteTypVorWeiteSortieren() {
    Jeans j1 = new Jeans("AA", 2, 2, Color.KANSAS_GREY);
    Jeans j2 = new Jeans("BB", 1, 1, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("CC", 3, 3, Color.LIGHT_WASH);
    if (!(j1 instanceof Comparable<?>)) {
      fail("Jeans ist nicht vergleichbar!");
    }

    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Comparable<Jeans>> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    Collections.sort(in);

    assertEquals(expected, in);
  }

  @Test
  @Order(2)
  public void compareToSollteWeiteVorLaengeSortieren() {
    Jeans j1 = new Jeans("AA", 1, 2, Color.KANSAS_GREY);
    Jeans j2 = new Jeans("AA", 2, 1, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("AA", 3, 3, Color.LIGHT_WASH);
    if (!(j1 instanceof Comparable<?>)) {
      fail("Jeans ist nicht vergleichbar!");
    }

    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    Collections.sort(in);

    assertEquals(expected, in);
  }

  @Test
  @Order(3)
  public void compareToSollteLaengeVorFarbeSortieren() {
    Jeans j1 = new Jeans("AA", 1, 1, Color.KANSAS_GREY);
    Jeans j2 = new Jeans("AA", 1, 2, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("AA", 1, 3, Color.LIGHT_WASH);
    if (!(j1 instanceof Comparable<?>)) {
      fail("Jeans ist nicht vergleichbar!");
    }

    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    Collections.sort(in);

    assertEquals(expected, in);
  }

  @Test
  @Order(4)
  public void compareToSollteZuletztNachFarbeSortieren() {
    Jeans j1 = new Jeans("AA", 1, 1, Color.DARK_STONEWASH);
    Jeans j2 = new Jeans("AA", 1, 1, Color.KANSAS_GREY);
    Jeans j3 = new Jeans("AA", 1, 1, Color.LIGHT_WASH);
    if (!(j1 instanceof Comparable<?>)) {
      fail("Jeans ist nicht vergleichbar!");
    }

    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    Collections.sort(in);

    assertEquals(expected, in);
  }
}
