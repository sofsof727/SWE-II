package edu.hm.cs.bka.dev2.bingo;

import com.google.common.collect.Sets;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BingoTest {

  @Test
  @Order(1)
  public void karteHatKorrekteStruktur() throws NoSuchFieldException,
      IllegalAccessException {
    Set<Integer> values = Sets.newHashSet(101, 102, 103, 104, 105, 106, 107, 108, 109, 110);
    Bingo bingo = new Bingo(values, 3);
    Field f = Bingo.class.getDeclaredField("card");
    f.setAccessible(true);
    List<List<?>> card = (List<List<?>>) f.get(bingo);
    assertNotNull(card, "Interne Repräsentation card darf nicht null sein!");
    assertEquals(3, card.size(), "Karte sollte übergebene Anzahl (3) Zeilen haben!");
    for (List<?> row : card) {
      assertNotNull(row, "Zeile in interner Repräsentation card darf nicht null sein!");
      assertEquals(3, row.size(), "Zeile sollte übergebene Anzahl (3) Einträge haben!");
    }
  }

  @Test
  @Order(2)
  public void karteEnthaeltNurWerteAusUebergebenemBereich() throws NoSuchFieldException,
      IllegalAccessException {
    Set<Integer> values = Sets.newHashSet(101, 102, 103, 104, 105, 106, 107, 108, 109, 110);
    Bingo bingo = new Bingo(values, 3);
    Field f = Bingo.class.getDeclaredField("card");
    f.setAccessible(true);
    List<List<?>> card = (List<List<?>>) f.get(bingo);
    assertNotNull(card, "Interne Repräsentation card darf nicht null sein!");
    for (List<?> row : card) {
      assertNotNull(row, "Zeile in interner Repräsentation card darf nicht null sein!");
      for (Object i : row) {
        assertTrue(values.contains((Integer) i), "Karte sollte nur Werte aus übergebenem Bereich enthalten!");
      }
    }
  }

  @Test
  @Order(3)
  public void karteEnthaeltKeineWerteMehrfach() throws NoSuchFieldException,
      IllegalAccessException {
    Set<Integer> values = Sets.newHashSet(101, 102, 103, 104, 105, 106, 107, 108, 109, 110);
    Bingo bingo = new Bingo(values, 3);
    Field f = Bingo.class.getDeclaredField("card");
    f.setAccessible(true);
    List<List<?>> card = (List<List<?>>) f.get(bingo);
    assertNotNull(card, "Interne Repräsentation card darf nicht null sein!");
    for (List<?> row : card) {
      assertNotNull(row, "Zeile in interner Repräsentation card darf nicht null sein!");
      for (Object i : row) {
        values.remove(i);
      }
    }
    assertTrue(values.size() == 1, "Karte enthält Werte mehrfach!");
  }

  @Test
  @Order(4)
  public void karteEnthaeltZufaelligeAnordnung() throws NoSuchFieldException,
      IllegalAccessException {
    Set<Integer> values = Sets.newHashSet(0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
    int[][][] count = new int[3][3][10];
    Field f = Bingo.class.getDeclaredField("card");
    f.setAccessible(true);

    for (int i = 0; i < 1000; i++) {
      Bingo bingo = new Bingo(values, 3);
      List<List<?>> card = (List<List<?>>) f.get(bingo);
      assertNotNull(card, "Interne Repräsentation card darf nicht null sein!");
      for (int rowIdx = 0; rowIdx < 3; rowIdx++) {
        List<?> row = card.get(rowIdx);
        assertNotNull(row, "Zeile in interner Repräsentation card darf nicht null sein!");
        for (int col = 0; col < 3; col++) {
          count[rowIdx][col][(Integer)row.get(col)]++;
        }
      }
    }

    for (int row = 0; row < 3; row++) {
      for (int col = 0; col < 3; col++) {
        for (int value : values) {
          if (count[row][col][value] == 0) {
            fail(
                "Werte werden nicht zufällig verteilt, es kommen nicht alle Werte " +
                    "überall vor, wenn man viele Karten generiert!");
          }
        }
      }
    }

  }

  @Test
  @Order(5)
  public void testCrossing() throws BingoException {
    Bingo b = new Bingo(Sets.newHashSet(1, 2, 3, 4, 5, 6), 2);
    String s = b.toString();
    String substring = s.substring(42, 43);
    int i = Integer.parseInt(substring);
    b.add(i);
    String expected = s.substring(0, 38) + "XXXX" + i + "XXXXX" + s.substring(48);
    String g = b.toString();
    assertEquals(expected, g);
  }
}
