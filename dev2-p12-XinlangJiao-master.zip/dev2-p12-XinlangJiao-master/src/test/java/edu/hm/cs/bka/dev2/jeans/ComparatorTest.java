package edu.hm.cs.bka.dev2.jeans;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ComparatorTest {

  @Test
  @Order(5)
  public void comparatorSollteZuerstNachWeiteSortieren() {
    Jeans j1 = new Jeans("CC", 1, 3, Color.LIGHT_WASH);
    Jeans j2 = new Jeans("AA", 2, 1, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("BB", 3, 2, Color.KANSAS_GREY);


    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    SizeComparator comparator = new SizeComparator();
    try {
      Collections.sort(in, (Comparator<Jeans>) comparator);
    } catch (ClassCastException e) {
      fail("SizeComparator ist kein korrekter Comparator!");
    }

    assertEquals(expected, in);
  }

  @Test
  @Order(6)
  public void comparatorSollteLaengeNachWeiteSortieren() {
    Jeans j1 = new Jeans("CC", 1, 1, Color.LIGHT_WASH);
    Jeans j2 = new Jeans("AA", 1, 2, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("BB", 1, 3, Color.KANSAS_GREY);


    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);
    SizeComparator comparator = new SizeComparator();
    try {
      Collections.sort(in, (Comparator<Jeans>) comparator);
    } catch (ClassCastException e) {
      fail("SizeComparator ist kein korrekter Comparator!");
    }

    assertEquals(expected, in);
  }


  @Test
  @Order(7)
  public void comparatorSollteFarbeNachLaengeSortieren() {
    Jeans j1 = new Jeans("CC", 1, 1, Color.DARK_STONEWASH);
    Jeans j2 = new Jeans("AA", 1, 1, Color.KANSAS_GREY);
    Jeans j3 = new Jeans("BB", 1, 1, Color.LIGHT_WASH);


    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    SizeComparator comparator = new SizeComparator();
    try {
      Collections.sort(in, (Comparator<Jeans>) comparator);
    } catch (ClassCastException e) {
      fail("SizeComparator ist kein korrekter Comparator!");
    }

    assertEquals(expected, in);
  }

  @Test
  @Order(8)
  public void comparatorSollteZuletztNachTypSortieren() {
    Jeans j1 = new Jeans("AA", 1, 1, Color.DARK_STONEWASH);
    Jeans j2 = new Jeans("BB", 1, 1, Color.DARK_STONEWASH);
    Jeans j3 = new Jeans("CC", 1, 1, Color.DARK_STONEWASH);


    List<Jeans> in = new ArrayList<>();

    in.add(j3);
    in.add(j1);
    in.add(j2);

    List<Jeans> expected = new ArrayList<>();
    expected.add(j1);
    expected.add(j2);
    expected.add(j3);

    SizeComparator comparator = new SizeComparator();
    try {
      Collections.sort(in, (Comparator<Jeans>) comparator);
    } catch (ClassCastException e) {
      fail("SizeComparator ist kein korrekter Comparator!");
    }

    assertEquals(expected, in);
  }
}
