package edu.hm.cs.bka.dev2.text.abbreviate;

/**
 * Implementierung von {@link Abbreviator}, der lange Wörter durch Auslassung kuerzt.
 */
public class FixedLengthAbbreviator implements Abbreviator {

  private int length;

  /**
   * Konstruktor.
   *
   * @param length maximale Wortlaenge.
   */
  public FixedLengthAbbreviator(int length) {
    this.length = Math.max(length, 4);
  }

  @Override
  public String abbreviate(final String word) {
    if (word.length() <= length) {
      return word;
    }
    int prefix = (length - 2 + 1) / 2;
    int suffix = (length - 2) / 2;
    return word.substring(0, prefix) + ".." + word.substring(word.length() - suffix);
  }

}
