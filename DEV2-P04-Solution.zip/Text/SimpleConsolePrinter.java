package edu.hm.cs.bka.dev2.text.printer;

/**
 * Sehr einfache Lösung zur Ausgabe eines String.
 */
public class SimpleConsolePrinter implements Printer {

  public void print(String s) {
    System.out.println(s);
  }
}
