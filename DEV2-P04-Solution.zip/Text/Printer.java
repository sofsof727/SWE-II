package edu.hm.cs.bka.dev2.text.printer;

/**
 * Interface fuer Ausgabeformate.
 */
public interface Printer {

  // Gibt einen String aus.
  void print(String s);
}
