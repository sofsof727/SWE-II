package edu.hm.cs.bka.dev2.text.abbreviate;

/**
 * Implementierung von {@link Abbreviator}, der nach Vokalen sucht und entsprechend abkuerzt.
 */
public class PhoneticAbbreviator implements Abbreviator {

  private final int length;

  public PhoneticAbbreviator(int length) {
    this.length = length;
  }

  @Override
  public String abbreviate(final String word) {
    if (word.length() <= length) {
      return word;
    }
    String s = "";
    int vowels = 0;
    for (int i = 0; i < word.length(); i++) {
      if ("aeiou".indexOf(Character.toLowerCase(word.charAt(i))) >= 0) {
        vowels++;
        if (vowels == 3) {
          s += ".";
        }
      }
      if (vowels < 3) {
        s += word.charAt(i);
      }
    }
    return s;
  }

}
