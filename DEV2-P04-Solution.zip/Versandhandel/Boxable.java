package edu.hm.cs.bka.dev2.boxing;

public interface Boxable {

  /**
   * Liefert das Gewicht.
   *
   * @return Gewicht in kg.
   */
  double getWeight();

}
