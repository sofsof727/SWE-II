package edu.hm.cs.bka.dev2.boxing;

/**
 * Klasse zur Repräsentation von Kartons, die mit Büchern gefüllt sind.
 */
public class Box {

  /**
   * Beschriftung.
   */
  private final String label;

  /**
   * Im Karton enthaltene Bücher.
   */
  private final Boxable[] content;

  /**
   * Konstruktor zur Erzeugung eines neuen Kartons.
   *
   * @param content enthaltene Bücher.
   * @param label   Beschriftung.
   */
  public Box(String label, Boxable... content) {
    this.content = content;
    this.label = label;
  }

  @Override
  public String toString() {
    String result =
        String.format("Box %s, Gewicht %.2fkg mit ", label, getTotalWeight());
    for (Boxable boxable : content) {
      result += "\n\t" + String.format("%s (%.2fkg)", boxable, boxable.getWeight());
    }
    return result;
  }

  /**
   * Berechnet das Gesamtgewicht.
   *
   * @return Gesamtgewicht der Box.
   */
  public double getTotalWeight() {
    double weight = 0.0;
    for (Boxable boxable : content) {
      weight += boxable.getWeight();
    }
    return weight;
  }
}
