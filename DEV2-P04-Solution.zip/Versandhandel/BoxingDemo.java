package edu.hm.cs.bka.dev2.boxing;

/**
 * Demo-Anwendung fuers Karton-Packen..
 *
 * @author katz.bastian
 */
public class BoxingDemo {

  /**
   * Main-Methode zur Demonstration.
   *
   * @param args wird ignoriert
   */
  public static void main(String[] args) {

    Book[] books = new Book[9];
    books[0] = new Book("Effective Java", 0.5);
    books[1] = new Book("Software Engineering", 0.8);
    books[2] = new Book("Java 8 - Die Neuerungen", 0.3);
    books[3] = new Book("Domain Driven Design", 0.9);
    books[4] = new Book("Scrum in der Praxis", 0.4);
    books[5] = new Book("Algorithmen und Datenstrukturen", 0.8);
    books[6] = new Book("Introduction to Algorithms", 0.6);
    books[7] = new Book("Programmieren mit Java", 0.7);
    books[8] = new Book("Angular JS", 0.5);

    CrystalBall[] balls = new CrystalBall[5];
    balls[0] = new CrystalBall("Blau, 4cm", 0.4);
    balls[1] = new CrystalBall("Klar, 4cm", 0.4);
    balls[2] = new CrystalBall("Weiß, 4cm", 0.4);
    balls[3] = new CrystalBall("Schwarz, 4cm", 0.4);
    balls[4] = new CrystalBall("Glow-in-the-dark, 4cm", 0.4);

    Box[] boxes = new Box[3];
    boxes[0] = new Box("#1", books[1], books[3], books[4]);
    boxes[1] = new Box("#2", balls[3], balls[4]);
    boxes[2] = new Box("#3", books[1], books[2], balls[4]);

    for (int i = 0; i < 3; i++) {
      if (boxes[i] != null) {
        System.out.println(boxes[i]);
      }
    }
  }
}
