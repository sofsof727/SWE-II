package edu.hm.cs.bka.dev2.switchables;

/**
 * Klasse fuer eine schaltbare Lampe.
 */
public class Lightbulb implements Switchable {

  private boolean isOn = false;

  @Override
  public void toggle() {
    isOn = !isOn;
    if (isOn) {
      System.out.println("HELL");
    } else {
      System.out.println("DUNKEL");
    }
  }

}
