package edu.hm.cs.bka.dev2.switchables;

/**
 * Klasse fuer einen schaltbaren Mixer.
 */
public class Mixer implements Switchable {

  int status = 0;

  @Override
  public void toggle() {
    status = (status + 1) % 3;
    if (status == 1) {
      System.out.println("brmmmm");
    } else if (status == 2) {
      System.out.println("BRMMMM");
    } else {
      System.out.println("click");
    }

  }

}
