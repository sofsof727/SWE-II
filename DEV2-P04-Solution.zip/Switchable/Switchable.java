package edu.hm.cs.bka.dev2.switchables;

/**
 * Interface fuer alles, was man schalten kann.
 */
public interface Switchable {

  /**
   * Schaltet ein Gerät.
   */
  void toggle();
}
