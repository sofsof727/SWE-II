package edu.hm.cs.bka.dev2.smoothness;

/**
 * Exception, die signalisiert, dass eine Zahl keinen kleinen Faktor hat.
 *
 * @author katz.bastian
 */
public class NoSmallFactorException extends Exception {

  public NoSmallFactorException(String message) {
    super(message);
  }
}