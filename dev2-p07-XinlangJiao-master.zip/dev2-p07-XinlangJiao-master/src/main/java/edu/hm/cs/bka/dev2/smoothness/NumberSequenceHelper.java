package edu.hm.cs.bka.dev2.smoothness;

/**
 * Hilfsklassen für Zahlenfolgen.
 */
public class NumberSequenceHelper {

  /**
   * Liefert zurück, ob eine Zahl p-Smooth ist, d.h. ob sie nur Teiler kleiner oder gleich p hat.
   *
   * @param value Zahl
   * @param p     Grenze für Teiler
   * @return true genau dann, wenn die Zahl p-smooth ist.
   */
  public static boolean isSmooth(final int value, final int p) {
    // TODO: Implementieren Sie diese Methode!
    return true;
  }

  /**
   * Liefert den kleinsten Teiler (größer 1) einer Zahl zurück, wenn dieser unter einer Grenze
   * liegt.
   *
   * @param value      Zahl
   * @param maxDivisor Grenze für die Suche nach einem Teiler
   * @return Teiler
   * @throws NoSmallFactorException wenn kein Teiler kleiner oder gleich der Grenze existiert.
   */
  private static int findSmallestFactor(final int value, final int maxDivisor)
      throws NoSmallFactorException {
    if (value <= 1) {
      throw new IllegalArgumentException("Nur anwendbar für Werte >1.");
    }
    for (int divisor = 2; divisor <= maxDivisor; divisor++) {
      if (value % divisor == 0) {
        return divisor;
      }
    }
    throw new NoSmallFactorException(
        value + " hat keinen Teiler kleiner oder gleich " + maxDivisor);
  }
}
