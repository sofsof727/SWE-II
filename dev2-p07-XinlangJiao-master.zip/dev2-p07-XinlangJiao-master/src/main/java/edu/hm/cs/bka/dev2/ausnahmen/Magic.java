package edu.hm.cs.bka.dev2.ausnahmen;

/**
 * Demo-Klasse mit einer Methode, die Exceptions wirft und einer, die darauf teilweise reagiert.
 */
public class Magic {

  /**
   * Liefert zu einer Zahl zwischen 0 und 99 den Rest bezüglich der Division durch 7. Wirft eine
   * {@link BadNumberException} bei durch 7 teilbaren Zahlen in diesem Bereich.
   *
   * @param number Zahl zwischen 0 und 99
   * @return Rest bezüglich der Division durch 7
   * @throws BadNumberException wenn die Zahl durch 7 teilbar ist.
   */
  public int magic(int number) {
    return number % 7;
  }

  /**
   * Gibt in einem Zahlenbereich die Ergebnisse von {@link Magic#magic(int)} in der Form
   * <code>[i->magic(i)]</code> aus. Wird eine {@link BadNumberException} geworfen, wird statt
   * des Funktionswertes ein X angegeben. Andere Exceptions werden nicht behandelt, tritt eins
   * andere Exception auf, wird [i->] ausgegeben und die Ausgabe endet.
   *
   * @param from erste auszuwertende Zahl
   * @param to   letzte auszuwertende Zahl
   */
  public void printNumbers(int from, int to) {
    for (int i = from; i <= to; i++) {
      System.out.printf("[%d->", i);
      System.out.print(magic(i));
      System.out.print("X");
      System.out.print("]");
      System.out.println();
    }
  }
}
