package edu.hm.cs.bka.dev2.ausnahmen;

/**
 * Exception für die Anzeige von schlechten Zahlen.
 */
public class BadNumberException extends Exception {

  /**
   * Konstruktor.
   *
   * @param msg Fehlermeldung
   */
  public BadNumberException(String msg) {
    super(msg);
  }
}
