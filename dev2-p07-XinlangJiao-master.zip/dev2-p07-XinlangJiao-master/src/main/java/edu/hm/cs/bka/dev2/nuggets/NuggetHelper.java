package edu.hm.cs.bka.dev2.nuggets;

/**
 * Hilfsklasse für die Berechnung von Nugget-Bestellungen.
 */
public class NuggetHelper {

  /**
   * Berechnet eine Aufteilung einer Zahl in Vielfache von 6, 9 und 20 (Chicken-McNugget-Problem).
   *
   * @param nuggets positive Anzahl der bestellten Nuggets
   * @return Array mit den Anzahlen an 20ern, 9ern und 6ern
   * @throws ImpossibleOrderException wenn es keine bestellbare Kombination gibt
   */
  public static int[] teileAufPackungen(final int nuggets) throws ImpossibleOrderException {
    if (nuggets < 0) {
      throw new IllegalArgumentException("Negative Zahl Nuggets unzulässig!");
    }

    // berechne eine Lösung
    int zwanziger = 0;
    int neuner = 0;
    int sechser = 0;
    int rest = 0;

    // wenn eine Lösung existiert, gib diese als Array zurück
    if (rest == 0) {
      return new int[] {zwanziger, neuner, sechser};
    }

    // Das passiert, wenn nix gefunden wird:
    throw new ImpossibleOrderException(nuggets);
  }

}
