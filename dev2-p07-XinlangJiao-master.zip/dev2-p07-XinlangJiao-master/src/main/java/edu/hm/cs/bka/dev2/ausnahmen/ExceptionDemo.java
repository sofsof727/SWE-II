package edu.hm.cs.bka.dev2.ausnahmen;

/**
 * Demo-Klasse für Exception-Übungen.
 */
public class ExceptionDemo {

  /**
   * Beispielaufrufe von Magic.
   *
   * @param args nicht verwendet
   */
  public static void main(String[] args) {

    Magic magic = new Magic();

    System.out.println("==== sollte 5 ausgeben:");
    try {
      System.out.println(magic.magic(12)); // -> 5
    } catch (Exception e) {
      System.out.println(" " + e.getClass().getSimpleName());
    }

    System.out.println("==== sollte BadNumberException ausgeben:");
    try {
      System.out.println(magic.magic(21)); // -> Exception!
    } catch (Exception e) {
      System.out.println(" " + e.getClass().getSimpleName());
    }

    System.out.println("==== sollte IllegalArgumentException ausgeben:");
    try {
      System.out.println(magic.magic(102)); // -> Exception!
      System.out.println("Fehler, Exception fehlt!");
    } catch (Exception e) {
      System.out.println(" " + e.getClass().getSimpleName());
    }

    /* Beispiel für printNumbers!*/
    System.out.print("==== sollte zeilenweise ausgeben ");
    System.out.println("[96->5]/[97->6]/[98->X]/[99->1]/[100->] IllegalArgumentException");
    try {
      magic.printNumbers(96, 102);
      System.out.println("Fehler, Exception fehlt!");
    } catch (Exception e) {
      System.out.println(" " + e.getClass().getSimpleName());
    }
  }
}
