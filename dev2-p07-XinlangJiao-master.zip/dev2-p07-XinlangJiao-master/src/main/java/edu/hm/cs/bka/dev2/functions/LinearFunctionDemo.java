package edu.hm.cs.bka.dev2.functions;

/**
 * Demo-Code für Aufgabe 19.
 */
public class LinearFunctionDemo {

  /**
   * Beispielprogramm.
   *
   * @param args nicht verwendet.
   */
  public static void main(String[] args) throws Exception {

    // Beispielcode für toString und equals
    LinearFunction f = new LinearFunction(0, 0); // m=n=0 (x-Achse)
    LinearFunction g = new LinearFunction(1, -2); // m=1, n=-2
    System.out.print("Schnitt von " + f + " und " + g + ": ");
    System.out.println(f.intersection(g));
    System.out.println();

    // Beispielcode für IllegalArgumentException
    try {
      f.intersection(null);
      System.out.println("Exception fehlt!");
    } catch (IllegalArgumentException e) {
      System.out.println("Korrekte IllegalArgumentException geworfen!");
    } catch (Exception e) {
      System.out.println("Wirft falsche Exception! " + e.getClass());
    }
    System.out.println();

    // Beispielcode für Behandlung der Sonderfälle
    // Achtung! Der Code sollte Exceptions werfen
    LinearFunction h = new LinearFunction(0, 0);
    LinearFunction l = new LinearFunction(0, -2);
    System.out.print("Schnitt von " + h + " und " + l + ": ");
    try {
      System.out.println(h.intersection(l));
      System.out.println("Exception fehlt!");
    } catch (Exception e) {
      System.out.println("Exception geworfen: " + e.getClass());
    }

    System.out.print("Schnitt von " + h + " und " + h + ": ");
    try {
      System.out.println(h.intersection(h));
      System.out.println("Exception fehlt!");
    } catch (Exception e) {
      System.out.println("Exception geworfen: " + e.getClass());
    }
  }
}
