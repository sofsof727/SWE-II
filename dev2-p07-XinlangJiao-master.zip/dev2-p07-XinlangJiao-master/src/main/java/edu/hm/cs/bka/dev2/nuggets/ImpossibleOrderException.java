package edu.hm.cs.bka.dev2.nuggets;

/**
 * Exception, die signalisiert, dass eine Bestellung unmöglich ist.
 */
public class ImpossibleOrderException extends Exception {
  public ImpossibleOrderException(int nuggets) {
    super("Keine Bestellung von " + nuggets + " Nuggets möglich.");
  }
}
