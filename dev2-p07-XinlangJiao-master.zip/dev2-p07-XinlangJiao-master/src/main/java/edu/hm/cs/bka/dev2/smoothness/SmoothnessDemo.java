package edu.hm.cs.bka.dev2.smoothness;

/**
 * Demo-Code für Aufgabe 20.
 */
public class SmoothnessDemo {

  /**
   * Main-Methode. Gibt für die Werte p=2..11 jeweils die p-smoothen Zahlen bis 50 aus.
   *
   * @param args Parameter
   */
  public static void main(String[] args) {
    for (int p = 2; p <= 11; p++) {

      System.out.print(p + "-smooth values: \n  ");
      for (int i = 1; i < 50; i++) {
        if (NumberSequenceHelper.isSmooth(i, p)) {
          System.out.print(i + " ");
        }
      }
      System.out.println();
    }

  }

}
