package edu.hm.cs.bka.dev2.functions;

/**
 * Repräsentation eines Punktes.
 */
public class Point {
  private final double xvalue;
  private final double yvalue;

  public Point(double xvalue, double yvalue) {
    this.xvalue = xvalue;
    this.yvalue = yvalue;
  }

  public double getX() {
    return xvalue;
  }

  public double getY() {
    return yvalue;
  }

  @Override
  public String toString() {
    return "(" + xvalue + "/" + yvalue + ")";
  }

}
