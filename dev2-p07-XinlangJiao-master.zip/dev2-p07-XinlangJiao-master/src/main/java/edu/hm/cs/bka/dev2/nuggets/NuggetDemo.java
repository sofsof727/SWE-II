package edu.hm.cs.bka.dev2.nuggets;

import java.util.Scanner;

/**
 * Demo-Code für die Bestellung von Nuggets.
 */
public class NuggetDemo {

  /**
   * Beispielprogramm.
   *
   * @param args nicht verwendet.
   */
  public static void main(String[] args) {

    int nuggets = askForInteger("Anzahl Nuggets");
    try {
      int[] aufteilung = NuggetHelper.teileAufPackungen(nuggets);
      System.out.println(aufteilung[0] + "*20");
      System.out.println(aufteilung[1] + "* 9");
      System.out.println(aufteilung[2] + "* 6");
    } catch (ImpossibleOrderException e) {
      System.out.println("Das hat nicht funktioniert: " + e.getMessage());
    }
  }

  private static final Scanner in = new Scanner(System.in, "default");

  /**
   * Hilfsmethode zur Abfrage einer Ganzzahl von der Konsole.
   *
   * @param prompt Prompt vor Eingabe
   * @return Ganzzahl, Eingabe von der Kommandozeile.
   */
  public static int askForInteger(String prompt) {
    Integer result = null;
    do {
      System.out.print(prompt + " > ");
      String input = in.nextLine();
      try {
        result = Integer.parseInt(input);
      } catch (NumberFormatException e) {
        System.out.println("Ungueltige Eingabe!");
      }
    } while (result == null);
    return result;
  }
}

