package edu.hm.cs.bka.dev2.functions;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Aufgabe Lineare Funktionen / Parametervalidierung
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LinearFunction3Test {

  /**
   * Testet die Parametervalidierung der Schnitttpunkberechnung.
   */
  @Test
  public void illegalNullArgument() throws Exception {
    assertThrows(IllegalArgumentException.class, () -> {
      LinearFunction f = new LinearFunction(0, 0);

      LinearFunction g = null;
      f.intersection(g);
    });
  }

}
