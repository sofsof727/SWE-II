package edu.hm.cs.bka.dev2.ausnahmen;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MagicTest {

  @Test
  @Order(1)
  public void magicGibtRestZurueck() throws BadNumberException {
    assertEquals(6, new Magic().magic(27), "Rest wird nicht korrekt zurückgegeben.");
  }

  @Test
  @Order(2)
  public void magicWirftBadNumberException() {
    assertThrows(BadNumberException.class, () -> {
      new Magic().magic(63);
    });
  }

  @Test
  @Order(3)
  public void magicWirftIllegalArgumentExceptionUnterNull() {
    assertThrows(IllegalArgumentException.class, () -> {
      new Magic().magic(-1);
    });
  }

  @Test
  @Order(4)
  public void magicWirftIllegalArgumentExceptionAb100() {
    assertThrows(IllegalArgumentException.class, () -> {
      new Magic().magic(100);
    });
  }

  @Test
  @Order(5)
  public void magicWirftKeineIllegalArgumentExceptionBei1() throws BadNumberException {
    new Magic().magic(1);
  }

  @Test
  @Order(6)
  public void magicWirftKeineIllegalArgumentExceptionBei99() throws BadNumberException {
    new Magic().magic(99);
  }

  @Test
  @Order(7)
  public void magicWirftBadNumberExceptionBei0() {
    assertThrows(BadNumberException.class, () -> {
      new Magic().magic(0);
    });
  }

  @Test
  @Order(8)
  public void printNumbersEinfachesBeispiel() throws Exception {
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      new Magic().printNumbers(8, 11);
    });
    assertEquals("[8->1]\n[9->2]\n[10->3]\n[11->4]", out.strip(),
        "printNumbers gibt Zahlenpaare nicht korrekt aus.");
  }

  @Test
  @Order(9)
  public void printNumbersBeispielMitBadNumberException() throws Exception {
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      new Magic().printNumbers(13, 15);
    });
    assertEquals("[13->6]\n[14->X]\n[15->1]", out.strip(),
        "printNumbers gibt Zahlenpaare mit BadNumbersException nicht korrekt aus.");
  }

  @Test
  @Order(10)
  public void printNumbersBeispielMitIllegalException() throws Exception {
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      try {
        new Magic().printNumbers(99, 102);
        fail("printNumbers behandel IllegalArgumentException, die sollte unbehandelt bleiben!");
      } catch (IllegalArgumentException e) {
      }
    });
    assertEquals("[99->1]\n[100->]", out.strip(),
        "printNumbers beendet bei IllegalArgumentException nicht korrekt");
  }


}
