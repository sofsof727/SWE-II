package edu.hm.cs.bka.dev2.nuggets;


import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Testklasse für NuggetHelper.
 */
public class NuggetHelperOptionalTest {

  final static Integer[] NUGGET_NUMBERS = {1, 2, 3, 4, 5, 7, 8, 10, 11, 13, 14, 16, 17, 19, 22,
      23, 25, 28, 31, 34, 37, 43};

  private static final Duration TIMEOUT = Duration.ofSeconds(10);

  @Test
  public void shouldThrowExceptionForNuggetNumbers() {
    // TODO: Parametrierte Tests nutzen.
    for (int i : NUGGET_NUMBERS) {
      try {
        NuggetHelper.teileAufPackungen(i);
        fail("Exception erwartet! Es ist unmöglich, " + i + " Nuggets zu bestellen.");
      } catch (ImpossibleOrderException e) {
        // alles gut.
      }
    }
  }

  @Test
  public void shouldGiveValidResult() throws ImpossibleOrderException {
    List<Integer> l = IntStream.range(1, 100).boxed()
        .filter(i -> !Set.of(NUGGET_NUMBERS).contains(i)).collect(Collectors.toList());
    for (int i : l) {
      int[] result = NuggetHelper.teileAufPackungen(i);
      assertEquals(3, result.length, "Länge des Arrays sollte 3 sein");
      assertEquals(i, 20 * result[0] + 9 * result[1] + 6 * result[2],
          "Keine korrekte Aufteilung für " + i + " Nuggets: " + Arrays.toString(result));
    }
  }
}
