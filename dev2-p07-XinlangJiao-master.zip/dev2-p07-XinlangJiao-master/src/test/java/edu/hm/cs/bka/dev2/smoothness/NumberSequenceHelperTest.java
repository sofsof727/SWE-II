package edu.hm.cs.bka.dev2.smoothness;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import org.junit.jupiter.api.Test;

/** Testklasse für NumberSequenceHelper. */
public class NumberSequenceHelperTest {

  /** Testet Positivfälle. */
  @Test
  public void testSmoothnessPositives() {
    assertTimeoutPreemptively(
        Duration.ofSeconds(5),
        () -> {
    int[] elevensmooth = {1, 2, 3, 16, 28, 32, 90, 121, 125, 128};
    for (int val : elevensmooth) {
      assertTrue(
          NumberSequenceHelper.isSmooth(val, 11),
          val + " ist 11-smooth, wird falsch klassifiziert!");
    }
    });
  }

  /** Testet Negativfälle. */
  @Test
  public void testSmoothnessNegatives() {
    assertTimeoutPreemptively(
        Duration.ofSeconds(5),
        () -> {
          int[] elevensmooth = {13, 111, 65, 82, 106};
          for (int val : elevensmooth) {
            assertFalse(
                NumberSequenceHelper.isSmooth(val, 11),
                val + " ist nicht 11-smooth, wird falsch klassifiziert!");
          }
        });
  }
}
