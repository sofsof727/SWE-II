package edu.hm.cs.bka.dev2.functions;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Aufgabe Lineare Funktionen / equals
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LinearFunction2Test {

  /**
   * Testet die Auswertung einer Funktion.
   */
  @Test
  @Order(1)
  public void testValueAt() {
    LinearFunction f = new LinearFunction(2.5, 1);
    assertEquals(8.5, f.valueAt(3), 0.05);
  }

  /**
   * Testet die Schnittpunktberechnung im Standardfall.
   */
  @Test
  @Order(2)
  public void standardFall() throws Exception {
    LinearFunction f = new LinearFunction(0, 0);
    LinearFunction g = new LinearFunction(1, -2);
    System.out.println(f.intersection(g));
    assertEquals(new Point(2, 0), f.intersection(g));
  }

  @Test
  @Order(3)
  public void testEqualsSamePoint() throws Exception {
    Point a = new Point(1, 2);
    assertEquals(a, a);
  }

  @Test
  @Order(4)
  public void testEqualsIdenticalPoint() throws Exception {
    Point a = new Point(1, 2);
    Point b = new Point(1, 2);
    assertEquals(a, b);
  }

  @Test
  @Order(5)
  public void testNotEqualsDifferentPoints() throws Exception {
    Point a = new Point(1, 2);
    Point b = new Point(1, 3);
    assertNotEquals(a, b);
  }

  @Test
  @Order(6)
  public void testNotEqualsDifferentPoints2() throws Exception {
    Point a = new Point(1, 2);
    Point b = new Point(2, 2);
    assertFalse(a.equals(b));
  }

}
