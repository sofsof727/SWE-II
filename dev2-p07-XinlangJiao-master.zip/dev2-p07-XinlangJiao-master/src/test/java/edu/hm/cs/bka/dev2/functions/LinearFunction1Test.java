package edu.hm.cs.bka.dev2.functions;


import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Aufgabe Lineare Funktionen / toString
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LinearFunction1Test {


  @Test
  @Order(1)
  public void testBothPositive() {
    LinearFunction f = new LinearFunction(2.5, 1.5);
    assertEquals("2.5x+1.5", f.toString().replace(",", "."));
  }

  @Test
  @Order(2)
  public void testOffsetPositive() {
    LinearFunction f = new LinearFunction(-2.5, 1.5);
    assertEquals("-2.5x+1.5", f.toString().replace(",", "."));
  }

  @Test
  @Order(3)
  public void testSlopePositive() {
    LinearFunction f = new LinearFunction(2.5, -1.5);
    assertEquals("2.5x-1.5", f.toString().replace(",", "."));
  }

  @Test
  @Order(4)
  public void testBothNegative() {
    LinearFunction f = new LinearFunction(-2.5, -1.5);
    assertEquals("-2.5x-1.5", f.toString().replace(",", "."));
  }

  @Test
  @Order(5)
  public void testBothZero() {
    LinearFunction f = new LinearFunction(0.0, 0.0);
    assertEquals("0.0x+0.0", f.toString().replace(",", "."));
  }
}
