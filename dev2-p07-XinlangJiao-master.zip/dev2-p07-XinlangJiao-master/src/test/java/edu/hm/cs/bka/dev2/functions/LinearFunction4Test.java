package edu.hm.cs.bka.dev2.functions;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Aufgabe Lineare Funktionen / equals
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LinearFunction4Test {

    /**
     * Testet die Behandlung nicht-schneidender linearer Funktionen bei der Schnittberechnung.
     */
    @Test
    public void intersectParallelLines() throws Exception {
        LinearFunction f = new LinearFunction(0, 0);
        LinearFunction g = new LinearFunction(0, -2);
        try {
            f.intersection(g);
        } catch (Exception e) {
            // Hinweis: So testet man Exceptions normalerweise nicht! Da die Exception-Klassen noch
            // nicht existieren, muss die Exception gefangen werden, um den Namen zu überprüfen!
            assertEquals("NoIntersectionException", e.getClass().getSimpleName());
            return;
        }
        fail("Exception fehlt für parallele Geraden!");
    }

    /**
     * Testet die Behandlung identischer Geraden bei der Schnittberechnung.
     */
    @Test
    public void testIdenticalLines() throws Exception {
        LinearFunction f = new LinearFunction(0, 0);
        LinearFunction g = new LinearFunction(0, 0);
        try {
            f.intersection(g);
        } catch (Exception e) {
            // Hinweis: So testet man Exceptions normalerweise nicht! Da die Exception-Klassen noch
            // nicht existieren, muss die Exception gefangen werden, um den Namen zu überprüfen!
            assertEquals("IdenticalLinesException", e.getClass().getSimpleName());
            return;
        }
        fail("Exception fehlt für identische Geraden!");
    }

}
