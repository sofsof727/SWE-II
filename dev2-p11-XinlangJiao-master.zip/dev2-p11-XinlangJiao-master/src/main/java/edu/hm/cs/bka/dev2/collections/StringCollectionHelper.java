package edu.hm.cs.bka.dev2.collections;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

/**
 * Hilfsklasse zum Umgang mit Collections-Klassen zur Verwaltung von Strings.
 */
public class StringCollectionHelper {

  /**
   * Liefert alle Elemente einer Collection zurück, die einen gegebenen Teilstring (Muster)
   * enthalten. Dabei kann angegeben werden, ob die Groß/Kleinschreibung berücksichtigt werden
   * soll.
   *
   * @param strings       Collection mit Strings
   * @param muster        zu suchender (Teil)-String (Muster)
   * @param caseSensitive gibt an, ob Groß/Kleinschreibung berücksichtigt werden soll.
   * @return Alle Elemente der Collection, die das Muster als Teilstring enthalten.
   */
  public static Set<String> selectContaining(Collection<String> strings, String muster,
                                             boolean caseSensitive) {

    // TODO: Implementieren (Teilaufgabe 1)
    return null;
  }

  /**
   * Ersetzt direkte einfache oder mehrfache Wiederholungen eines Elements durch einen String der
   * Form "*3".
   */
  public static void countDuplicates(List<String> list) {
    // TODO: Implementieren (Teilaufgabe 2)
  }
}
