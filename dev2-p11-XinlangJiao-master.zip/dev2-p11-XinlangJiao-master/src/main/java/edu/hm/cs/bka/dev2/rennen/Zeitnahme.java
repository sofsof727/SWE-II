package edu.hm.cs.bka.dev2.rennen;

import java.util.*;
import org.apache.commons.collections4.bag.CollectionSortedBag;

/**
 * Klasse zum Registrieren von Teams und deren Zeiterfassung.
 */
public class Zeitnahme {

  /**
   * Registriert ein Team unter einer Team-Kennung.
   *
   * @param teamId Kennung
   * @param team   Läufer
   */
  public void register(String teamId, Team team) {
    // TODO: Implementierung ergänzen
  }

  /**
   * Speichert die Startzeit eines Teams.
   *
   * @param teamId    Kennung
   * @param startTime Startzeit (nach Beginn des Rennens)
   */
  public void start(String teamId, long startTime)  {
    // TODO: Implementierung ergänzen
  }

  /**
   * Speichert die Zielzeit eines Läufers.
   *
   * @param teamId Kennung
   * @param stopTime Zielzeit (ab Beginn des Rennens)
   */
  public void finish(String teamId, long stopTime)  {
    // TODO: Implementierung ergänzen
  }

  /**
   * Liefert eine Collection mit allen Teams, die registriert, aber nicht gestartet sind.
   *
   * @return registrierte, nicht gestartete Teams
   */
  public Collection<Team> getWaiting() {
    // TODO: Implementierung ergänzen, echte Collection zurückliefern
    return Collections.emptySet();
  }

  /**
   * Liefert eine Collection mit allen Teams, die gestartet, aber nicht im Ziel sind.
   *
   * @return laufende Teams
   */
  public Collection<Team> getRunning() {
    // TODO: Implementierung ergänzen, echte Collection zurückliefern
    return Collections.emptySet();
  }

  /**
   * Liefert die Gesamtzeit eines Läufers.
   *
   * @param teamId Kennung
   * @return Differenz aus Zielzeit und Startzeit
   */
  public long getTime(String teamId) {
    // TODO: Implementierung ergänzen
    return 0;
  }

  /**
   * Liefert eine Map, die Teams, die schon im Ziel sind, auf ihre Zielzeit abbildet.
   *
   * @return Abbildung Teams-Gesamtzeit
   */
  public Map<Team, Long> getFinished() {
    // TODO: Implementierung ergänzen
    return null;
  }

}
