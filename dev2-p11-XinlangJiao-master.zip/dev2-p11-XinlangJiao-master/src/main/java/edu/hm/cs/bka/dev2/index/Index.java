package edu.hm.cs.bka.dev2.index;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Klasse zum Aufbau eines Textindex, d.h. zur Speicherung der Information, auf welchen Seiten eines
 * Buches ein Wort vorkommt.
 *
 * @author katz.bastian
 */
public class Index {

  /**
   * Fügt ein Vorkommnis zum Index hinzu, d.h. ergänzt den Eintrag zu einem Wort um eine
   * Seitenzahl.
   *
   * @param word Wort
   * @param page Seitenzahl
   */
  public void addOccurrence(final String word, final int page) {
    // TODO: Implementierung ergänzen
  }

  /**
   * Liefert einen Eintrag von der Form "Wort: 1, 3, 7, 8".
   *
   * @param word Wort
   * @return Textueller Eintrag aus Wort und den Vorkommnissen
   */
  public String getEntry(String word) {
    // TODO: Implementierung ergänzen
    return null;
  }
}
