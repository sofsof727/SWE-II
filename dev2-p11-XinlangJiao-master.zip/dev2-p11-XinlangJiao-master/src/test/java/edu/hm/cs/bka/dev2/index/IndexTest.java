package edu.hm.cs.bka.dev2.index;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class IndexTest {

  /**
   * Testet Standardfall.
   */
  @Test
  @Order(1)
  public void testExample() {
    Index index = new Index();
    index.addOccurrence("Rotationsellipsoid", 5);
    index.addOccurrence("Paraboloid", 8);
    index.addOccurrence("Rotationsellipsoid", 8);
    index.addOccurrence("Paraboloid", 10);
    index.addOccurrence("Hyperboloid", 17);
    assertEquals("Hyperboloid: 17", index.getEntry("Hyperboloid"));
    assertEquals("Paraboloid: 8, 10", index.getEntry("Paraboloid"));
    assertEquals("Rotationsellipsoid: 5, 8", index.getEntry("Rotationsellipsoid"));
  }

  /**
   * Testet den Fall, dass mindestens ein Eintrag auf einer Seite mehrfach vorkommt.
   */
  @Test
  @Order(2)
  public void testManyOccurrencesOnOnePage() {
    Index index = new Index();
    index.addOccurrence("Rotationsellipsoid", 5);
    index.addOccurrence("Rotationsellipsoid", 5);
    index.addOccurrence("Rotationsellipsoid", 8);
    assertEquals("Rotationsellipsoid: 5, 8", index.getEntry("Rotationsellipsoid"));
  }

  /**
   * Testet, dass die Indexbildung auch funktioniert, wenn die Einträge nicht in der richtigen
   * Reihenfolge aufgenommen werden.
   */
  @Test
  @Order(3)
  public void testIndexEntryBadOrder() {
    Index index = new Index();
    index.addOccurrence("Hund", 6);
    index.addOccurrence("Berg", 2);
    index.addOccurrence("Hund", 4);
    index.addOccurrence("Berg", 1);
    index.addOccurrence("Hund", 7);
    assertEquals("Hund: 4, 6, 7", index.getEntry("Hund"));
  }

  @Test
  @Order(4)
  public void testIndexEntryNonExistent() {
    Index index = new Index();
    index.addOccurrence("Hund", 6);
    index.addOccurrence("Berg", 2);
    index.addOccurrence("Hund", 4);
    index.addOccurrence("Berg", 1);
    index.addOccurrence("Hund", 7);
    assertEquals("Floh: ---", index.getEntry("Floh"));
  }
}
