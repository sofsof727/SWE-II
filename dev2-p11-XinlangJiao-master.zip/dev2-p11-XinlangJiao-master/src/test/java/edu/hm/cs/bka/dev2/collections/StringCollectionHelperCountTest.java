package edu.hm.cs.bka.dev2.collections;

import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StringCollectionHelperCountTest {

    @Test
    @Order(1)
    public void testReplaceDuplicatesSample1() {
        List<String> names = Lists.newArrayList("Tick", "Trick", "Trick", "Trick", "Track",
                "Donald", "Donald", "Trick");

        List<String> expected = Lists.newArrayList("Tick", "Trick", "*3", "Track",
                "Donald", "*2", "Trick");

        StringCollectionHelper.countDuplicates(names);
        assertEquals(names, expected);
    }

    @Test
    @Order(2)
    public void testReplaceDuplicatesAtStart() {
        List<String> names = Lists.newArrayList("Tick", "Tick", "Tick", "Boom");

        List<String> expected = Lists.newArrayList("Tick", "*3", "Boom");

        StringCollectionHelper.countDuplicates(names);
        assertEquals(names, expected);
    }
    
    @Test
    @Order(3)
    public void testReplaceDuplicatesAtEnd() {
        List<String> names = Lists.newArrayList("Schuss", "Toor", "Toor");

        List<String> expected = Lists.newArrayList("Schuss", "Toor", "*2");

        StringCollectionHelper.countDuplicates(names);
        assertEquals(names, expected);
    }
    
    
}
