package edu.hm.cs.bka.dev2.collections;


import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.Set;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StringCollectionHelperContainsTest {

  @Test
  @Order(1)
  public void testContainsSample1() {
    Collection<String> strings = Lists.newArrayList("Eins", "Zwei", "DREI", "vier");

    Set<String> selected = StringCollectionHelper.selectContaining(strings, "ei", false);
    assertNotNull(selected);
    assertEquals(3, selected.size());
    assertTrue(selected.contains("Zwei"));
    assertTrue(selected.contains("Eins"));
    assertTrue(selected.contains("DREI"));
  }


  @Test
  @Order(2)
  public void testContainsSample2() {
    Collection<String> strings = Lists.newArrayList("Eins", "Zwei", "DREI", "vier");

    Set<String> selected = StringCollectionHelper.selectContaining(strings, "ei", true);
    assertNotNull(selected);
    assertEquals(1, selected.size());
    assertTrue(selected.contains("Zwei"));
  }

  @Test
  @Order(3)
  public void testContainsSample3() {
    Collection<String> strings = Lists.newArrayList("Eins", "Zwei", "DREI", "vier");

    Set<String> selected = StringCollectionHelper.selectContaining(strings, "e", true);
    assertNotNull(selected);
    assertEquals(2, selected.size());
    assertTrue(selected.contains("Zwei"));
    assertTrue(selected.contains("vier"));
  }

  @Test
  @Order(4)
  public void testContainsSample4() {
    Collection<String> strings = Lists.newArrayList("Eins", "Zwei", "DREI", "vier");

    Set<String> selected = StringCollectionHelper.selectContaining(strings, "y", false);
    assertNotNull(selected);
    assertEquals(0, selected.size());
  }

  @Test
  @Order(5)
  public void testContainsUppercaseMuster() {
    Collection<String> strings = Lists.newArrayList("Eins", "Zwei", "DREI", "vier");

    Set<String> selected = StringCollectionHelper.selectContaining(strings, "W", false);
    assertNotNull(selected);
    assertEquals(1, selected.size());
    assertTrue(selected.contains("Zwei"));
  }
}
