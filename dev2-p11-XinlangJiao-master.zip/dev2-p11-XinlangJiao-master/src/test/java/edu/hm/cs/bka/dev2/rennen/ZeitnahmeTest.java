package edu.hm.cs.bka.dev2.rennen;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ZeitnahmeTest {

  @Test
  @Order(1)
  public void einfacherDurchlaufFunktioniert() {
    Zeitnahme tk = new Zeitnahme();
    tk.register("D", new Team("XX"));
    tk.start("D", 90);
    tk.finish("D", 120);
    assertEquals(30, tk.getTime("D"));
  }

  @Test
  @Order(2)
  public void unregistrierterStartWirftExeption() {
    assertThrows(RuntimeException.class, () -> {
      Zeitnahme tk = new Zeitnahme();
      tk.start("FF", 20);
    });
  }


  @Test
  @Order(3)
  public void ungestarteterZieleinlaufWirftException() {
    assertThrows(RuntimeException.class, () -> {
      Zeitnahme tk = new Zeitnahme();
      tk.register("FF", new Team("Firefox"));
      tk.finish("FF", 20);
    });
  }

  @Test
  @Order(4)
  public void standardBeispiel() {
    Zeitnahme Zeitnahme = new Zeitnahme();

    Zeitnahme.register("RR", new Team("Road Team"));
    Zeitnahme.register("COYOTE", new Team("Wile E. Coyote"));

    Zeitnahme.start("RR", 320);
    Zeitnahme.register("SAM", new Team("Yosemite Sam"));
    Zeitnahme.register("FUDD", new Team("Elmer Fudd"));
    Zeitnahme.start("COYOTE", 510);
    Zeitnahme.finish("RR", 580);
    Zeitnahme.start("FUDD", 600);
    Zeitnahme.finish("FUDD", 730);

    // TODO: NPEs durch Assertions verhindern.
    assertEquals(1, Zeitnahme.getWaiting().size());
    assertTrue(Zeitnahme.getWaiting().contains(new Team("Yosemite Sam")));

    assertEquals(1, Zeitnahme.getRunning().size());
    assertTrue(Zeitnahme.getRunning().contains(new Team("Wile E. Coyote")));

    assertEquals(2, Zeitnahme.getFinished().size());
    assertTrue(Zeitnahme.getFinished().containsKey(new Team("Road Team")));
    assertTrue(Zeitnahme.getFinished().containsKey(new Team("Elmer Fudd")));
    assertEquals(260L, Zeitnahme.getFinished().get(new Team("Road Team")).longValue());
    assertEquals(130L, Zeitnahme.getFinished().get(new Team("Elmer Fudd")).longValue());
  }

}
