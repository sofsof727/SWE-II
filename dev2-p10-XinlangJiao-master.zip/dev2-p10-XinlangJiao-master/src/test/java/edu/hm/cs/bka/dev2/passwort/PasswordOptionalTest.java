package edu.hm.cs.bka.dev2.passwort;

import edu.hm.cs.bka.dev2.geometry.GeometryHelper;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testklasse für {@link GeometryHelper}.
 *
 * @author katz.bastian
 */
public class PasswordOptionalTest {

  private static final String STANDARD_INITIAL_PASSWORD = "4RoUbAd0Ur";
  private static final String STANDARD_CHANGED_PASSWORD = "As4e$i#S";

  /**
   * Testet die Erzeugung eines Passwort-Objektes.
   *
   * @throws BadPasswordException nicht erwartet.
   */
  @Test
  @Order(1)
  public void testStandardCreation() throws BadPasswordException {
    Password password = new Password(STANDARD_INITIAL_PASSWORD);
    assertEquals(STANDARD_INITIAL_PASSWORD, password.getPassword());
  }

  /**
   * Testet die Erzeugung eines Passwort-Objektes mit leerem Passwort.
   *
   * @throws BadPasswordException erwartet.
   */
  @Test
  @Order(2)
  public void testEmptyCreation() throws BadPasswordException {
    assertThrows(BadPasswordException.class, () -> new Password(""));
  }

  /**
   * Testet die Erzeugung eines Passwort-Objektes mit {@code null} als Passwort.
   *
   * @throws IllegalArgumentException erwartet.
   */
  @Test
  @Order(3)
  public void testNullCreation() throws BadPasswordException {
    assertThrows(IllegalArgumentException.class, () -> new Password(null));
  }

  /**
   * Testet die Änderung eines Passworts.
   *
   * @throws BadPasswordException nicht erwartet.
   */
  @Test
  @Order(4)
  public void testChangePasswort() throws BadPasswordException {
    Password password = new Password(STANDARD_INITIAL_PASSWORD);
    password.changePassword(STANDARD_CHANGED_PASSWORD);
    assertEquals(STANDARD_CHANGED_PASSWORD, password.getPassword());
  }

  /**
   * Testet die mehrfache Änderung eines Passworts.
   *
   * @throws BadPasswordException nicht erwartet.
   */
  @Test
  @Order(5)
  public void testChangePasswortRepeatedly() throws BadPasswordException {
    Password password = new Password(STANDARD_INITIAL_PASSWORD);
    password.changePassword(STANDARD_CHANGED_PASSWORD);
    password.changePassword("/76(adsdga76/§");
    password.changePassword("gallery-horse-battery-staple");
    password.changePassword("7$9DöKJS)");
    password.changePassword("pOadabcu(");
    password.changePassword("09agg76a6(272");
  }

  /**
   * Testet die Änderung eines Passworts mit einem Passwort von der Blocklist. Achtung: Die
   * Blacklist enthält die Worte nur in Kleinschreibung; trotzdem sollen Passwörter abgelehnt
   * werden, die sich nur in Groß- und Kleinschreibung von Wörtern auf der Blocklist unterscheiden.
   *
   * @throws BadPasswordException erwartet.
   */
  @Test
  @Order(6)
  public void testBlocklist() throws BadPasswordException {
    assertThrows(
        BadPasswordException.class,
        () -> {
          assertFalse(Password.getBlockList().contains("Test123"));
          assertTrue(Password.getBlockList().contains("test123"));
          assertTrue(Password.getBlockList().contains("password"));
          assertTrue(Password.getBlockList().contains("passwort"));
          assertTrue(Password.getBlockList().contains("geheim"));
          Password password = new Password(STANDARD_INITIAL_PASSWORD);
          password.changePassword("Test123");
        });
  }

  /** Testet, dass die Anzahl unterschiedlicher Zeichen in einem Passwort korrekt ermittelt wird. */
  @Test
  @Order(7)
  public void testCountCharacters() {
    assertEquals(7, Password.getNumberOfDifferentCharacters("Password"));
  }

  /**
   * Testet, dass Passwörter abgelehnt werden, die nicht mindestens 6 verschiedene Zeichen
   * enthalten.
   *
   * @throws BadPasswordException erwartet.
   */
  @Test
  @Order(8)
  public void testDifferentCharacters() throws BadPasswordException {
    assertThrows(
        BadPasswordException.class,
        () -> {
          Password password = new Password(STANDARD_INITIAL_PASSWORD);
          password.changePassword("abcdeabcde");
        });
  }

  /**
   * Testet, dass die Wiederholung von Passwörtern möglich ist, wenn mindestens 5 Passwörter
   * dazwischenliegen.
   *
   * @throws BadPasswordException nicht erwartet.
   */
  @Test
  @Order(9)
  public void testRepetitionAllowed() throws BadPasswordException {
    Password password = new Password(STANDARD_INITIAL_PASSWORD);
    password.changePassword(STANDARD_CHANGED_PASSWORD);
    password.changePassword("/76(adsdga76/§");
    password.changePassword("gallery-horse-battery-staple");
    password.changePassword("7$9DöKJS)");
    password.changePassword("pOadabcu(");
    password.changePassword("09agg76a6(272");
    password.changePassword(STANDARD_CHANGED_PASSWORD);
    password.changePassword("/76(adsdga76/§");
    password.changePassword("gallery-horse-battery-staple");
    password.changePassword("7$9DöKJS)");
    password.changePassword("pOadabcu(");
    password.changePassword("09agg76a6(272");
  }

  /**
   * Testet, dass die Wiederholung von Passwörtern nicht möglich ist, wenn das Passwort zu den
   * letzten 5 Passwörtern gehörte.
   *
   * @throws BadPasswordException erwartet.
   */
  @Test
  @Order(10)
  public void testRepetitionNotAllowed() throws BadPasswordException {
    assertThrows(
        BadPasswordException.class,
        () -> {
          Password password = new Password(STANDARD_INITIAL_PASSWORD);
          password.changePassword(STANDARD_CHANGED_PASSWORD);
          password.changePassword("/76(adsdga76/§");
          password.changePassword("gallery-horse-battery-staple");
          password.changePassword("7$9DöKJS)");
          password.changePassword("pOadabcu(");
          password.changePassword(STANDARD_CHANGED_PASSWORD);
        });
  }

  /**
   * Testet, dass die Wiederholung von Passwörtern möglich ist, wenn mindestens 5 Passwörter
   * dazwischenliegen.
   *
   * @throws BadPasswordException erwartet.
   */
  @Test
  @Order(11)
  public void testThirdRepetition() throws BadPasswordException {
    assertThrows(
        BadPasswordException.class,
        () -> {
          Password password = new Password(STANDARD_INITIAL_PASSWORD);
          password.changePassword(STANDARD_CHANGED_PASSWORD);
          password.changePassword("/76(adsdga76/§");
          password.changePassword("gallery-horse-battery-staple");
          password.changePassword("7$9DöKJS)");
          password.changePassword("pOadabcu(");
          password.changePassword("09agg76a6(272");
          password.changePassword(STANDARD_CHANGED_PASSWORD);
          password.changePassword("/76(adsdga76/§");
          password.changePassword("gallery-horse-battery-staple");
          password.changePassword("7$9DöKJS)");
          password.changePassword("pOadabcu(");
          password.changePassword("09agg76a6(272");
          password.changePassword(STANDARD_CHANGED_PASSWORD);
        });
  }
}
