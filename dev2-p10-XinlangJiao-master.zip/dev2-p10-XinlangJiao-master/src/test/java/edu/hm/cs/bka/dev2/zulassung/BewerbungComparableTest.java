package edu.hm.cs.bka.dev2.zulassung;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Testklasse für {@link Bewerbung}.
 *
 * @author katz.bastian
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BewerbungComparableTest {

  @Test
  @Order(1)
  public void implementiertComparable() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
  }

  @Test
  @Order(2)
  public void vergleichtKorrektMitKleinererNote() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Minnie", 1.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
    Comparable<Bewerbung> c = (Comparable<Bewerbung>) a;
    assertEquals(1, c.compareTo(b), "Vergleich mit kleinerer Note muss 1 liefern!");
  }

  @Test
  @Order(3)
  public void vergleichtKorrektMitGroessererNote() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Minnie", 4.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
    Comparable<Bewerbung> c = (Comparable<Bewerbung>) a;
    assertEquals(-1, c.compareTo(b), "Vergleich mit größerer Note muss -1 liefern!");
  }

  @Test
  @Order(4)
  public void vergleichtKorrektMitGroesseremNamenBeiGleicherNote() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Minnie", 3.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
    Comparable<Bewerbung> c = (Comparable<Bewerbung>) a;
    assertTrue(c.compareTo(b) < 0,
        "Vergleich mit gleicher Note und lexikographisch größerem Namen " +
            "muss negativen Wert liefern!");
  }

  @Test
  @Order(5)
  public void vergleichtKorrektMitKleineremNamenBeiGleicherNote() {
    Bewerbung a = new Bewerbung("Minnie", 3.4);
    Bewerbung b = new Bewerbung("Micky", 3.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
    Comparable<Bewerbung> c = (Comparable<Bewerbung>) a;
    assertTrue(c.compareTo(b) > 0,
        "Vergleich mit gleicher Note und lexikographisch kleinerem Namen muss 1 liefern!");
  }

  @Test
  @Order(6)
  public void vergleichtKorrektMitGleichemObjekt() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Micky", 3.4);
    assertTrue(a instanceof Comparable<?>, "Comparable muss implementiert werden!");
    Comparable<Bewerbung> c = (Comparable<Bewerbung>) a;
    assertEquals(0, c.compareTo(b), "Vergleich mit gleichem Objekt muss 0 liefern!");
  }

}
