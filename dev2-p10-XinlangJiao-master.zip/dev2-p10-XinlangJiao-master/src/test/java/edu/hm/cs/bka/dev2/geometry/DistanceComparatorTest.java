package edu.hm.cs.bka.dev2.geometry;

import static org.junit.jupiter.api.Assertions.*;


import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Testklasse für {@link GeometryHelper}.
 *
 * @author katz.bastian
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DistanceComparatorTest {

  @Test
  @Order(1)
  public void vergleichtKorrektKleiner()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Constructor<DistanceComparator> constructor =
        (Constructor<DistanceComparator>) assertPublicConstructor(DistanceComparator.class,
            Point.class);

    DistanceComparator dc = constructor.newInstance(new Point(5, 8));

    assertTrue(dc.compare(new Point(6, 9), new Point(4, 6)) < 0,
        "Punkt (6,9) liegt dichter an (5,8) als (4,6). Das Ergebnis des Vergleichs sollte negativ sein!");
  }

  @Test
  @Order(2)
  public void vergleichtKorrektGroesser()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Constructor<DistanceComparator> constructor =
        (Constructor<DistanceComparator>) assertPublicConstructor(DistanceComparator.class,
            Point.class);

    DistanceComparator dc = constructor.newInstance(new Point(5, 8));

    assertTrue(dc.compare(new Point(4, 6), new Point(6, 9)) > 0,
        "Punkt (4,6) liegt dichter an (5,8) als (6,9). Das Ergebnis des Vergleichs sollte positiv sein!");
  }

  @Test
  @Order(2)
  public void vergleichtKorrektGleich()
      throws IllegalAccessException, InvocationTargetException, InstantiationException {
    Constructor<DistanceComparator> constructor =
        (Constructor<DistanceComparator>) assertPublicConstructor(DistanceComparator.class,
            Point.class);

    DistanceComparator dc = constructor.newInstance(new Point(5, 8));

    assertTrue(dc.compare(new Point(4, 6), new Point(3, 9)) == 0,
        "Das Ergebnis eines Vergleiches zweier Punkte mit denselben Koordinaten sollte 0 sein!");
  }
}
