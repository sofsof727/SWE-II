package edu.hm.cs.bka.dev2.zulassung;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Testklasse für {@link Bewerbung}.
 *
 * @author katz.bastian
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BewerbungEqualsHashCodeTest {

  @Test
  @Order(1)
  public void sollteSelbenHashCodeFuerGleicheBewerbungenLiefern() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Micky", 3.4);
    assertEquals(a.hashCode(), b.hashCode(),
        "Methode hashCode() fehlt oder stimmt nicht in Bewerbung!");
  }

  @Test
  @Order(2)
  public void equalsSollteTrueLiefernBeiGleicherBewerbung() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Micky", 3.4);
    assertTrue(a.equals(b), "Methode equals() fehlt oder stimmt nicht in Bewerbung!");
  }

  @Test
  @Order(3)
  public void equalsSollteFalseLiefernBeiUnterschiedlichemNamen() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Mirky", 3.4);
    assertFalse(a.equals(b), "Methode equals() fehlt oder stimmt nicht in Bewerbung!");
  }

  @Test
  @Order(4)
  public void equalsSollteFalseLiefernBeiUnterschiedlicherNote() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    Bewerbung b = new Bewerbung("Micky", 3.3);
    assertFalse(a.equals(b), "Methode equals() fehlt oder stimmt nicht in Bewerbung!");
  }

  @Test
  @Order(5)
  public void equalsSollteFalseLiefernBeiNull() {
    Bewerbung a = new Bewerbung("Micky", 3.4);
    assertFalse(a.equals(null), "Methode equals() fehlt oder stimmt nicht in Bewerbung!");
  }

}
