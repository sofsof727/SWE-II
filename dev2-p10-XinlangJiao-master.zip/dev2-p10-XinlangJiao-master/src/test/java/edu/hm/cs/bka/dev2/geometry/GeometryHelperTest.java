package edu.hm.cs.bka.dev2.geometry;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Testklasse für {@link GeometryHelper}.
 *
 * @author katz.bastian
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class GeometryHelperTest {

  @Test
  @Order(1)
  public void sollteNurPunkteInKorrekterEntfernungLiefern() {
    List<Point> points = new ArrayList<>();
    points.add(new Point(7, 5));
    points.add(new Point(-3, 7));
    points.add(new Point(0, 0));
    points.add(new Point(2, 3));

    List<Point> closePoints = GeometryHelper.pointsInDistance(new Point(2, 2), 4, points);
    assertNotNull(closePoints, "pointsInDistance gibt null zurück!");
    assertEquals(2, closePoints.size());
    assertTrue(closePoints.contains(new Point(0, 0)),
        "(0,0) ist keine 4 Einheiten von (2,2) entfernt.");
    assertTrue(closePoints.contains(new Point(2, 3)),
        "(2,3) ist keine 4 Einheiten von (2,2) entfernt.");
    assertFalse(closePoints.contains(new Point(7, 5)),
        "(7,5) ist mehr als 4 Einheiten von (2,2) entfernt.");
    assertFalse(closePoints.contains(new Point(-3, 7)),
        "(-3,7) ist mehr als 4 Einheiten von (2,2) entfernt.");
  }

  @Test
  @Order(2)
  public void solltePunkteInAufsteigenderEntfernungLiefern() {
    List<Point> points = new ArrayList<Point>();
    points.add(new Point(-1, -1));
    points.add(new Point(1, 3));
    points.add(new Point(7, 7));
    points.add(new Point(6, -2));
    points.add(new Point(2, 2));
    points.add(new Point(4, 0));

    List<Point> closePoints = GeometryHelper.pointsInDistance(new Point(2, 2), 7, points);
    assertNotNull(closePoints, "pointsInDistance gibt null zurück!");
    assertEquals(5, closePoints.size());
    double d = -1.0;
    for (Point p: closePoints) {
      assertTrue(d<=p.distanceTo(new Point(2,2)), "Punkte sind nicht nach Abstand zu (2,2) sortiert: " + closePoints);
      d = p.distanceTo(new Point(2,2));
    }
  }

}
