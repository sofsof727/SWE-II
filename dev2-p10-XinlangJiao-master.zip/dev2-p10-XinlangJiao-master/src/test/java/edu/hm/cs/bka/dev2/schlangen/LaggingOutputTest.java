package edu.hm.cs.bka.dev2.schlangen;

import static org.junit.jupiter.api.Assertions.*;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Testklasse für {@link LaggingOutput}.
 *
 * @author katz.bastian
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class LaggingOutputTest {

  @Test
  @Order(1)
  public void sollteNichtDirektAusgeben() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s = SystemLambda.tapSystemOutNormalized(() -> lo.add("heyo"));
    assertEquals("", s, "LaggingOutput sollte nicht direkt ausgeben!");
  }

  @Test
  @Order(2)
  public void sollteEingabeBeiNextAusgeben() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("yay");
              lo.next();
            });
    assertTrue(s.strip().contains("yay"), "Add/next sollte genau eine Eingabe ausgeben!");
  }

  @Test
  @Order(3)
  public void sollteErsteEingabeBeiErstemNextAusgeben() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("zap");
              lo.add("zip");
              lo.next();
            });
    assertTrue(s.strip().contains("zap"), "add/add/next sollte genau eine Eingabe ausgeben!");
    assertFalse(s.strip().contains("zip"), "add/add/next sollte genau eine Eingabe ausgeben!");
  }

  @Test
  @Order(4)
  public void sollteEingabenInRichtigerReihenfolgeAusgeben() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("zip");
              lo.add("zap");
              lo.next();
              lo.next();
            });
    assertTrue(s.strip().contains("zip"), "add/add/next/next sollte genau zwei Eingaben ausgeben!");
    assertTrue(s.strip().contains("zap"), "add/add/next/next sollte genau zwei Eingaben ausgeben!");
  }

  @Test
  @Order(5)
  public void sollteNichtsAusgebenWennLeer() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("ugs");
              lo.next();
              lo.next();
            });
    assertTrue(s.strip().equals("ugs"), "add/next/next sollte genau eine Zeile ausgeben!");
  }

  @Test
  @Order(6)
  public void sollteWartendesElementEntfernen() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("abra");
              lo.add("kadabra");
              lo.revoke();
              lo.add("simsa");
              lo.next();
              lo.next();
              lo.next();
            });
    assertTrue(
        s.strip().contains("abra"),
        "add/add/revoke/add/next/next/next sollte nur erstes und drittes add ausgeben");
    assertTrue(
        s.strip().contains("simsa"),
        "add/add/revoke/add/next/next/next sollte nur erstes und drittes add ausgeben");
    assertFalse(
        s.strip().contains("kadabra"),
        "add/add/revoke/add/next/next/next sollte nur erstes und drittes add ausgeben");
  }

  @Test
  @Order(7)
  public void sollteKeinenFehlerWerfenWennBeiLeererSchlangeRevokedWird() {
    LaggingOutput lo = new LaggingOutput(3);
    lo.revoke();
  }

  @Test
  @Order(8)
  public void sollteSelbstaendigAusgebenWennSchlangeUeberlaeuft() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("Raphael");
              lo.add("Donatello");
              lo.add("Leonardo");
              lo.add("Michelangelo");
            });
    assertTrue(
        s.strip().contains("Raphael"),
        "add/add/add/add sollte bei Schlange mit Laenge 3 automatisch erste Eingabe ausgeben");
    assertFalse(
        s.strip().contains("Donatello"),
        "add/add/add/add sollte bei Schlange mit Laenge 3 automatisch nur erste Eingabe ausgeben");
  }

  @Test
  @Order(9)
  public void flushSollteAllesAusgeben() throws Exception {
    LaggingOutput lo = new LaggingOutput(3);
    String s =
        SystemLambda.tapSystemOutNormalized(
            () -> {
              lo.add("Raphael");
              lo.add("Donatello");
              lo.add("Leonardo");
              lo.next();
              lo.flush();
            });
    assertTrue(
        s.strip().contains("Raphael"), "add/add/add/next/flush sollte alle Eingaben ausgeben");
    assertTrue(
        s.strip().contains("Donatello"), "add/add/add/next/flush sollte alle Eingaben ausgeben");
    assertTrue(
        s.strip().contains("Leonardo"), "add/add/add/next/flush sollte alle Eingaben ausgeben");
  }
}
