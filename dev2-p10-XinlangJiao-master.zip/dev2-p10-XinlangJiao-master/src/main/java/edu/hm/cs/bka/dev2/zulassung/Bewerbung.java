package edu.hm.cs.bka.dev2.zulassung;

/**
 * Klasse zur Speicherung einer Bewerbung.
 */
public class Bewerbung {

  private final String name;
  private final double note;

  /**
   * Konstruktor.
   *
   * @param name Name
   * @param note Note des Abschlusszeugnisses
   */
  public Bewerbung(String name, double note) {
    this.name = name;
    this.note = note;
  }

  public String getName() {
    return name;
  }

  public double getNote() {
    return note;
  }

  @Override
  public String toString() {
    return name + " (" + note + ")";
  }
}
