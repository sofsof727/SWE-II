package edu.hm.cs.bka.dev2.schlangen;

/**
 * Beispielklasse für LaggingOutput.
 */
public class LaggingOutputDemo {

  /**
   * Demo-Code.
   *
   * @param args wird nicht genutzt.
   */
  public static void main(String[] args) {

    LaggingOutput output = new LaggingOutput(3);

    output.add("Ich"); // keine Ausgabe
    output.add("hoffe"); // keine Ausgabe
    output.next(); // Ausgabe: "Ich"
    output.revoke(); // keine Ausgabe
    output.add("wünsche"); // keine Ausgabe
    output.add("Ihnen"); // keine Ausgabe
    output.add("viel"); // keine Ausgabe
    output.add("Spaß!"); // Ausgabe "wünsche"

    System.out.println("--"); // Nur Markierung der Ausgabe
    output.flush(); // Ausgabe "Ihnen", "viel" und "Spaß!"
  }

}
