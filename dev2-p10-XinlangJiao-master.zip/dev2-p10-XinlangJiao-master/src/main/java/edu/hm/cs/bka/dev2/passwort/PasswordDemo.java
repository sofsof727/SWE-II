package edu.hm.cs.bka.dev2.passwort;

import java.nio.charset.Charset;
import java.util.Scanner;

/**
 * Demo zum Ausprobieren der Passwortregeln.
 */
public class PasswordDemo {

  /**
   * Demo method.
   *
   * @param args ignored.
   */
  public static void main(String[] args) {

    Scanner in = new Scanner(System.in, Charset.defaultCharset());
    Password password = null;

    while (true) {
      try {
        System.out.print(password == null ? "Initiales Passwort (q beendet)>"
            : "Neues Passwort (q beendet)>");
        String result = in.nextLine();
        if (result.equals("q")) {
          break;
        }
        if (password == null) {
          password = new Password(result);
        } else {
          password.changePassword(result);
        }
        System.out.println("Passwort \"" + result + "\" akzeptiert.");
      } catch (BadPasswordException e) {
        System.out.println("Fehler: " + e.getMessage());
      }
    }
    in.close();
  }
}
