package edu.hm.cs.bka.dev2.geometry;

import java.util.Comparator;

/**
 * Comparator (Vergleicher) für zwei Punkte. Die Ordnung der Punkte soll dabei dem Abstand von einem
 * festen Punkt (Mittelpunkt) entsprechen.
 *
 * <p>Achtung: Streng genommen sollte der Comparator für Punkte mit gleichem Abstand auch
 * eine Ordnungdefinieren, z.B. nach X- und Y-Wert sortieren. Soll nur sortiert werden, reicht
 * aber eine "Ordnung" nach Entfernung.
 */
public class DistanceComparator implements Comparator<Point> {

  // TODO: Instanzvariable und Konstruktor ergänzen!

  @Override
  public int compare(Point o1, Point o2) {
    // TODO: Vergleich zweier Punkte ergänzen (Abstand vom Punkt).
    return 0;
  }

}
