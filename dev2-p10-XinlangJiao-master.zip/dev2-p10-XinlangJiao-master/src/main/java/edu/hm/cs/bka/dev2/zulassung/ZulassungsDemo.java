package edu.hm.cs.bka.dev2.zulassung;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Demo-Klasse für Aufgabe 28.
 */
public class ZulassungsDemo {

  /**
   * Demo-Code.
   *
   * @param args wird nicht verwendet
   */
  public static void main(String[] args) {

    List<Bewerbung> prio = new ArrayList<Bewerbung>();
    prio.add(new Bewerbung("Micky Maus", 2.3));
    prio.add(new Bewerbung("Kater Carlo", 2.0));

    List<Bewerbung> web = new ArrayList<Bewerbung>();
    web.add(new Bewerbung("Minnie Maus", 1.3));
    web.add(new Bewerbung("Trick", 2.7));
    web.add(new Bewerbung("Donald Duck", 3.3));
    web.add(new Bewerbung("Gundel Gaukeley", 3.0));
    web.add(new Bewerbung("Micky Maus", 2.3));
    web.add(new Bewerbung("Gustav Gans", 2.0));

    List<Bewerbung> mail = new ArrayList<Bewerbung>();
    mail.add(new Bewerbung("Gustav Gans", 2.0));
    mail.add(new Bewerbung("Track", 2.7));
    mail.add(new Bewerbung("Tick", 2.7));
    mail.add(new Bewerbung("Donald Duck", 3.3));
    mail.add(new Bewerbung("Gustav Gans", 2.0));
    mail.add(new Bewerbung("Dagobert Duck", 2.3));

    // Sollte in bel. Reihe enthalten: Micky, Carlo, Gustav, Tick und Dagobert
    Set<Bewerbung> zulassung = Zulassung.select(4, prio, web, mail);
    System.out.println(zulassung);

  }
}
