package edu.hm.cs.bka.dev2.schlangen;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Klasse zum Puffern von Ausgaben.
 */
public class LaggingOutput {

  // TODO: Instanzvariablen fehlen.

  /**
   * Konstruktor.
   *
   * @param delay Anzahl der Strings, die zwischengespeichert werden dürfen.
   */
  public LaggingOutput(int delay) {
    // TODO: Initialisierung der Instanzvariablen
  }

  /**
   * Fügt einen String hinzu. Gibt einen wartenden String aus, wenn sonst mehr als die erlaubte
   * Anzahl an Strings warten.
   *
   * @param string (Später) auszugebender String
   */
  public void add(String string) {
    // TODO: Implementieren!
  }

  /**
   * Gibt einen wartenden String aus. Tut nichts, wenn kein String wartet.
   */
  public void next() {
    // TODO: Implementieren!
  }

  /**
   * Entfernt den zuletzt eingefügten String wieder (ohne Ausgabe).
   */
  public void revoke() {
    // TODO: Implementieren!
  }

  /**
   * Gibt alle noch wartenden Strings aus.
   */
  public void flush() {
    // TODO: Implementieren!
  }
}
