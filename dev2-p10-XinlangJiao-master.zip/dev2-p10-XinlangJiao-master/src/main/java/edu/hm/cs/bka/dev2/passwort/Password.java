package edu.hm.cs.bka.dev2.passwort;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

/**
 * Klasse zur Ablage/Änderung eines Passwortes mit Durchsetzung von Passwortregeln.
 */
public class Password {

  String password = null;

  /**
   * Konstruktor. Erzeugt ein Passwort-Objekt mit einem initialen Passwort.
   *
   * @param initial initiales Passwort
   * @throws BadPasswordException wenn das Passwort nicht den Anforderungen genügt.
   */
  public Password(String initial) throws BadPasswordException {
    changePassword(initial);
  }

  /**
   * Gibt das aktuelle Passwort zurück.
   *
   * @return aktuelles Passwort.
   */
  public String getPassword() {
    return password;
  }

  /**
   * Ändert das Passwort. Führt dabei diverse Überprüfungen durch.
   *
   * @param password neues Passwort, darf nicht null sein
   * @throws BadPasswordException wenn das Passwort nicht den Anforderungen genügt.
   */
  public void changePassword(String password) throws BadPasswordException {
    // Passwort darf nicht null sein
    if (password == null) {
      throw new IllegalArgumentException("Parameter password ist null.");
    }

    // Passwort darf nicht leer sein.
    if (password.isEmpty()) {
      throw new BadPasswordException("Passwort darf nicht leer sein!");
    }

    // Hier sollten die zusätzlichen Überprüfungen greifen!
    // TODO: Teil 1 Blocklist überprüfen
    // TODO: Teil 2 Anzahl unterschiedlicher Zeichen prüfen
    // TODO: Teil 3 Überprüfung, ob Passwort innerhalb der letzten 5 Passwörter
    // TODO: Teil 4 Überprüfung, ob das Passwort bereits zweimal aktiv war

    // Setze das Passwort
    this.password = password;

    // TODO: Teil 3&4 Aktualisiere interne Daten über vergangene Passwörter
  }

  /**
   * Liefert die Blacklist.
   *
   * @return Liste mit schlechten Passwörtern (wie "passwort").
   */
  protected static List<String> getBlockList() {
    List<String> blocklist = new ArrayList<String>();
    // TODO Teil 1 - Blocklist füllen
    return blocklist;
  }

  /**
   * Zählt die Anzahl unterschiedlicher Zeichen.
   *
   * @param password neues Passwort
   * @return Anzahl verschiedener Zeichen im Passwort, also z.B. 7 für "Passwort"
   */
  protected static int getNumberOfDifferentCharacters(String password) {
    char[] pwdAsArray = password.toCharArray();
    // TODO Teil 2 - Implementieren
    return 0;
  }


}
