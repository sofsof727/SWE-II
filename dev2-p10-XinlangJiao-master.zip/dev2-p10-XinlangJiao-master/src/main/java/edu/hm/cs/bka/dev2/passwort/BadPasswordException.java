package edu.hm.cs.bka.dev2.passwort;

/**
 * Signalisiert ein nicht zulässiges Passwort.
 */
public class BadPasswordException extends Exception {

  /**
   * Konstruktor.
   *
   * @param message Fehlermeldung
   */
  public BadPasswordException(String message) {
    super(message);
  }

}
