package edu.hm.cs.bka.dev2.peng;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Field;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class RevolverOptionalTest {

  @Test
  @Order(1)
  public void shouldExtendSchusswaffe() {
    assertEquals(Schusswaffe.class, Revolver.class.getSuperclass(),
        "Revolver sollte von Schusswaffe erben!");
  }

  @Test
  @Order(2)
  public void shouldShoot() throws Exception {
    Revolver r = new Revolver("Wumms", new boolean[] {true, true, true});
    String out = SystemLambda.tapSystemOutNormalized(r::schiessen);
    assertEquals(1, StringUtils.countMatches(out, "Wumms"), "Sollte Wumms ausgeben!");
    assertEquals(0, StringUtils.countMatches(out, "klick"), "Sollte Wumms ausgeben!");
  }

  @Test
  @Order(3)
  public void shouldShootWithSuperClassField() throws Exception {
    Revolver r = new Revolver("Wumms", new boolean[] {true, true, true});
    Field f = Schusswaffe.class.getDeclaredField("geraeusch");
    f.setAccessible(true);
    f.set(r, "Piff");
    String out = SystemLambda.tapSystemOutNormalized(r::schiessen);
    assertEquals(1, StringUtils.countMatches(out, "Piff"),
        "Revolver darf das Geräusch nicht in eigener Variable ablegen!");
  }

  @Test
  @Order(4)
  public void shouldShootCorrectly() throws Exception {
    Revolver r = new Revolver("Peng", new boolean[] {false, true, true, false, true});
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      for (int i = 0; i < 5; i++) {
        r.schiessen();
      }
    });
    assertEquals(3, StringUtils.countMatches(out, "Peng"), "Sollte 2x Peng machen!");
    assertEquals(2, StringUtils.countMatches(out, "klick"), "Sollte 3xklick machen");
  }

  @Test
  @Order(5)
  public void shouldClickWhenEmpty() throws Exception {
    Revolver r = new Revolver("Wumms", new boolean[] {true, false, true});
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      for (int i = 0; i < 6; i++) {
        r.schiessen();
      }
    });
    assertEquals(2, StringUtils.countMatches(out, "Wumms"), "Sollte 2x Wumms machen!");
    assertEquals(4, StringUtils.countMatches(out, "klick"), "Sollte 3xklick machen");
  }
}
