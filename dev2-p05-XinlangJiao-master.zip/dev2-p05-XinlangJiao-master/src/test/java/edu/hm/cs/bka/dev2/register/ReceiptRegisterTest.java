package edu.hm.cs.bka.dev2.register;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Field;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link ReceiptRegister}.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ReceiptRegisterTest {

  @Test
  @Order(1)
  public void shouldHaveOnlyOnePrivateField() {
    Field[] methods = ReceiptRegister.class.getDeclaredFields();
    assertEquals(1, methods.length, "Klasse ReceiptRegister darf nur eine Instanzvariable haben!");
  }

  @Test
  @Order(2)
  public void shouldHaveSumZeroAfterInitialization() {
    // Given
    ReceiptRegister register = new ReceiptRegister();

    // When
    int actual = register.getSum();

    // Then
    assertEquals(0, actual);
  }

  @Test
  @Order(3)
  public void shouldHaveAddedValueAfterSingleAddition() {
    // Given
    ReceiptRegister register = new ReceiptRegister();

    // When
    register.add(17);

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  @Order(4)
  public void shouldHaveCorrectSumAfterMultipleAdditions() {
    // Given
    ReceiptRegister register = new ReceiptRegister();

    // When
    register.add(17);
    register.add(12);

    // Then
    int actual = register.getSum();
    assertEquals(29, actual);
  }

  @Test
  @Order(5)
  public void shouldResetCorrectly() {
    // Given
    ReceiptRegister register = new ReceiptRegister();
    register.add(17);

    // When
    register.reset();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(6)
  public void shouldNotRepeatAfterReset() {
    // Given
    ReceiptRegister register = new ReceiptRegister();
    register.add(17);
    register.add(12);

    // When
    register.reset();
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(7)
  public void shouldNotAddNegativeValue() {
    // Given
    ReceiptRegister register = new ReceiptRegister();

    // When
    register.add(-17);

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(8)
  public void shouldNotRepeatNegativeValue() {
    // Given
    ReceiptRegister register = new ReceiptRegister();
    register.add(20);

    // When
    register.add(-3);
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(20, actual);
  }

  @Test
  @Order(9)
  public void shouldNotRepeatAfterInitialization() {
    // Given
    ReceiptRegister register = new ReceiptRegister();

    // When
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(10)
  public void shouldPrintSingleZeroSum() throws Exception {
    // Given
    ReceiptRegister register = new ReceiptRegister();
    String out = SystemLambda.tapSystemOutNormalized(register::printReceipt);

    assertTrue(out.contains("0"), "Summe 0 wird nicht auf Quittung gedruckt.");
  }

  @Test
  @Order(11)
  public void shouldPrintStandardAddition() throws Exception {
    // Given
    ReceiptRegister register = new ReceiptRegister();
    register.add(112);
    register.add(224);
    String out = SystemLambda.tapSystemOutNormalized(register::printReceipt);
    assertTrue(out.contains("112"), "Erster addierter Wert wird nicht auf Quittung gedruckt.");
    assertTrue(out.contains("224"), "Weiterer addierter Wert wird nicht auf die Quittung gedruckt.");
    assertTrue(out.contains("336"), "Summe wird nicht auf Quittung gedruckt.");
  }

}
