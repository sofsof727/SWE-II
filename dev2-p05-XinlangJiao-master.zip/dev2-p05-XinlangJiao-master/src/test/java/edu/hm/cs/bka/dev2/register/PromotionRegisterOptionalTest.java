package edu.hm.cs.bka.dev2.register;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link PromotionRegister}.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PromotionRegisterOptionalTest {

  @Test
  @Order(1)
  public void shouldHaveSumZeroAfterInitialization() {
    // Given
    PromotionRegister register = new PromotionRegister();

    // When
    int actual = register.getSum();

    // Then
    assertEquals(0, actual);
  }

  @Test
  @Order(2)
  public void shouldHaveAddedValueAfterSingleAddition() {
    // Given
    PromotionRegister register = new PromotionRegister();

    // When
    register.add(17);

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  @Order(3)
  public void shouldHaveCorrectSumAfterMultipleAdditions() {
    // Given
    PromotionRegister register = new PromotionRegister();

    // When
    register.add(17);
    register.add(12);

    // Then
    int actual = register.getSum();
    assertEquals(29, actual);
  }

  @Test
  @Order(4)
  public void shouldResetCorrectly() {
    // Given
    PromotionRegister register = new PromotionRegister();
    register.add(17);

    // When
    register.reset();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(5)
  public void shouldNotRepeatAfterReset() {
    // Given
    PromotionRegister register = new PromotionRegister();
    register.add(17);
    register.add(12);

    // When
    register.reset();
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(6)
  public void shouldNotAddNegativeValue() {
    // Given
    PromotionRegister register = new PromotionRegister();

    // When
    register.add(-17);

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(7)
  public void shouldNotRepeatNegativeValue() {
    // Given
    PromotionRegister register = new PromotionRegister();
    register.add(20);

    // When
    register.add(-3);
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(20, actual);
  }

  @Test
  @Order(8)
  public void shouldNotRepeatAfterInitialization() {
    // Given
    PromotionRegister register = new PromotionRegister();

    // When
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(9)
  public void shouldGiveDiscount() {
    // Given
    PromotionRegister register = new PromotionRegister();

    register.add(3);
    // When
    for (int i = 0; i < 25; i++) {
      register.repeat();
    }

    // Then
    int actual = register.getSum();
    assertEquals(24 * 3, actual);

  }

  @Test
  @Order(10)
  public void shouldNotGiveDiscountTooEarly() {
    // Given
    PromotionRegister register = new PromotionRegister();

    register.add(3);
    // When
    for (int i = 0; i < 11; i++) {
      register.repeat();
    }

    // Then
    int actual = register.getSum();
    assertEquals(12 * 3, actual);

  }
}
