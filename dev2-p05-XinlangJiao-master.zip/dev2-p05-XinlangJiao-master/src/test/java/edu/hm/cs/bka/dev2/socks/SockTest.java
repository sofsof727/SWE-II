package edu.hm.cs.bka.dev2.socks;

import java.awt.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SockTest {

  @Test
  @Order(1)
  public void shouldIdentifyEqualSocks() {
    assertEquals(new Sock(Color.CYAN, 12), new Sock(Color.CYAN, 12),
        "Gleiche Socken werden nicht erkannt!");
  }

  @Test
  @Order(2)
  public void shouldNotIdentifySocksWithDifferentColors() {
    assertNotEquals(new Sock(Color.CYAN, 12), new Sock(Color.BLUE, 12),
        "Ungleiche Socken werden als gleich erkannt!");
  }


}
