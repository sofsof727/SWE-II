package edu.hm.cs.bka.dev2.register;

import java.lang.reflect.Field;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link ProRegister}.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProRegisterTest {

  @Test
  @Order(1)
  public void shouldHaveOnlyOnePrivateField() {
    Field[] methods = ProRegister.class.getDeclaredFields();
    assertEquals(1, methods.length,
        "Klasse ProRegister darf nach Vereinfachung nur eine Instanzvariable haben!");
  }

  @Test
  @Order(2)
  public void shouldHaveSumZeroAfterInitialization() {
    // Given
    ProRegister register = new ProRegister();

    // When
    int actual = register.getSum();

    // Then
    assertEquals(0, actual);
  }

  @Test
  @Order(3)
  public void shouldHaveAddedValueAfterSingleAddition() {
    // Given
    ProRegister register = new ProRegister();

    // When
    register.add(17);

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  @Order(4)
  public void shouldHaveCorrectSumAfterMultipleAdditions() {
    // Given
    ProRegister register = new ProRegister();

    // When
    register.add(17);
    register.add(12);

    // Then
    int actual = register.getSum();
    assertEquals(29, actual);
  }

  @Test
  @Order(5)
  public void shouldResetCorrectly() {
    // Given
    ProRegister register = new ProRegister();
    register.add(17);

    // When
    register.reset();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(6)
  public void shouldNotRepeatAfterReset() {
    // Given
    ProRegister register = new ProRegister();
    register.add(17);
    register.add(12);

    // When
    register.reset();
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(7)
  public void shouldNotAddNegativeValue() {
    // Given
    ProRegister register = new ProRegister();

    // When
    register.add(-17);

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(8)
  public void shouldNotRepeatNegativeValue() {
    // Given
    ProRegister register = new ProRegister();
    register.add(20);

    // When
    register.add(-3);
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(20, actual);
  }

  @Test
  @Order(9)
  public void shouldNotRepeatAfterInitialization() {
    // Given
    ProRegister register = new ProRegister();

    // When
    register.repeat();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

}
