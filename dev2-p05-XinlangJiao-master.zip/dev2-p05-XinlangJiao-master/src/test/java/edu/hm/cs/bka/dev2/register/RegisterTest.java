package edu.hm.cs.bka.dev2.register;

import java.lang.reflect.Field;

import java.lang.reflect.Modifier;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Klasse zur Implementierung von Tests fuer die Klasse {@link Register}.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class RegisterTest {

  @Test
  @Order(1)
  public void shouldHaveOnlyPrivateField() {
    Field[] methods = Register.class.getDeclaredFields();
    assertEquals(1, methods.length, "Klasse Register darf nicht verändert werden!");
    assertTrue(Modifier.isPrivate(methods[0].getModifiers()),
        "Klasse Register darf nicht verändert werden!");
  }

  @Test
  @Order(2)
  public void shouldHaveSumZeroAfterInitialization() {
    // Given
    Register register = new Register();

    // When
    int actual = register.getSum();

    // Then
    assertEquals(0, actual);
  }

  @Test
  @Order(3)
  public void shouldHaveAddedValueAfterSingleAddition() {
    // Given
    Register register = new Register();

    // When
    register.add(17);

    // Then
    int actual = register.getSum();
    assertEquals(17, actual);
  }

  @Test
  @Order(4)
  public void shouldHaveCorrectSumAfterMultipleAdditions() {
    // Given
    Register register = new Register();

    // When
    register.add(17);
    register.add(12);

    // Then
    int actual = register.getSum();
    assertEquals(29, actual);
  }

  @Test
  @Order(5)
  public void shouldResetCorrectly() {
    // Given
    Register register = new Register();
    register.add(17);

    // When
    register.reset();

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

  @Test
  @Order(6)
  public void shouldNotAddNegativeValue() {
    // Given
    Register register = new Register();

    // When
    register.add(-17);

    // Then
    int actual = register.getSum();
    assertEquals(0, actual);
  }

}
