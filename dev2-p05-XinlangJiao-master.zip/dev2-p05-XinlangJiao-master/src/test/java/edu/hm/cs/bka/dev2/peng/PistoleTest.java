package edu.hm.cs.bka.dev2.peng;

import com.github.stefanbirkner.systemlambda.SystemLambda;
import java.lang.reflect.Field;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PistoleTest {

  @Test
  @Order(1)
  public void shouldExtendSchusswaffe() {
    assertEquals(Schusswaffe.class, Pistole.class.getSuperclass(),
        "Pistole sollte von Schusswaffe erben!");
  }

  @Test
  @Order(2)
  public void shouldShoot() throws Exception {
    Pistole p = new Pistole("Wumms", 6, 6);
    String out = SystemLambda.tapSystemOutNormalized(p::schiessen);
    assertEquals(1, StringUtils.countMatches(out, "Wumms"), "Ausgabe sollte Wumms sein.");
    assertEquals(0, StringUtils.countMatches(out, "klick"), "Ausgabe sollte Wumms sein.");
  }

  @Test
  @Order(3)
  public void shouldShootWithSuperClassField() throws Exception {
    Pistole p = new Pistole("Wumms", 6, 6);
    Field f = Schusswaffe.class.getDeclaredField("geraeusch");
    f.setAccessible(true);
    f.set(p, "Piff");
    String out = SystemLambda.tapSystemOutNormalized(p::schiessen);
    assertEquals(1, StringUtils.countMatches(out, "Piff"),
        "Pistole darf das Geräusch nicht in eigener Variable ablegen!");
  }

  @Test
  @Order(4)
  public void shouldShootRepeatedly() throws Exception {
    Pistole p = new Pistole("Wumms", 6, 6);
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      for (int i = 0; i < 6; i++) {
        p.schiessen();
      }
    });
    assertEquals(6, StringUtils.countMatches(out, "Wumms"));
    assertEquals(0, StringUtils.countMatches(out, "klick"));
  }

  @Test
  @Order(5)
  public void shouldShootRepeatedlyWithExtraMethod() throws Exception {
    Pistole p = new Pistole("Wumms", 6, 6);
    String out = SystemLambda.tapSystemOutNormalized(() ->
        p.schiessen(2));
    assertEquals(2, StringUtils.countMatches(out, "Wumms"));
    assertEquals(0, StringUtils.countMatches(out, "klick"));
  }

  @Test
  @Order(6)
  public void shouldShootKlickWhenWmpty() throws Exception {
    Pistole p = new Pistole("Wumms", 6, 2);
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      p.schiessen();
      p.schiessen();
      p.schiessen();
    });
    assertEquals(2, StringUtils.countMatches(out, "Wumms"));
    assertEquals(1, StringUtils.countMatches(out, "klick"));
  }

  @Test
  @Order(7)
  public void shouldRefill() throws Exception {
    Pistole p = new Pistole("Wumms", 5, 2);
    String out = SystemLambda.tapSystemOutNormalized(() -> {
      p.schiessen(3);
      p.nachladen();
      p.schiessen(7);
    });
    assertEquals(7, StringUtils.countMatches(out, "Wumms"));
    assertEquals(3, StringUtils.countMatches(out, "klick"));
  }


}
