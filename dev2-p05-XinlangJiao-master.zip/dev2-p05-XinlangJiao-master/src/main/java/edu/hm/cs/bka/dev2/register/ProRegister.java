package edu.hm.cs.bka.dev2.register;

/**
 * Implementierung einer Kasse mit Storno- und Wiederholfunktion.
 */
public class ProRegister {

  // aktuelle Summe
  private int sum;

  // letzte Erhoehung (fuer repeat-Funktion).
  private int lastAddition;

  /**
   * Aktuelle Summe.
   *
   * @return Aktueller Wert der Kasse
   */
  public int getSum() {
    return sum;
  }

  /**
   * Eingabe einer Summe.
   *
   * @param value Erhoehung. Negative Werte werden wie Null behandelt.
   */
  public void add(final int value) {
    if (value > 0) {
      sum += value;
      lastAddition = value;
    } else {
      lastAddition = 0;
    }
  }

  /**
   * Wiederholt die letzte Erhoehung.
   */
  public void repeat() {
    sum += lastAddition;
  }

  /**
   * Setzt das Objekt wieder in den Ausgangszustand zurueck.
   */
  public void reset() {
    sum = 0;
    lastAddition = 0;
  }

}
