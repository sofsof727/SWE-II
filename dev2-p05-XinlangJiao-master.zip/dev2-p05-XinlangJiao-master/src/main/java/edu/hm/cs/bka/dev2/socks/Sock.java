package edu.hm.cs.bka.dev2.socks;

import java.awt.Color;

/**
 * Klasse für Socken.
 */
public class Sock {
  private final Color color;
  private final int size;

  /**
   * Konstruktor.
   *
   * @param color Farbe
   * @param size Größe
   */
  public Sock(Color color, int size) {
    this.color = color;
    this.size = size;
  }
}
