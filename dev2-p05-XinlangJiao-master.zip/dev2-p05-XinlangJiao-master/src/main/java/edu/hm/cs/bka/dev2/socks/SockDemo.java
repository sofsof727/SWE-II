package edu.hm.cs.bka.dev2.socks;

import java.awt.Color;

/**
 * Klasse für Demo-Code.
 */
public class SockDemo {

  /**
   * Beispielcode für Sockensuche.
   *
   * @param args nicht genutzt.
   */
  public static void main(String[] args) {

    Sock[] sockenstapel = new Sock[6];
    sockenstapel[0] = new Sock(Color.BLUE, 41);
    sockenstapel[1] = new Sock(Color.BLACK, 44);
    sockenstapel[2] = new Sock(Color.DARK_GRAY, 43);
    sockenstapel[3] = new Sock(Color.BLACK, 44);
    sockenstapel[4] = new Sock(Color.DARK_GRAY, 43);
    sockenstapel[5] = new Sock(Color.BLUE, 41);

    for (int i = 0; i < sockenstapel.length; i++) {
      for (int j = i + 1; j < sockenstapel.length; j++) {
        if (sockenstapel[i].equals(sockenstapel[j])) {
          System.out.println("Jaaaa, zwei gleiche Socken!");
        }
      }
    }
  }
}
