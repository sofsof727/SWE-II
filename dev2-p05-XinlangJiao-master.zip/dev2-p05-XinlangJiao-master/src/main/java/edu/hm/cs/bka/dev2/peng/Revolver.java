package edu.hm.cs.bka.dev2.peng;

/**
 * Implementierung eines Revolvers.
 */
public class Revolver extends Schusswaffe {

  /**
   * Konstruktor.
   *
   * @param geraeusch        Geräusch beim Schießen
   * @param ladungInTrommeln Trommeln mit Ladezustand (true: Patrone in Trommel)
   */
  public Revolver(String geraeusch, boolean[] ladungInTrommeln) {
    // TODO: Implementieren
    super("");
  }
}
