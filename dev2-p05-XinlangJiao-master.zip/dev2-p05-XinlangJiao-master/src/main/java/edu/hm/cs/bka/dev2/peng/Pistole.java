package edu.hm.cs.bka.dev2.peng;

/**
 * Eine Pistole hat eine begrenzte Zahl von Schüssen in einem Magazin.
 */
public class Pistole extends Schusswaffe {

  /**
   * Konstruktor.
   *
   * @param geraeusch      Geräusch beim Schießen
   * @param magazinGroesse Größe des Magazins
   * @param patronen       Anzahl der Patronen im Magazin
   */
  public Pistole(String geraeusch, int magazinGroesse, int patronen) {
    // TODO: Implementieren
    super("");
  }

  /**
   * Gibt mehrere Schüsse ab.
   *
   * @param anzahl Anzahl der Schüsse
   */
  public void schiessen(int anzahl) {
    // TODO Implementieren
  }

  /**
   * Füllt das Magazin auf (ganz).
   */
  public void nachladen() {
    // TODO: Implementieren
  }

}
