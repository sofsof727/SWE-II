package edu.hm.cs.bka.dev2.peng;

/**
 * Demonstration verschiedener Schusswaffen.
 */
public class Demo {

  /**
   * Beispielcode.
   *
   * @param args nicht verwendet
   */
  public static void main(String[] args) {
    Schusswaffe s = new Schusswaffe("Peng!");
    s.schiessen(); // -> Peng!

    Pistole p = new Pistole("Pop!", 3, 2);
    p.schiessen(); // -> Pop!
    p.schiessen(); // -> Pop!
    p.schiessen(); // -> klick
    p.nachladen();
    p.schiessen(5); // ->3x Ausgabe Pop!, 2x Ausgabe klick

    Revolver r = new Revolver("Pow!", new boolean[] {true, false, true, false});
    r.schiessen(); // -> Pow!
    r.schiessen(); // -> klick
    r.schiessen(); // -> Pow!
    r.schiessen(); // klick (ab hier kommen nur noch klicks, Trommel ist leer!)

  }
}

