package edu.hm.cs.bka.dev2.peng;

/**
 * Schusswaffen machen Geräusche.
 */
public class Schusswaffe {

  private final String geraeusch;

  /**
   * Konstruktor.
   *
   * @param geraeusch Schussgeräusch
   */
  public Schusswaffe(String geraeusch) {
    this.geraeusch = geraeusch;
  }

  /**
   * Schuss abgeben, verursacht ein Geräusch.
   */
  public void schiessen() {
    System.out.println(geraeusch);
  }
}
