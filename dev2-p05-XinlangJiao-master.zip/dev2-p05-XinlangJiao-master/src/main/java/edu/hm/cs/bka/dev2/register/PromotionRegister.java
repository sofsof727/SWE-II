package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die statt jedes 13. Wertes eine 0 erfasst..
 */
public class PromotionRegister extends ProRegister {

}

