package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die eine Funktion zu Quittungsdruck beherrscht.
 */
public class ReceiptRegister extends ProRegister {

  public void printReceipt() {

  }
}
