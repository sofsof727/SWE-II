package edu.hm.cs.bka.dev2.register;

/**
 * Variante von {@link ProRegister}, die bei jeder vierten Eingabe einen Wert von 2 addiert.
 */
public class CheatingRegister extends ProRegister {

}
