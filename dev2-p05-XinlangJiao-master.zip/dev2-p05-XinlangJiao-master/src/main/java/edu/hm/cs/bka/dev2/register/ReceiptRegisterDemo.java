package edu.hm.cs.bka.dev2.register;

/**
 * Beispielklasse zur Verwendung von {@link ReceiptRegister}.
 */
public class ReceiptRegisterDemo {

  /**
   * Verwendungsbeispiel.
   *
   * @param args nicht genutzt.
   */
  public static void main(String[] args) {
    ReceiptRegister register = new ReceiptRegister();
    register.add(17);
    register.add(2);
    register.printReceipt();
  }
}
