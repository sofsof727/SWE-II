package edu.hm.cs.bka.dev2.schaltungen;

public class UeberspannungsException extends Exception {
  public UeberspannungsException(String msg) {
    super(msg);
  }
}
