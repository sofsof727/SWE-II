package edu.hm.cs.bka.dev2.schach;

/**
 * Abstrakte Oberklasse für alle Figuren, die sich gradlinig bewegen müssen.
 */
public abstract class GeradeZiehendeFigur extends NormalSchlagendeFigur {

  public GeradeZiehendeFigur(Farbe color) {
    super(color);
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte, int zuReihe,
                            int zuSpalte) {

    if (!super.kannZiehen(schachbrett, vonReihe, vonSpalte, zuReihe, zuSpalte)) {
      return false;
    }

    int differenzReihe = Math.abs(zuReihe - vonReihe);
    int differenzSpalte = Math.abs(zuSpalte - vonSpalte);

    // Figur darf nicht stehenbleiben!
    if (differenzReihe + differenzSpalte == 0) {
      return false;
    }

    // Differenzen sind entweder gleich (diagonal) oder eine ist 0.
    if (differenzReihe != differenzSpalte && differenzReihe != 0 && differenzSpalte != 0) {
      return false;
    }

    // Zwischen Start- und Zielfeld darf keine Figur stehen!
    int richtungReihe = (zuReihe - vonReihe) / Math.max(differenzReihe, differenzSpalte);
    int richtungSpalte = (zuSpalte - vonSpalte) / Math.max(differenzReihe, differenzSpalte);
    for (int i = 1; i < Math.max(differenzReihe, differenzSpalte); i++) {
      Figur figur = schachbrett.get(vonReihe + i * richtungReihe, vonSpalte + i * richtungSpalte);
      if (figur != null) {
        return false;
      }
    }
    return true;
  }
}
