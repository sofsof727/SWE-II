package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Bauern.
 */
public class Bauer extends Figur {

  public Bauer(Farbe farbe) {
    super(farbe);
  }

  public String toString() {
    return "\u265f"; // Bauer!
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte, int nachReihe,
                            int nachSpalte) {
    Figur ziel = schachbrett.get(nachReihe, nachSpalte);
    int direction = (getFarbe() == Farbe.WEISS) ? 1 : -1;

    // Schritte in der gleichen Spalte sind auf leere Felder erlaubt..
    if (nachSpalte == vonSpalte && ziel == null) {
      // ..einen Schritt vor
      if (nachReihe == vonReihe + direction) {
        return true;
      }
      // ..oder als erster Zug zwei Schritte..
      if (nachReihe == vonReihe + 2 * direction && (vonReihe == 1 || vonReihe == 6)) {
        return true;
      }
    }
    // Schritte in Nachbarspalte sind nur schlagend erlaubt
    return (nachSpalte == vonSpalte - 1 || nachSpalte == vonSpalte + 1) && ziel != null
        && ziel.getFarbe() != getFarbe() && nachReihe == vonReihe + direction;
  }
}

