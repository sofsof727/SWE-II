package edu.hm.cs.bka.dev2.schach;

/**
 * Exception für die Anzeige ungültiger Züge.
 */
public class IllegalMoveException extends Exception {

  /**
   * Konstruktor.
   */
  public IllegalMoveException(String message) {
    super(message);
  }
}
