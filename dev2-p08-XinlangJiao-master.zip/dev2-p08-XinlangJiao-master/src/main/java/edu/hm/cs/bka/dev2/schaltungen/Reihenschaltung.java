package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Reihenschaltung zweier Schaltungen. Widerstände addieren sich.
 */
public class Reihenschaltung implements Schaltung {

  private final Schaltung[] teile;

  public Reihenschaltung(Schaltung a, Schaltung b) {
    this.teile = new Schaltung[] {a, b};
  }

  @Override
  public double berechneWiderstand() {
    return teile[0].berechneWiderstand() + teile[1].berechneWiderstand();
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    teile[0].legeSpannungAn(spannung * teile[0].berechneWiderstand() / berechneWiderstand());
    teile[1].legeSpannungAn(spannung * teile[1].berechneWiderstand() / berechneWiderstand());
    return spannung / berechneWiderstand();
  }
}
