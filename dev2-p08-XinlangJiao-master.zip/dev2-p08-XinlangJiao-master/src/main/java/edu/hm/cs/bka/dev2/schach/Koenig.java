package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Könige.
 */
public class Koenig extends GeradeZiehendeFigur {

  public Koenig(Farbe farbe) {
    super(farbe);
  }

  public String toString() {
    return "\u265a"; // König
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                            int nachReihe, int nachSpalte) {

    // Wenn Zug nicht geradlinig ist, ist der Zug nicht zulässig.
    if (!super.kannZiehen(schachbrett, vonReihe, vonSpalte, nachReihe, nachSpalte)) {
      return false;
    }

    // TODO: Überprüfe, dass Zug auf benachbartes Feld geht!
    return false;
  }


}

