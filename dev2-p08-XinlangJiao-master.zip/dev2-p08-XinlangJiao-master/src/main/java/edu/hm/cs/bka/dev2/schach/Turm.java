package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Turm.
 */
public class Turm extends GeradeZiehendeFigur {

  public Turm(Farbe farbe) {
    super(farbe);
  }

  public String toString() {
    return "\u265c"; // Turm
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                            int nachReihe, int nachSpalte) {

    // Wenn Zug nicht geradlinig ist, ist der Zug nicht zulässig.
    if (!super.kannZiehen(schachbrett, vonReihe, vonSpalte, nachReihe, nachSpalte)) {
      return false;
    }

    // TODO: Überprüfe, dass Zug nicht diagonal geht!
    return false;
  }

}

