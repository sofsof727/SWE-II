package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Parallelschaltung zweier Schaltungen.
 */
public class Parallelschaltung implements Schaltung {

  private final Schaltung[] teile;

  public Parallelschaltung(Schaltung a, Schaltung b) {
    this.teile = new Schaltung[] {a, b};
  }

  @Override
  public double berechneWiderstand() {
    return 1 / (1 / teile[0].berechneWiderstand() + 1 / teile[1].berechneWiderstand());
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    teile[0].legeSpannungAn(spannung);
    teile[1].legeSpannungAn(spannung);
    return spannung / berechneWiderstand();
  }
}

