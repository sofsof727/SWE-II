package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Demo, berechnet Stromfluss für eine Beispielschaltung (siehe Vorlesung).
 */
public class Demo {

  private static final String OHM = "\u2126"; // Ohm-Zeichen

  /**
   * Demo-Programm.
   *
   * @param args wird nicht verwendet
   */
  public static void main(String[] args) {
    Schaltung l1 = new Lampe(12.0, 3.0);
    Schaltung r1 = new Widerstand(12.0);
    Schaltung s1 = new Reihenschaltung(l1, r1);
    Schaltung r2 = new Widerstand(40.0);
    Schaltung p1 = new Parallelschaltung(s1, r2);
    Schaltung r3 = new Widerstand(10.0);
    Schaltung r4 = new Widerstand(40.0);
    Schaltung p2 = new Parallelschaltung(r3, r4);
    Schaltung r5 = new Widerstand(16.0);
    Schaltung s2 = new Reihenschaltung(r5, p2);
    Schaltung s3 = new Reihenschaltung(s2, p1);

    System.out.printf("Gesamtwiderstand %.02f%s\n", s3.berechneWiderstand(), OHM);
    try {
      System.out.printf("Gesamtstrom %.02fA\n", s3.legeSpannungAn(25.0));
    } catch (UeberspannungsException e) {
      System.out.println("Puff!");
    }

  }
}
