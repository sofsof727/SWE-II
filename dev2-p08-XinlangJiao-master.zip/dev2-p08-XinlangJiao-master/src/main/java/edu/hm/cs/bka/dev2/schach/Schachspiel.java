package edu.hm.cs.bka.dev2.schach;

import java.util.Scanner;

/**
 * Schachbrett mit Darstellung und Abfrage der Züge in Konsole.
 */
public abstract class Schachspiel extends Schachbrett {

  private Farbe amZug = Farbe.WEISS;

  /**
   * Führt ein Spiel durch (Game Loop).
   */
  public void spiele() {
    while (!beendet()) { // solange Spiel nicht zuende
      zeichne(); // zeichne das Brett

      frageZugAb(amZug); // frage Zug für akt. Spieler ab

      // Wechsle den Spieler
      amZug = (amZug == Farbe.WEISS)
          ? Farbe.SCHWARZ : Farbe.WEISS;
    }
    zeichne();
    System.out.println("Spiel vorbei!");
  }

  /**
   * Ermittelt, ob das Spiel zuende ist.
   *
   * @return true, wenn das Spiel beendet ist.
   */
  protected abstract boolean beendet();

  /* Die folgenden Methoden dienen zum Zeichnen/Einlesen und sind weitgehend irrelevant.*/

  private static final Scanner in = new Scanner(System.in);

  /**
   * Hilfsmethode für die Abfrage eines Zuges.
   *
   * @param farbe Farbe am Zug
   */
  private void frageZugAb(Farbe farbe) {
    String prompt = farbe == Farbe.WEISS ? "Weiß" : "Schwarz";
    boolean zugErfolgt = false;
    do {
      try {
        System.out.print(prompt + " am Zug > ");
        String result = in.nextLine().trim();
        fuehreZugDurch(result);
        zugErfolgt = true;
      } catch (Exception e) {
        System.out.println("Ungültiger Zug: " + e.getMessage());
      }
    } while (!zugErfolgt);
  }

  private static final String LINE_NUMBERS = "\u001B[38;2;128;128;128m\u001B[48;2;240;240;240m";
  private static final String DARK_BACKGROUND = "\u001B[48;2;150;100;80m";
  private static final String LIGHT_BACKGROUND = "\u001B[48;2;230;190;130m";
  private static final String WHITE_FOREGROUND = "\u001B[38;2;255;255;255m";
  private static final String BLACK_FOREGROUND = "\u001B[38;2;0;0;0m";

  /**
   * Zeichnet das Schachbrett mit den enthaltenen Figuren.
   */
  private void zeichne() {
    // draw top indizes
    System.out.println(LINE_NUMBERS + "   a  b  c  d  e  f  g  h   ");
    for (int row = 7; row >= 0; row--) {
      System.out.print(LINE_NUMBERS + (row + 1) + " ");
      for (int col = 0; col <= 7; col++) {
        if ((col + row) % 2 == 0) {
          System.out.print(DARK_BACKGROUND);
        } else {
          System.out.print(LIGHT_BACKGROUND);
        }
        if (get(row, col) != null) {
          if (get(row, col).getFarbe() == Farbe.WEISS) {
            System.out.print(WHITE_FOREGROUND);
          } else {
            System.out.print(BLACK_FOREGROUND);
          }
          System.out.print(" " + get(row, col) + " ");
        } else {
          System.out.print("   ");
        }
      }
      System.out.println(LINE_NUMBERS + " " + (row + 1));
    }
    System.out.print(LINE_NUMBERS + "   a  b  c  d  e  f  g  h     ");
    System.out.println("\u001B[39m\u001B[49m ");
  }

  /**
   * Führt einen Zug auf Basis einer Eingabe wie "a3b4" durch.
   *
   * @param zug Zug
   * @throws IllegalMoveException wenn der Zug nicht gültig ist.
   */
  private void fuehreZugDurch(final String zug) throws IllegalMoveException {
    if (zug == null || zug.length() != 4) {
      throw new IllegalArgumentException("Zug muss aus vier Zeichen bestehen!");
    }
    String moveAsLowerCase = zug.toLowerCase();
    if (moveAsLowerCase.charAt(0) < 'a' || moveAsLowerCase.charAt(0) > 'h') {
      throw new IllegalArgumentException("Erstes Zeichen muss Buchstabe (a-h) sein!");
    }
    if (moveAsLowerCase.charAt(1) < '1' || moveAsLowerCase.charAt(1) > '8') {
      throw new IllegalArgumentException("Zweites Zeichen muss Ziffer (1-8) sein!");
    }
    if (moveAsLowerCase.charAt(2) < 'a' || moveAsLowerCase.charAt(2) > 'h') {
      throw new IllegalArgumentException("Drittes Zeichen muss Buchstabe (a-h) sein!");
    }

    if (moveAsLowerCase.charAt(3) < '1' || moveAsLowerCase.charAt(3) > '8') {
      throw new IllegalArgumentException("Viertes Zeichen muss Ziffer (1-8) sein!");
    }
    int fromCol = moveAsLowerCase.charAt(0) - 'a';
    int fromRow = moveAsLowerCase.charAt(1) - '1';
    int toCol = moveAsLowerCase.charAt(2) - 'a';
    int toRow = moveAsLowerCase.charAt(3) - '1';
    ziehe(amZug, fromRow, fromCol, toRow, toCol);
  }
}
