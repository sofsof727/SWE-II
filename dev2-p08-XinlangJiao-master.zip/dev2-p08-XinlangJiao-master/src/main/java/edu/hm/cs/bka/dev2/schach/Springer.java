package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Springer.
 */
public class Springer extends NormalSchlagendeFigur {

  public Springer(Farbe color) {
    super(color);
  }

  public String toString() {
    return "\u265e"; // Springer
  }

  @Override
  public boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                            int nachReihe, int nachSpalte) {

    if (!super.kannZiehen(schachbrett, vonReihe, vonSpalte, nachReihe, nachSpalte)) {
      return false;
    }

    // TODO: Entfernung des Zielfeldes überprüfen!
    return false;
  }
}
