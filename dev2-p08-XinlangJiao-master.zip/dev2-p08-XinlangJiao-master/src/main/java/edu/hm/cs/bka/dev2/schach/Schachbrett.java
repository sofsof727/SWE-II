package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für ein Schachbrett. Verwendet für Reihen und Spalten jeweils Indizes zwischen 0 und 7,
 * d.h.
 * <ul>
 * <li>Reihe 1 hat Index 0, Reihe 8 hat Index 7 und</li>
 * <li>Spalte a hat Index 0, Spalte h hat Index 7.
 * </ul>
 * Aus Gründen der besseren Lesbarkeit wird auf die Überprüfung der Indizes verzichtet!
 */
public class Schachbrett {

  // Spielbrett, erster Index ist Reihe, zweiter Spalte
  private final Figur[][] felder = new Figur[8][8];

  protected void set(int reihe, int spalte, Figur figur) {
    felder[reihe][spalte] = figur;
  }

  protected Figur get(int reihe, int spalte) {
    return felder[reihe][spalte];
  }

  /**
   * Ziehen einer Figur.
   *
   * @param farbe     Spieler, der den Zug durchführen will
   * @param vonReihe   Reihe, aus der Figur gezogen werden soll
   * @param vonSpalte  Spalte, aus der Figur gezogen werden soll
   * @param nachReihe  Reihe, in die die Figur gezugen werden soll
   * @param nachSpalte Spalte, in die die Figur gezogen werden soll
   */
  public void ziehe(Farbe farbe, int vonReihe, int vonSpalte, int nachReihe, int nachSpalte)
      throws IllegalMoveException {
    Figur figur = get(vonReihe, vonSpalte);
    if (figur == null || figur.getFarbe() != farbe) {
      throw new IllegalMoveException("Auf dem Feld steht keine eigene Figur!");
    }
    if (!figur.kannZiehen(this, vonReihe, vonSpalte, nachReihe, nachSpalte)) {
      throw new IllegalMoveException("Figur darf so nicht ziehen!");
    }
    set(vonReihe, vonSpalte, null);
    set(nachReihe, nachSpalte, figur);
  }
}
