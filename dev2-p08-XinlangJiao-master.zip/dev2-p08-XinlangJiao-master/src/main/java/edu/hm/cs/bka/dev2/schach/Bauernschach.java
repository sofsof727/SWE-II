package edu.hm.cs.bka.dev2.schach;

/**
 * Schachspiel-Variante Bauernschach.
 */
public class Bauernschach extends Schachspiel {

  public static void main(String[] args) {
    Schachspiel schachspiel = new Bauernschach();
    schachspiel.spiele();
  }

  /**
   * Konstruktor. Initialisiert Stellung für Bauernschach.
   */
  public Bauernschach() {
    super(); // nicht nötig
    for (int spalte = 0; spalte < 8; spalte++) {
      set(6, spalte, new Bauer(Farbe.SCHWARZ));
      set(1, spalte, new Bauer(Farbe.WEISS));
    }
  }

  @Override
  protected boolean beendet() {
    // überprüft, ob ein Bauer oben oder unten steht
    for (int i = 0; i < 8; i++) {
      if (get(0, i) != null || get(7, i) != null) {
        return true;
      }
    }
    return false;
  }

}
