package edu.hm.cs.bka.dev2.schaltungen;

public interface Schaltung {

  /**
   * Berechnet den inneren Widerstand.
   *
   * @return Widerstand in Ohm.
   */
  double berechneWiderstand();

  /**
   * Löst Verhalten eines Bauteils aus und berechnet den Stromfluss.
   *
   * @param spannung angelegte Spannung in Volt
   * @return Stromfluss in Ampere
   * @throws UeberspannungsException wenn Spannung zu hoch ist
   */
  double legeSpannungAn(double spannung) throws UeberspannungsException;
}
