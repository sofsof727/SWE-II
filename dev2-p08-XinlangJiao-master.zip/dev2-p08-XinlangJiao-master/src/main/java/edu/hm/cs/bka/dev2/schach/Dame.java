package edu.hm.cs.bka.dev2.schach;

/**
 * Klasse für Königin.
 */
public class Dame extends GeradeZiehendeFigur {

  public Dame(Farbe farbe) {
    super(farbe);
  }

  public String toString() {
    return "\u265b"; // Königin
  }

  // Keine kannZiehen-Methode, weil die Dame wirklich alle
  // Züge durchführen darf, die lt. GeradeZiehendeFigur erlaubt sind.
}
