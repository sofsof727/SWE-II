package edu.hm.cs.bka.dev2.schach;

/**
 * Enum für die Spielparteien.
 * Zugunsten der Übersichtlichkeit ohne Attribute.
 */
public enum Farbe {
  /**
   * Spielparteien Weiß, Schwarz.
   */
  WEISS, SCHWARZ
}
