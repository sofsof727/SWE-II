package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Lampe. Widerstand wird berechnet aus Nominalspannung und Leistung.
 */
public class Lampe implements Schaltung {

  private final double sollSpannung;
  private final double leistung;

  /**
   * Konstruktor.
   *
   * @param sollSpannung Sollspannung
   * @param leistung Leistungsaufnahme
   */
  public Lampe(double sollSpannung, double leistung) {
    this.sollSpannung = sollSpannung;
    this.leistung = leistung;
  }

  @Override
  public double berechneWiderstand() {
    return sollSpannung * sollSpannung / leistung;
  }

  @Override
  public double legeSpannungAn(double spannung) throws UeberspannungsException {
    if (spannung > sollSpannung) {
      throw new UeberspannungsException("Lampe kaputt.");
    }
    if (spannung >= 0.5 * sollSpannung) {
      System.out.println("BLINK!");
    }
    return spannung / berechneWiderstand();
  }

}
