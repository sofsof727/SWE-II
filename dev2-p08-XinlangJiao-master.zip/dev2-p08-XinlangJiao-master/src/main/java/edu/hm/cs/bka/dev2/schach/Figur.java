package edu.hm.cs.bka.dev2.schach;

/**
 * Abstrakte Klasse für Schachfiguren.
 */
public abstract class Figur {

  // Farbe der Spielfigur
  private final Farbe farbe;

  public Figur(Farbe farbe) {
    this.farbe = farbe;
  }

  public Farbe getFarbe() {
    return farbe;
  }

  /**
   * Liefert true wenn eine Figur einen Zug durchführen darf.
   *
   * @param schachbrett Schachbrett
   * @param vonReihe Startreihe (0..7, von weiß nach schwarz)
   * @param vonSpalte Startspalte (0..7, von links nach rechts)
   * @param nachReihe Zielreihe (0..7, von weiß nach schwarz)
   * @param nachSpalte Zielspalte (0..7, von links nach rechts)
   * @return true, wenn Zug zulässig ist.
   */
  public abstract boolean kannZiehen(Schachbrett schachbrett, int vonReihe, int vonSpalte,
                                     int nachReihe, int nachSpalte);
}
