package edu.hm.cs.bka.dev2.schaltungen;

/**
 * Widerstand.
 */
public class Widerstand implements Schaltung {

  private final double widerstand;

  /**
   * Konstruktor.
   *
   * @param widerstand Widerstandswert, muss positiv sein.
   */
  public Widerstand(double widerstand) {
    if (widerstand <= 0.0) {
      throw new IllegalArgumentException("Widerstand negativ!");
    }
    this.widerstand = widerstand;
  }

  @Override
  public double berechneWiderstand() {
    return widerstand;
  }

  @Override
  public double legeSpannungAn(double spannung) {
    return spannung / berechneWiderstand();
  }
}
