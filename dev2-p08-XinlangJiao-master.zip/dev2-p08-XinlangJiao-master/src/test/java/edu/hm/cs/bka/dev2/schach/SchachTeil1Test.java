package edu.hm.cs.bka.dev2.schach;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;
import static de.i8k.java.testing.ReflectiveAssertions.*;

/**
 * Tests für Schachaufgabe, Teil 1
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchachTeil1Test {

  private static final String PACKAGE = "edu.hm.cs.bka.dev2.schach";

  @Test
  @Order(1)
  public void test01SchachklasseAngelegt() {
    Class<?> c = assertClass(PACKAGE, "Schach");
    if (!Schachspiel.class.isAssignableFrom(c)) {
      failf("Schach muss Unterklasse von Schachspiel sein!");
    }
  }

  @Test
  @Order(2)
  public void test02ShouldInitializeCorrectly()
      throws InstantiationException, IllegalAccessException {
    Class<?> c = assertClass(PACKAGE, "Schach");
    Schachspiel o = (Schachspiel) c.newInstance();

    for (Farbe color : Farbe.values()) {
      int row = 0;
      String farbe = "weiß";
      if (color == Farbe.SCHWARZ) {
        row = 7;
        farbe = "schwarz";
      }

      String msg = "Auf a" + (row + 1) + " muss " + farbe + "er Turm stehen!";
      assertNotNull(o.get(row, 0), msg);
      assertSame(o.get(row, 0).getClass(), Turm.class, msg);
      assertEquals(color, o.get(row, 0).getFarbe(), msg);

      msg = "Auf b" + (row + 1) + " muss " + farbe + "er Springer stehen!";
      assertNotNull(o.get(row, 1), msg);
      assertSame(o.get(row, 1).getClass(), Springer.class, msg);
      assertEquals(color, o.get(row, 1).getFarbe(), msg);

      msg = "Auf c" + (row + 1) + " muss " + farbe + "er Läufer stehen!";
      assertNotNull(o.get(row, 2), msg);
      assertSame(o.get(row, 2).getClass(), Laeufer.class, msg);
      assertEquals(color, o.get(row, 2).getFarbe(), msg);

      msg = "Auf d" + (row + 1) + " muss " + farbe + "e Dame stehen!";
      assertNotNull(o.get(row, 3), msg);
      assertSame(o.get(row, 3).getClass(), Dame.class, msg);
      assertEquals(color, o.get(row, 3).getFarbe(), msg);

      msg = "Auf e" + (row + 1) + " muss " + farbe + "er König stehen!";
      assertNotNull(o.get(row, 4), msg);
      assertSame(o.get(row, 4).getClass(), Koenig.class, msg);
      assertEquals(color, o.get(row, 4).getFarbe(), msg);

      msg = "Auf f" + (row + 1) + " muss " + farbe + "er Läufer stehen!";
      assertNotNull(o.get(row, 5), msg);
      assertSame(o.get(row, 5).getClass(), Laeufer.class, msg);
      assertEquals(color, o.get(row, 5).getFarbe(), msg);

      msg = "Auf g" + (row + 1) + " muss " + farbe + "er Springer stehen!";
      assertNotNull(o.get(row, 6), msg);
      assertSame(o.get(row, 6).getClass(), Springer.class, msg);
      assertEquals(color, o.get(row, 6).getFarbe(), msg);

      msg = "Auf h" + (row + 1) + " muss " + farbe + "er Turm stehen!";
      assertNotNull(o.get(row, 7), msg);
      assertSame(o.get(row, 7).getClass(), Turm.class, msg);
      assertEquals(color, o.get(row, 7).getFarbe(), msg);

      row = (row + 1) - (2 * row / 7);
      for (int col = 0; col < 8; col++) {
        char colLetter = (char) ('a' + col);
        msg = "Auf " + colLetter + (row + 1) + " muss " + farbe + "er Bauer stehen!";
        assertNotNull(o.get(row, col), msg);
        assertSame(o.get(row, col).getClass(), Bauer.class, msg);
        assertEquals(color, o.get(row, col).getFarbe(), msg);
      }
    }

    for (int row = 2; row <= 5; row++) {
      for (int col = 0; col < 8; col++) {
        char colletter = (char) ('a' + col);
        assertNull(o.get(row, col), "Auf " + colletter + (row + 1) + " darf keine Figur stehen!");
      }
    }
  }

  @Test
  public void test03ShouldNotBeGameOverInInitialPosition()
      throws InstantiationException, IllegalAccessException {
    Class<?> c = assertClass(PACKAGE, "Schach");
    Schachspiel o = (Schachspiel) c.newInstance();
    assertFalse(o.beendet(), "Sollte in Ausgangsstellung kein Spielende signalisieren.");
  }

  @Test
  public void test04ShouldBeGameOverWhenWhiteKingIsRemoved()
      throws InstantiationException, IllegalAccessException {
    Class<?> c = assertClass(PACKAGE, "Schach");
    Schachspiel o = (Schachspiel) c.newInstance();
    o.set(0, 4, null);
    assertTrue(o.beendet(), "Sollte Spielende anzeigen, wenn weißer König entfernt wird.");
  }

  @Test
  public void test05ShouldBeGameOverWhenBlackKingIsRemoved()
      throws InstantiationException, IllegalAccessException {
    Class<?> c = assertClass(PACKAGE, "Schach");
    Schachspiel o = (Schachspiel) c.newInstance();
    o.set(7, 4, null);
    assertTrue(o.beendet(), "Sollte Spielende anzeigen, wenn schwarzer König entfernt wird.");
  }

  @Test
  public void test06ShouldNotBeGameOverWhenKingsAreDisplaced()
      throws InstantiationException, IllegalAccessException {
    Class<?> c = assertClass(PACKAGE, "Schach");
    Schachspiel o = (Schachspiel) c.newInstance();
    o.set(4, 0, o.get(7, 4));
    o.set(7, 4, null);

    o.set(6, 2, o.get(0, 4));
    o.set(0, 4, null);
    assertFalse(o.beendet(),
        "Sollte kein Spielende anzeigen, wenn Könige sich auf dem Brett befinden!");
  }

}
