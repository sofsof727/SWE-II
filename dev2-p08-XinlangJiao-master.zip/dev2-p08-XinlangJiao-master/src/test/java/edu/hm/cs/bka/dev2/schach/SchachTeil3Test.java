package edu.hm.cs.bka.dev2.schach;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Schachaufgabe, Teil 3
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchachTeil3Test {

    @Test
    @Order(1)
    public void test01RookPositive() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Turm(Farbe.SCHWARZ);
        c.set(6, 3, cm);

        assertTrue(cm.kannZiehen(c, 6, 3, 2, 3));
        assertTrue(cm.kannZiehen(c, 6, 3, 7, 3));
        assertTrue(cm.kannZiehen(c, 6, 3, 6, 0));
        assertTrue(cm.kannZiehen(c, 6, 3, 6, 6));
    }

    @Test
    public void test02RookNegativeBadDirections() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Turm(Farbe.SCHWARZ);
        c.set(6, 3, cm);
        assertFalse(cm.kannZiehen(c, 6, 3, 5, 4));
        assertFalse(cm.kannZiehen(c, 6, 3, 7, 4));
        assertFalse(cm.kannZiehen(c, 6, 3, 6, 3));
        assertFalse(cm.kannZiehen(c, 6, 3, 3, 0));
    }

    @Test
    public void test03RookNegativeManInMiddle() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Turm(Farbe.SCHWARZ);
        c.set(6, 3, cm);
        c.set(5, 3, new Bauer(Farbe.WEISS));
        assertFalse(cm.kannZiehen(c, 6, 3, 2, 3));
    }
    
    @Test
    public void test04LaeuferPositive() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Laeufer(Farbe.SCHWARZ);
        c.set(6, 3, cm);

        assertTrue(cm.kannZiehen(c, 6, 3, 7, 2));
        assertTrue(cm.kannZiehen(c, 6, 3, 7, 4));
        assertTrue(cm.kannZiehen(c, 6, 3, 3, 0));
        assertTrue(cm.kannZiehen(c, 6, 3, 3, 6));
    }

    @Test
    public void test05LaeuferNegativeBadDirections() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Laeufer(Farbe.SCHWARZ);
        c.set(6, 3, cm);
        assertFalse(cm.kannZiehen(c, 6, 3, 6, 4));
        assertFalse(cm.kannZiehen(c, 6, 3, 0, 3));
        assertFalse(cm.kannZiehen(c, 6, 3, 6, 3));
        assertFalse(cm.kannZiehen(c, 6, 3, 3, 2));
    }

    @Test
    public void test06RookNegativeManInMiddle() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Turm(Farbe.SCHWARZ);
        c.set(6, 3, cm);
        c.set(4, 1, new Bauer(Farbe.WEISS));
        assertFalse(cm.kannZiehen(c, 6, 3, 3, 0));
    }

    @Test
    public void test07KingPositive() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Koenig(Farbe.SCHWARZ);
        c.set(6, 3, cm);

        assertTrue(cm.kannZiehen(c, 6, 3, 6,2));
        assertTrue(cm.kannZiehen(c, 6, 3, 7, 4));
        assertTrue(cm.kannZiehen(c, 6, 3, 5, 3));
        assertTrue(cm.kannZiehen(c, 6, 3, 7, 2));
    }

    @Test
    public void test08KingNegative() {
        Schachbrett c = new Schachbrett();
        Figur cm = new Koenig(Farbe.SCHWARZ);
        c.set(6, 3, cm);
        assertFalse(cm.kannZiehen(c, 6, 3, 6, 5));
        assertFalse(cm.kannZiehen(c, 6, 3, 4, 1));
        assertFalse(cm.kannZiehen(c, 6, 3, 6, 3));
        assertFalse(cm.kannZiehen(c, 6, 3, 3, 2));
    }

}
