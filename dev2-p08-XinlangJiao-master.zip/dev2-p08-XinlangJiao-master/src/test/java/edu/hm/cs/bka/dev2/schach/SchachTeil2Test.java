package edu.hm.cs.bka.dev2.schach;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;


import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests für Schachaufgabe, Teil 2
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SchachTeil2Test {

  @Test
  @Order(1)
  public void test01MoveAndCaptureShouldApproveEmptyMove() {
    Schachbrett c = new Schachbrett();
    Figur cm = new TestFigur(Farbe.WEISS);
    c.set(4, 5, cm);
    assertTrue(cm.kannZiehen(c, 4, 5, 6, 6),
        "NormalSchlagendeFiguren sollten auf leere Felder springen dürfen.");
  }

  @Test
  @Order(2)
  public void test02MoveAndCaptureShouldApproveCapture() {
    Schachbrett c = new Schachbrett();
    Figur cm = new TestFigur(Farbe.SCHWARZ);
    c.set(4, 5, cm);
    c.set(6, 6, new Bauer(Farbe.WEISS));
    assertTrue(cm.kannZiehen(c, 4, 5, 6, 6),
        "NormalSchlagendeFiguren sollten auf Felder mit gegnerischer Figur springen dürfen.");
  }

  @Test
  @Order(3)
  public void test03MoveAndCaptureShouldDisapproveIfFieldTaken() {
    Schachbrett c = new Schachbrett();
    Figur cm = new TestFigur(Farbe.SCHWARZ);
    c.set(4, 5, cm);
    c.set(6, 6, new Bauer(Farbe.SCHWARZ));
    assertFalse(cm.kannZiehen(c, 4, 5, 6, 6), "NormalSchlagendeFiguren sollten auf nicht Felder"
        + " mit eigener Figur springen dürfen.");
  }

  @Test
  public void test04SpringerMustApproveValidMoves() {
    Schachbrett c = new Schachbrett();
    Figur cm = new Springer(Farbe.SCHWARZ);
    c.set(5, 4, cm);
    assertTrue(cm.kannZiehen(c, 5, 4, 3, 3), "Zug e6d4 sollte gültig sein für Springer!");
    assertTrue(cm.kannZiehen(c, 5, 4, 7, 5), "Zug e6f8 sollte gültig sein für Springer!");
    assertTrue(cm.kannZiehen(c, 5, 4, 4, 6), "Zug e6g5 sollte gültig sein für Springer!");
  }

  @Test
  public void test05SpringerMustNotApproveInvalidMoves() {
    Schachbrett c = new Schachbrett();
    Figur cm = new Springer(Farbe.SCHWARZ);
    c.set(5, 4, cm);
    assertFalse(cm.kannZiehen(c, 5, 4, 3, 2), "Zug e6c4 sollte ungültig sein für Springer!");
  }

  private static class TestFigur extends NormalSchlagendeFigur {

    public TestFigur(Farbe color) {
      super(color);
    }

  }
}
