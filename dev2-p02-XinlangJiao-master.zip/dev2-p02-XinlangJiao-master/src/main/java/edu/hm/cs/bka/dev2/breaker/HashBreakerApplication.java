package edu.hm.cs.bka.dev2.breaker;

import javax.swing.*;

/**
 * Anwendung zum Ermitteln eines Geheimnisses zu einem Hash.
 *
 * @author katz.bastian
 */
public class HashBreakerApplication {

  /**
   * Gibt zu einem gegebenen Hash das Passwort aus, sofern es einfach genug.
   *
   * @param args nicht verwendet
   */
  public static void main(String... args) {

    String hash = JOptionPane.showInputDialog("Geben Sie den Hash ein!");

    // Erzeuge ein Objekt der Klasse BruteForceSha1Breaker und
    // frage es nach dem Passwort zum Hash.
    BruteForceSha1Breaker breaker = new BruteForceSha1Breaker();
    String password = breaker.findPassword(hash);

    // Gib das gefundene Passwort aus
    if (password != null) {
      JOptionPane.showMessageDialog(null,  "Passwort gefunden: \"" + password + "\"");
    } else {
      JOptionPane.showMessageDialog(null, "Passwort konnte nicht ermittelt werden.");
    }
  }
}
