package edu.hm.cs.bka.dev2.breaker;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.time.Duration;
import org.junit.jupiter.api.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ImprovedHashBreakerTest {

  Duration timeout = Duration.ofSeconds(300);
  @Test
  @Order(1)
  public void testBreakingOne() {
    Assertions.assertTimeoutPreemptively(timeout, () ->
        assertEquals("1",
            new BruteForceSha1Breaker().findPassword("356a192b7913b04c54574d18c28d46e6395428ab")));
  }

  @Test
  @Order(2)
  public void testBreakingFK7() {
    Assertions.assertTimeoutPreemptively(timeout, () ->
        assertEquals("Fk7",
            new BruteForceSha1Breaker().findPassword("c123c63b25b4a2310190015cda4e1df7cb902948")));
  }

  @Test
  @Order(3)
  public void testBreakingIB2() {
    Assertions.assertTimeoutPreemptively(timeout, () ->
        assertEquals("ib2a",
            new BruteForceSha1Breaker().findPassword("b0af40a4d12c9e03a85b05b76d328a1e5157c2ee")));
  }



}

