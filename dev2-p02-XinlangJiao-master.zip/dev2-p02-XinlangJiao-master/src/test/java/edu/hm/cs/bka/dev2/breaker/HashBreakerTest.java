package edu.hm.cs.bka.dev2.breaker;

import java.time.Duration;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;

public class HashBreakerTest {

  Duration timeout = Duration.ofMinutes(3);

  @Test
  public void testBreaking() {
    Assertions.assertTimeoutPreemptively(timeout, () ->
        assertEquals("suba",
            new BruteForceSha1Breaker().findPassword("893cfbd5d9efff90a7726a8dddb60a45cca1c369")));
  }
}
