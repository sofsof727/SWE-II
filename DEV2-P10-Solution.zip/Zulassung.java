package edu.hm.cs.bka.dev2.zulassung;

import java.util.*;

/**
 * Hilfsklasse zur Zusammenführung der einzelnen Bewerbungswege.
 */
public class Zulassung {

  /**
   * Erstellt eine Auswahl aus den Bewerbungen mit Priorität (werden alle aufgenommen) und den
   * Bewerbungen über Web und Mail, von denen noch maximal so viele aufgenommen werden, dass die
   * vorgegebene Anzahl an Plätzen erreicht wird. Unter den Bewerbungen aus Web und Mail werden
   * die Plätze nach Note vergeben, bei gleicher Note nach alphabetischer Ordnung.
   *
   * <p>Achtung! Die Listen können Elemente mehrfach enthalten!
   *
   * @param plaetze Anzahl freier Plätze
   * @param prio    Prio-Bewerbungen, werden alle angenommen
   * @param web     Bewerbungen per Web, werden mit Mail-Bewerbungen zur Auswahl zusammengefasst
   * @param mail    Bewerbungen per Mail, werden mit Web-Bewerbungen zur Auswahl zusammengefasst
   * @return Liste angenommener Bewerbungen,
   */
  public static Set<Bewerbung> select(int plaetze, List<Bewerbung> prio, List<Bewerbung> web,
                                      List<Bewerbung> mail) {
    Set<Bewerbung> auswahl = new HashSet<Bewerbung>();

    auswahl.addAll(prio);

    Set<Bewerbung> rest = new HashSet<Bewerbung>();
    rest.addAll(web);
    rest.addAll(mail);
    rest.removeAll(prio);
    List<Bewerbung> rest2 = new ArrayList<Bewerbung>(rest);
    Collections.sort(rest2);

    if (auswahl.size() < plaetze) {
      if (rest2.size() <= plaetze - auswahl.size()) {
        auswahl.addAll(rest2);
      } else {
        auswahl.addAll(rest2.subList(0, plaetze - auswahl.size()));
      }
    }

    return auswahl;
  }

}
