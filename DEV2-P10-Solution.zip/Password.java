package edu.hm.cs.bka.dev2.passwort;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

/**
 * Klasse zur Ablage/Änderung eines Passwortes mit Durchsetzung von Passwortregeln.
 */
public class Password {

  String password = null;

  /** Schlange mit den letzten 5 Passwörtern. */
  private final Queue<String> recentPasswords = new ArrayDeque<String>();

  /** Menge aller bisher verwendeter Passwörter. */
  private final Set<String> previousPasswords = new HashSet<>();

  /** Menge der bereits zweimal verwendeten Passwörter. */
  private final Set<String> blockedPasswords = new HashSet<>();

  /**
   * Konstruktor. Erzeugt ein Passwort-Objekt mit einem initialen Passwort.
   *
   * @param initial initiales Passwort
   * @throws BadPasswordException wenn das Passwort nicht den Anforderungen genügt.
   */
  public Password(String initial) throws BadPasswordException {
    changePassword(initial);
  }

  /**
   * Gibt das aktuelle Passwort zurück.
   *
   * @return aktuelles Passwort.
   */
  public String getPassword() {
    return password;
  }

  /**
   * Ändert das Passwort. Führt dabei diverse Überprüfungen durch.
   *
   * @param password neues Passwort, darf nicht null sein
   * @throws BadPasswordException wenn das Passwort nicht den Anforderungen genügt.
   */
  public void changePassword(String password) throws BadPasswordException {
    // Passwort darf nicht null sein
    if (password == null) {
      throw new IllegalArgumentException("Parameter password ist null.");
    }

    // Passwort darf nicht leer sein.
    if (password.isEmpty()) {
      throw new BadPasswordException("Passwort darf nicht leer sein!");
    }

    // Teil 1: Passwort darf nicht auf Blacklist stehen.
    if (getBlockList().contains(password.toLowerCase())) {
      throw new BadPasswordException("Passwort ist auf Blacklist!");
    }

    // Teil 2: Passwort muss mindestens 6 verschiedenen Zeichen enthalten.
    if (getNumberOfDifferentCharacters(password) < 6) {
      throw new BadPasswordException("Passwort enthält keine 6 verschiedenen Zeichen!");
    }

    // Teil 3: Passwort darf nicht unter den letzten 5 Passwörtern sein.
    if (recentPasswords.contains(password)) {
      throw new BadPasswordException("Passwort war unter den letzten fünf Passwörtern!");
    }

    // Teil 4: Passwort darf nicht schon zweimal aktiv gewesen sein
    if (blockedPasswords.contains(password)) {
      throw new BadPasswordException("Passwort war schon zweimal aktiv!");
    }

    // Setze das Passwort
    this.password = password;

    // Aktualisiere die Schlange mit den letzten 5 Passwort-Hashes
    recentPasswords.add(password);
    if (recentPasswords.size() > 5) {
      recentPasswords.remove();
    }

    // Aktualisiere die Mengen aller verwendeten und doppelt verwendeten Passwort-Hashes
    if (previousPasswords.contains(password)) {
      blockedPasswords.add(password);
    }
    previousPasswords.add(password);
  }

  /**
   * Liefert die Blacklist.
   *
   * @return Liste mit schlechten Passwörtern (wie "passwort").
   */
  protected static List<String> getBlockList() {
    List<String> blacklist = new ArrayList<String>();
    blacklist.add("geheim");
    blacklist.add("test123");
    blacklist.add("password");
    blacklist.add("passwort");
    return blacklist;
  }

  /**
   * Zählt die Anzahl unterschiedlicher Zeichen.
   *
   * @param password neues Passwort
   * @return Anzahl verschiedener Zeichen im Passwort, also z.B. 7 für "Passwort"
   */
  protected static int getNumberOfDifferentCharacters(String password) {
    char[] pwdAsArray = password.toCharArray();
    Set<Character> uniqueChars = new HashSet<>();
    for (char zeichen : pwdAsArray) {
      uniqueChars.add(zeichen);
    }
    return uniqueChars.size();
  }


}
