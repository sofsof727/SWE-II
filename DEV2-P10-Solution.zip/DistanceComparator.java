package edu.hm.cs.bka.dev2.geometry;

import java.util.Comparator;

/**
 * Comparator (Vergleicher) für zwei Punkte. Die Ordnung der Punkte soll dabei dem Abstand von einem
 * festen Punkt (Mittelpunkt) entsprechen.
 *
 * <p>Achtung: Streng genommen sollte der Comparator für Punkte mit gleichem Abstand auch
 * eine Ordnung definieren, z.B. nach X- und Y-Wert sortieren. Soll nur sortiert werden,
 * reicht aber eine "Ordnung" nach Entfernung.
 */
public class DistanceComparator implements Comparator<Point> {

  private final Point center;

  /**
   * Konstruktor.
   *
   * @param center Zentrum der Abstandsmessung
   */
  public DistanceComparator(Point center) {
    this.center = center;
  }

  @Override
  public int compare(Point o1, Point o2) {

    int distanceVergleich = Double.compare(o1.distanceTo(center), o2.distanceTo(center));
    return distanceVergleich;
  }

}

