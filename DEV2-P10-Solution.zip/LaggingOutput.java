package edu.hm.cs.bka.dev2.schlangen;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Klasse zum Puffern von Ausgaben.
 */
public class LaggingOutput {

  // Speichert die wartenden Strings
  private final Deque<String> queue = new ArrayDeque<String>();

  // maximale Anzahl wartender Strings
  private final int delay;

  /**
   * Konstruktor.
   *
   * @param delay Anzahl der Strings, die zwischengespeichert werden dürfen.
   */
  public LaggingOutput(int delay) {
    this.delay = delay;
  }

  /**
   * Fügt einen String hinzu. Gibt einen wartenden String aus, wenn sonst mehr als die erlaubte
   * Anzahl an Strings warten.
   *
   * @param string (Später) auszugebender String
   */
  public void add(String string) {
    while (queue.size() >= delay) {
      next();
    }
    queue.add(string);
  }

  /**
   * Gibt einen wartenden String aus. Tut nichts, wenn kein String wartet.
   */
  public void next() {
    if (queue.size() > 0) {
      System.out.println(queue.removeFirst());
    }
  }

  /**
   * Entfernt den zuletzt eingefügten String wieder (ohne Ausgabe).
   */
  public void revoke() {
    if (queue.size() > 0) {
      queue.removeLast();
    }
  }

  /**
   * Gibt alle noch wartenden Strings aus.
   */
  public void flush() {
    while (!queue.isEmpty()) {
      next();
    }
  }
}
