package edu.hm.cs.bka.dev2.zulassung;

import java.util.Objects;

/**
 * Klasse zur Speicherung einer Bewerbung.
 */
public class Bewerbung implements Comparable<Bewerbung> {

  private final String name;
  private final double note;

  /**
   * Konstruktor.
   *
   * @param name Name
   * @param note Note des Abschlusszeugnisses
   */
  public Bewerbung(String name, double note) {
    this.name = name;
    this.note = note;
  }

  public String getName() {
    return name;
  }

  public double getNote() {
    return note;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Bewerbung bewerbung = (Bewerbung) o;
    return Double.compare(bewerbung.note, note) == 0
        && Objects.equals(name, bewerbung.name);
  }

  @Override
  public int compareTo(Bewerbung o) {
    int notenVergleich = Double.compare(note, o.note);
    if (notenVergleich != 0) {
      return notenVergleich;
    }

    return name.compareTo(o.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, note);
  }

  @Override
  public String toString() {
    return name + " (" + note + ")";
  }
}
